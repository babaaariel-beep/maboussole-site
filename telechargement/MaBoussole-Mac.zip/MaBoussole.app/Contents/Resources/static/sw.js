﻿// Service worker de MaBoussole Graphiques : rend l'application installable sur le PC.
// RÃ©seau d'abord (donnÃ©es toujours fraÃ®ches) ; la page d'accueil reste disponible si le serveur redÃ©marre.
const CACHE = "mbg-v34";
const BASE = ["/", "/app.css", "/app.js", "/lightweight-charts.js", "/icone.svg", "/icone-192.png", "/manifest.webmanifest"];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(BASE)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== CACHE).map(x => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== location.origin || url.pathname.startsWith("/api/") || location.port === "8781") return;
  e.respondWith(fetch(e.request).then(r => { if (r.ok) { const copie = r.clone(); caches.open(CACHE).then(c => c.put(e.request, copie)); } return r; }).catch(() => caches.match(e.request)));
});
