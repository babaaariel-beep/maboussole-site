// Pine Script dans MaBoussole Graphiques : un interpréteur du langage des indicateurs de TradingView (version 5, partie la plus utilisée).
// MBPine.analyser(code)  -> programme (ou exception PineErreur avec le numéro de ligne)
// MBPine.executer(programme, bougies, valeursEntrees, contexte) -> { titre, overlay, entrees, plots, niveaux, avertissements }
// bougies : [[temps (s), ouverture, haut, bas, clôture, volume], ...]
(function (racine) {
  "use strict";

  class PineErreur extends Error { constructor(message, ligne) { super(message); this.ligne = ligne || 0; } }
  const erreur = (m, l) => { throw new PineErreur(m, l); };

  // ------------------------------------------------------------------ lecture du texte
  const MOTS = new Set(["and", "or", "not", "if", "else", "var", "varip", "true", "false", "for", "to", "by", "while", "switch", "import", "export", "method", "type"]);
  const TYPES = new Set(["int", "float", "bool", "color", "string", "series", "simple", "const", "line", "label", "box", "table"]);
  function jetons(texte, ligne) {
    const t = []; let i = 0;
    while (i < texte.length) {
      const c = texte[i];
      if (c === " " || c === "\t") { i++; continue; }
      if (/[0-9]/.test(c) || (c === "." && /[0-9]/.test(texte[i + 1] || ""))) {
        const m = /^(\d*\.?\d+(?:[eE][+-]?\d+)?|\d+\.)/.exec(texte.slice(i)); t.push({ k: "num", v: parseFloat(m[0]) }); i += m[0].length; continue;
      }
      if (/[A-Za-z_]/.test(c)) {
        const m = /^[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)*/.exec(texte.slice(i)); const v = m[0];
        t.push({ k: MOTS.has(v) ? "mot" : "id", v }); i += v.length; continue;
      }
      if (c === '"' || c === "'") {
        let j = i + 1, s = "";
        while (j < texte.length && texte[j] !== c) { if (texte[j] === "\\" && j + 1 < texte.length) { j++; s += texte[j] === "n" ? "\n" : texte[j]; } else s += texte[j]; j++; }
        if (j >= texte.length) erreur("Texte entre guillemets non fermé", ligne);
        t.push({ k: "str", v: s }); i = j + 1; continue;
      }
      if (c === "#") { const m = /^#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?/.exec(texte.slice(i)); if (m) { t.push({ k: "couleur", v: m[0] }); i += m[0].length; continue; } }
      const deux = texte.substr(i, 2);
      if ([":=", "==", "!=", ">=", "<=", "=>", "+=", "-=", "*=", "/=", "%="].includes(deux)) { t.push({ k: "op", v: deux }); i += 2; continue; }
      if ("+-*/%<>=?:()[],".includes(c)) { t.push({ k: "op", v: c }); i++; continue; }
      erreur(`Caractère inattendu « ${c} »`, ligne);
    }
    return t;
  }
  function sansCommentaire(l) {                 // retire « // … » hors des textes
    let q = null;
    for (let i = 0; i < l.length; i++) {
      const c = l[i];
      if (q) { if (c === "\\") i++; else if (c === q) q = null; }
      else if (c === '"' || c === "'") q = c;
      else if (c === "/" && l[i + 1] === "/") return l.slice(0, i);
    }
    return l;
  }
  function lignesLogiques(code) {               // assemble les lignes coupées (parenthèses ouvertes ou retrait non multiple de 4)
    const brutes = code.replace(/\r/g, "").split("\n"), out = [];
    let cour = null, prof = 0;
    brutes.forEach((b, k) => {
      const s = sansCommentaire(b).replace(/\t/g, "    ");
      if (!s.trim()) return;
      const retrait = s.length - s.trimStart().length;
      if (cour && (prof > 0 || retrait % 4 !== 0 || /[,+\-*/%?:(=]$|\b(and|or)$/.test(cour.texte.trimEnd()) && !/=>$/.test(cour.texte.trimEnd()))) cour.texte += " " + s.trim();
      else { cour = { texte: s.trim(), retrait: retrait / 4, ligne: k + 1 }; out.push(cour); }
      prof = 0; let q = null;
      for (let i = 0; i < cour.texte.length; i++) { const c = cour.texte[i]; if (q) { if (c === "\\") i++; else if (c === q) q = null; } else if (c === '"' || c === "'") q = c; else if (c === "(" || c === "[") prof++; else if (c === ")" || c === "]") prof--; }
    });
    return out;
  }

  // ------------------------------------------------------------------ analyse (arbre)
  let numero = 0;
  function Lecteur(t, ligne) {
    let i = 0;
    const voir = (k, v) => t[i] && t[i].k === k && (v === undefined || t[i].v === v);
    const prendre = (k, v) => { if (!voir(k, v)) erreur(`« ${v || k} » attendu${t[i] ? ` avant « ${t[i].v} »` : " en fin de ligne"}`, ligne); return t[i++]; };
    const noeud = (o) => Object.assign(o, { id: ++numero, ligne });
    function expr() { return ternaire(); }
    function ternaire() {
      const c = ou();
      if (voir("op", "?")) { i++; const a = ternaire(); prendre("op", ":"); const b = ternaire(); return noeud({ t: "tern", c, a, b }); }
      return c;
    }
    function ou() { let g = et(); while (voir("mot", "or")) { i++; g = noeud({ t: "ou", g, d: et() }); } return g; }
    function et() { let g = egal(); while (voir("mot", "and")) { i++; g = noeud({ t: "et", g, d: egal() }); } return g; }
    function egal() { let g = comp(); while (voir("op", "==") || voir("op", "!=")) { const o = t[i++].v; g = noeud({ t: "bin", o, g, d: comp() }); } return g; }
    function comp() { let g = add(); while (["<", ">", "<=", ">="].some(o => voir("op", o))) { const o = t[i++].v; g = noeud({ t: "bin", o, g, d: add() }); } return g; }
    function add() { let g = mul(); while (voir("op", "+") || voir("op", "-")) { const o = t[i++].v; g = noeud({ t: "bin", o, g, d: mul() }); } return g; }
    function mul() { let g = un(); while (voir("op", "*") || voir("op", "/") || voir("op", "%")) { const o = t[i++].v; g = noeud({ t: "bin", o, g, d: un() }); } return g; }
    function un() {
      if (voir("mot", "not")) { i++; return noeud({ t: "non", e: un() }); }
      if (voir("op", "-")) { i++; return noeud({ t: "neg", e: un() }); }
      if (voir("op", "+")) { i++; return un(); }
      return suffixe();
    }
    function suffixe() {
      let e = prim();
      for (;;) {
        if (voir("op", "(") && e.t === "nom") { i++; const args = [], noms = {};
          while (!voir("op", ")")) {
            if (voir("id") && t[i + 1] && t[i + 1].k === "op" && t[i + 1].v === "=") { const n = t[i].v; i += 2; noms[n] = expr(); }
            else args.push(expr());
            if (!voir("op", ")")) prendre("op", ",");
          }
          i++; e = noeud({ t: "appel", nom: e.v, args, noms }); continue; }
        if (voir("op", "[")) { i++; const k = expr(); prendre("op", "]"); e = noeud({ t: "hist", e, k }); continue; }
        return e;
      }
    }
    function prim() {
      const j = t[i];
      if (!j) erreur("Expression incomplète", ligne);
      if (j.k === "num") { i++; return noeud({ t: "val", v: j.v }); }
      if (j.k === "str") { i++; return noeud({ t: "val", v: j.v }); }
      if (j.k === "couleur") { i++; return noeud({ t: "val", v: j.v }); }
      if (j.k === "mot" && (j.v === "true" || j.v === "false")) { i++; return noeud({ t: "val", v: j.v === "true" }); }
      if (j.k === "id") { i++; return noeud({ t: "nom", v: j.v }); }
      if (j.k === "op" && j.v === "(") { i++; const e = expr(); prendre("op", ")"); return e; }
      if (j.k === "op" && j.v === "[") { i++; const el = []; while (!voir("op", "]")) { el.push(expr()); if (!voir("op", "]")) prendre("op", ","); } i++; return noeud({ t: "tuple", el }); }
      erreur(`« ${j.v} » inattendu`, ligne);
    }
    return { expr, voir, prendre, fin: () => i >= t.length, pos: () => i, aller: k => { i = k; }, t, noeud };
  }

  function analyser(code) {
    numero = 0;
    const lignes = lignesLogiques(String(code || ""));
    let k = 0;
    function bloc(niveau) {
      const instr = [];
      while (k < lignes.length && lignes[k].retrait >= niveau) {
        const L = lignes[k];
        if (L.retrait > niveau) erreur("Retrait inattendu (4 espaces par niveau dans un bloc if / for / fonction)", L.ligne);
        instr.push(instruction(L, niveau));
      }
      return instr;
    }
    function instruction(L, niveau) {
      k++;
      const t = jetons(L.texte, L.ligne), R = Lecteur(t, L.ligne);
      if (!t.length) return { t: "rien" };
      const tete = t[0];
      if (tete.k === "mot" && ["while", "switch", "import", "export", "method", "type"].includes(tete.v)) erreur(`« ${tete.v} » n'est pas encore pris en charge dans MaBoussole`, L.ligne);
      if (tete.k === "mot" && tete.v === "if") {
        R.prendre("mot", "if"); const c = R.expr(); if (!R.fin()) erreur("Fin de ligne attendue après la condition du if", L.ligne);
        const alors = bloc(niveau + 1); let sinon = null;
        if (k < lignes.length && lignes[k].retrait === niveau && /^else\b/.test(lignes[k].texte)) {
          const E = lignes[k];
          if (/^else\s+if\b/.test(E.texte)) { E.texte = E.texte.replace(/^else\s+/, ""); sinon = [instruction(E, niveau)]; }
          else { k++; sinon = bloc(niveau + 1); }
        }
        return { t: "si", c, alors, sinon, ligne: L.ligne };
      }
      if (tete.k === "mot" && tete.v === "for") {
        R.prendre("mot", "for"); const v = R.prendre("id").v; R.prendre("op", "="); const de = R.expr(); R.prendre("mot", "to"); const a = R.expr();
        let pas = null; if (R.voir("mot", "by")) { R.prendre("mot", "by"); pas = R.expr(); }
        return { t: "pour", v, de, a, pas, corps: bloc(niveau + 1), ligne: L.ligne };
      }
      // fonction : nom(a, b) => …
      if (tete.k === "id" && t[1] && t[1].v === "(") {
        let p = 1, prof = 0; for (; p < t.length; p++) { if (t[p].v === "(") prof++; if (t[p].v === ")") { prof--; if (!prof) break; } }
        if (t[p + 1] && t[p + 1].v === "=>") {
          const params = []; for (let q = 2; q < p; q++) if (t[q].k === "id" && !TYPES.has(t[q].v)) params.push(t[q].v);
          let corps;
          if (p + 2 < t.length) { const R2 = Lecteur(t.slice(p + 2), L.ligne); corps = [{ t: "expr", e: R2.expr(), ligne: L.ligne }]; }
          else corps = bloc(niveau + 1);
          return { t: "fonc", nom: tete.v, params, corps, ligne: L.ligne };
        }
      }
      // déclaration de tuple : [a, b] = …
      if (tete.k === "op" && tete.v === "[") {
        const noms = []; let p = 1;
        while (p < t.length && t[p].v !== "]") { if (t[p].k === "id") noms.push(t[p].v); p++; }
        if (t[p + 1] && (t[p + 1].v === "=" || t[p + 1].v === ":=")) { R.aller(p + 2); return { t: "tuple", noms, e: R.expr(), ligne: L.ligne }; }
      }
      // déclaration / affectation : [var] [type] nom = …   ou   nom := …
      let p = 0, persistant = false;
      if (t[p] && t[p].k === "mot" && (t[p].v === "var" || t[p].v === "varip")) { persistant = true; p++; }
      while (t[p] && t[p].k === "id" && TYPES.has(t[p].v) && t[p + 1] && t[p + 1].k === "id") p++;
      if (t[p] && t[p].k === "id" && t[p + 1] && t[p + 1].k === "op" && ["=", ":=", "+=", "-=", "*=", "/=", "%="].includes(t[p + 1].v)) {
        const nom = t[p].v, op = t[p + 1].v; R.aller(p + 2); const e = R.expr(); if (!R.fin()) erreur(`Fin de ligne attendue, trouvé « ${t[R.pos()].v} »`, L.ligne);
        return { t: op === "=" ? "decl" : "affect", nom, op, e, persistant, ligne: L.ligne };
      }
      const e = R.expr(); if (!R.fin()) erreur(`Fin de ligne attendue, trouvé « ${t[R.pos()].v} »`, L.ligne);
      return { t: "expr", e, ligne: L.ligne };
    }
    const prog = bloc(0);
    if (k < lignes.length) erreur("Retrait inattendu en début de ligne", lignes[k].ligne);
    return { instr: prog, code };
  }

  // ------------------------------------------------------------------ couleurs
  const COULEURS = { red: "#F23645", green: "#089981", blue: "#2962FF", orange: "#FF9800", purple: "#9C27B0", yellow: "#FFEB3B", white: "#FFFFFF", black: "#363A45",
    gray: "#787B86", silver: "#B2B5BE", teal: "#009688", aqua: "#00BCD4", lime: "#00E676", maroon: "#880E4F", navy: "#311B92", fuchsia: "#E040FB", olive: "#808000" };
  function rgbDe(c) {
    if (typeof c !== "string") return null;
    let m = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})?$/i.exec(c);
    if (m) return [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16), m[4] ? parseInt(m[4], 16) / 255 : 1];
    m = /^rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?\)$/.exec(c);
    if (m) return [+m[1], +m[2], +m[3], m[4] == null ? 1 : +m[4]];
    return null;
  }
  const rgba = (r, g, b, a) => `rgba(${Math.round(r)},${Math.round(g)},${Math.round(b)},${+a.toFixed(3)})`;

  // ------------------------------------------------------------------ exécution
  const NA = NaN, estNa = x => x === null || x === undefined || (typeof x === "number" && isNaN(x));
  const nombre = x => (typeof x === "boolean" ? (x ? 1 : 0) : estNa(x) ? NaN : +x);
  const vrai = x => (typeof x === "boolean" ? x : !estNa(x) && x !== 0 && x !== "");

  function executer(prog, bougies, valeurs, ctxt) {
    valeurs = valeurs || {}; ctxt = ctxt || {};
    const n = bougies.length, O = [], H = [], Lo = [], C = [], V = [], T = [];
    for (const b of bougies) { T.push(b[0]); O.push(+b[1]); H.push(+b[2]); Lo.push(+b[3]); C.push(+b[4]); V.push(+(b[5] || 0)); }
    const res = { titre: "Mon script", court: "", overlay: false, entrees: [], plots: [], niveaux: [], fonds: [], avertissements: [] };
    const plots = new Map(), entreesVues = new Map(), etats = new Map(), fonctions = new Map(), dejaAverti = new Set();
    let i = 0, ligneCour = 0;
    const averti = m => { if (!dejaAverti.has(m)) { dejaAverti.add(m); res.avertissements.push(m); } };
    const etat = cle => { let s = etats.get(cle); if (!s) { s = {}; etats.set(cle, s); } return s; };
    const sous = (s, k) => (s[k] || (s[k] = {}));

    // variables : { vals: [], persistant }
    function Portee(parent) { this.vars = new Map(); this.parent = parent; }
    Portee.prototype.trouver = function (n) { let p = this; while (p) { if (p.vars.has(n)) return p.vars.get(n); p = p.parent; } return null; };
    const globale = new Portee(null);
    const portees = new Map();                 // portées des fonctions, gardées d'une bougie à l'autre

    // séries intégrées
    function serieIntegree(nom, k) {
      const j = i - k; if (j < 0) return NA;
      switch (nom) {
        case "open": return O[j]; case "high": return H[j]; case "low": return Lo[j]; case "close": return C[j]; case "volume": return V[j];
        case "hl2": return (H[j] + Lo[j]) / 2; case "hlc3": return (H[j] + Lo[j] + C[j]) / 3; case "ohlc4": return (O[j] + H[j] + Lo[j] + C[j]) / 4; case "hlcc4": return (H[j] + Lo[j] + 2 * C[j]) / 4;
        case "time": case "time_close": return T[j] * 1000; case "bar_index": return j; case "ta.tr": return vraieAmpl(j);
      }
      return undefined;
    }
    const vraieAmpl = j => j === 0 ? H[j] - Lo[j] : Math.max(H[j] - Lo[j], Math.abs(H[j] - C[j - 1]), Math.abs(Lo[j] - C[j - 1]));
    function constante(nom) {
      if (nom === "na") return NA;
      if (nom.startsWith("color.")) { const c = COULEURS[nom.slice(6)]; if (c) return c; }
      if (nom === "last_bar_index") return n - 1;
      if (nom === "barstate.islast") return i === n - 1; if (nom === "barstate.isfirst") return i === 0; if (nom === "barstate.isconfirmed") return i < n - 1;
      if (nom === "barstate.isrealtime" || nom === "barstate.isnew") return i === n - 1;
      if (nom === "syminfo.ticker" || nom === "syminfo.tickerid") return ctxt.symbole || ""; if (nom === "timeframe.period") return ctxt.periode || "";
      if (nom === "syminfo.mintick") return ctxt.mintick || 0.00001;
      if (nom === "timeframe.isintraday") return (ctxt.secondes || 3600) < 86400; if (nom === "timeframe.isdaily") return ctxt.secondes === 86400;
      if (nom.startsWith("plot.style_") || nom.startsWith("hline.style_") || nom.startsWith("shape.") || nom.startsWith("location.") || nom.startsWith("size.") || nom.startsWith("display.") || nom.startsWith("position.") || nom.startsWith("format.") || nom.startsWith("extend.") || nom.startsWith("text.") || nom.startsWith("xloc.") || nom.startsWith("yloc.") || nom.startsWith("scale.") || nom.startsWith("barmerge.")) return nom;
      if (nom === "math.pi") return Math.PI; if (nom === "math.e") return Math.E;
      if (nom === "dayofweek" || nom === "hour" || nom === "minute" || nom === "dayofmonth" || nom === "month" || nom === "year") {
        const d = new Date(T[i] * 1000); return nom === "dayofweek" ? d.getUTCDay() + 1 : nom === "hour" ? d.getUTCHours() : nom === "minute" ? d.getUTCMinutes() : nom === "dayofmonth" ? d.getUTCDate() : nom === "month" ? d.getUTCMonth() + 1 : d.getUTCFullYear();
      }
      return undefined;
    }

    // ---- fonctions techniques (une mémoire par endroit d'appel)
    const tampon = (s, x, len) => { const b = s.b || (s.b = []); b.push(x); while (b.length > len) b.shift(); return b; };
    const pleinOk = (b, len) => b.length === len && !b.some(estNa);
    function smaE(s, x, len) { const b = tampon(s, x, len); return pleinOk(b, len) ? b.reduce((a, y) => a + y, 0) / len : NA; }
    function emaE(s, x, len, alpha) {
      if (estNa(x)) return s.v === undefined ? NA : s.v;
      if (s.v === undefined) { const b = tampon(s, x, len); if (b.length < len) return NA; s.v = b.reduce((a, y) => a + y, 0) / len; return s.v; }
      s.v = alpha * x + (1 - alpha) * s.v; return s.v;
    }
    const ema = (s, x, len) => emaE(s, x, len, 2 / (len + 1)), rma = (s, x, len) => emaE(s, x, len, 1 / len);
    function wmaE(s, x, len) { const b = tampon(s, x, len); if (!pleinOk(b, len)) return NA; let num = 0, den = 0; b.forEach((y, k) => { num += y * (k + 1); den += k + 1; }); return num / den; }
    function stdevE(s, x, len) { const b = tampon(s, x, len); if (!pleinOk(b, len)) return NA; const m = b.reduce((a, y) => a + y, 0) / len; return Math.sqrt(b.reduce((a, y) => a + (y - m) * (y - m), 0) / len); }
    function plusHaut(s, x, len) { const b = tampon(s, x, len); return b.length === len ? Math.max(...b.filter(y => !estNa(y))) : NA; }
    function plusBas(s, x, len) { const b = tampon(s, x, len); return b.length === len ? Math.min(...b.filter(y => !estNa(y))) : NA; }
    function retard(s, x, k) { const b = tampon(s, x, k + 1); return b.length === k + 1 ? b[0] : NA; }
    function rsiE(s, x, len) {
      const p = s.p; s.p = x; if (p === undefined || estNa(p) || estNa(x)) return NA;
      const u = rma(sous(s, "u"), Math.max(x - p, 0), len), d = rma(sous(s, "d"), Math.max(p - x, 0), len);
      if (estNa(u) || estNa(d)) return NA; return d === 0 ? 100 : u === 0 ? 0 : 100 - 100 / (1 + u / d);
    }
    const len = v => { const l = Math.round(nombre(v)); if (!(l >= 1)) erreur("La longueur doit être un nombre entier positif", ligneCour); return l; };

    const TA = {
      "ta.sma": (s, a) => smaE(s, nombre(a[0]), len(a[1])),
      "ta.ema": (s, a) => ema(s, nombre(a[0]), len(a[1])),
      "ta.rma": (s, a) => rma(s, nombre(a[0]), len(a[1])),
      "ta.wma": (s, a) => wmaE(s, nombre(a[0]), len(a[1])),
      "ta.vwma": (s, a) => { const l = len(a[1]), x = nombre(a[0]), num = smaE(sous(s, "n"), x * V[i], l), den = smaE(sous(s, "d"), V[i], l); return den ? num / den : NA; },
      "ta.hma": (s, a) => { const l = len(a[1]), x = nombre(a[0]), w1 = wmaE(sous(s, "a"), x, Math.max(1, Math.floor(l / 2))), w2 = wmaE(sous(s, "b"), x, l); return wmaE(sous(s, "c"), 2 * w1 - w2, Math.max(1, Math.round(Math.sqrt(l)))); },
      "ta.rsi": (s, a) => rsiE(s, nombre(a[0]), len(a[1])),
      "ta.stdev": (s, a) => stdevE(s, nombre(a[0]), len(a[1])),
      "ta.variance": (s, a) => { const d = stdevE(s, nombre(a[0]), len(a[1])); return d * d; },
      "ta.highest": (s, a) => a.length < 2 ? plusHaut(s, H[i], len(a[0])) : plusHaut(s, nombre(a[0]), len(a[1])),
      "ta.lowest": (s, a) => a.length < 2 ? plusBas(s, Lo[i], len(a[0])) : plusBas(s, nombre(a[0]), len(a[1])),
      "ta.change": (s, a) => { const x = nombre(a[0]), k = a.length > 1 ? len(a[1]) : 1; if (typeof a[0] === "boolean") { const p = retard(s, a[0], k); return p === a[0] ? false : true; } return x - retard(s, x, k); },
      "ta.mom": (s, a) => { const x = nombre(a[0]); return x - retard(s, x, len(a[1])); },
      "ta.roc": (s, a) => { const x = nombre(a[0]), p = retard(s, x, len(a[1])); return p ? 100 * (x - p) / p : NA; },
      "ta.crossover": (s, a) => { const x = nombre(a[0]), y = nombre(a[1]), r = s.x !== undefined && x > y && s.x <= s.y; s.x = x; s.y = y; return r; },
      "ta.crossunder": (s, a) => { const x = nombre(a[0]), y = nombre(a[1]), r = s.x !== undefined && x < y && s.x >= s.y; s.x = x; s.y = y; return r; },
      "ta.cross": (s, a) => { const x = nombre(a[0]), y = nombre(a[1]), r = s.x !== undefined && ((x > y && s.x <= s.y) || (x < y && s.x >= s.y)); s.x = x; s.y = y; return r; },
      "ta.tr": () => vraieAmpl(i),
      "ta.atr": (s, a) => rma(s, vraieAmpl(i), len(a[0])),
      "ta.cum": (s, a) => { const x = nombre(a[0]); s.v = (s.v || 0) + (estNa(x) ? 0 : x); return s.v; },
      "ta.macd": (s, a) => { const x = nombre(a[0]), m = ema(sous(s, "f"), x, len(a[1])) - ema(sous(s, "l"), x, len(a[2])), sg = ema(sous(s, "s"), m, len(a[3])); return [m, sg, m - sg]; },
      "ta.bb": (s, a) => { const x = nombre(a[0]), l = len(a[1]), k = nombre(a[2]), m = smaE(sous(s, "m"), x, l), d = stdevE(sous(s, "d"), x, l); return [m, m + k * d, m - k * d]; },
      "ta.stoch": (s, a) => { const l = len(a[3]), hh = plusHaut(sous(s, "h"), nombre(a[1]), l), ll = plusBas(sous(s, "l"), nombre(a[2]), l); return hh === ll ? NA : 100 * (nombre(a[0]) - ll) / (hh - ll); },
      "ta.cci": (s, a) => { const l = len(a[1]), x = nombre(a[0]), b = tampon(s, x, l); if (!pleinOk(b, l)) return NA; const m = b.reduce((p, y) => p + y, 0) / l, md = b.reduce((p, y) => p + Math.abs(y - m), 0) / l; return md ? (x - m) / (0.015 * md) : 0; },
      "ta.mfi": (s, a) => { const l = len(a[1]), x = nombre(a[0]), p = s.p; s.p = x; const f = x * V[i], pos = p !== undefined && x > p ? f : 0, neg = p !== undefined && x < p ? f : 0;
        const bp = tampon(sous(s, "p"), pos, l), bn = tampon(sous(s, "n"), neg, l); if (bp.length < l) return NA; const sp = bp.reduce((q, y) => q + y, 0), sn = bn.reduce((q, y) => q + y, 0); return sn ? 100 - 100 / (1 + sp / sn) : 100; },
      "ta.barssince": (s, a) => { if (vrai(a[0])) s.d = i; return s.d === undefined ? NA : i - s.d; },
      "ta.valuewhen": (s, a) => { const l = s.l || (s.l = []); if (vrai(a[0])) l.unshift(a[1]); if (l.length > 500) l.pop(); const k = Math.round(nombre(a[2]) || 0); return l.length > k ? l[k] : NA; },
      "ta.rising": (s, a) => { const l = len(a[1]), b = tampon(s, nombre(a[0]), l + 1); if (b.length < l + 1) return false; for (let k = 1; k < b.length; k++) if (!(b[k] > b[k - 1])) return false; return true; },
      "ta.falling": (s, a) => { const l = len(a[1]), b = tampon(s, nombre(a[0]), l + 1); if (b.length < l + 1) return false; for (let k = 1; k < b.length; k++) if (!(b[k] < b[k - 1])) return false; return true; },
      "ta.pivothigh": (s, a) => { const [src, g, d] = a.length >= 3 ? [nombre(a[0]), len(a[1]), len(a[2])] : [H[i], len(a[0]), len(a[1])]; const b = tampon(s, src, g + d + 1); if (b.length < g + d + 1) return NA; const c = b[g]; for (let k = 0; k < b.length; k++) if (k !== g && !(b[k] < c)) return NA; return c; },
      "ta.pivotlow": (s, a) => { const [src, g, d] = a.length >= 3 ? [nombre(a[0]), len(a[1]), len(a[2])] : [Lo[i], len(a[0]), len(a[1])]; const b = tampon(s, src, g + d + 1); if (b.length < g + d + 1) return NA; const c = b[g]; for (let k = 0; k < b.length; k++) if (k !== g && !(b[k] > c)) return NA; return c; },
      "ta.vwap": (s, a) => { const x = a.length ? nombre(a[0]) : (H[i] + Lo[i] + C[i]) / 3, j = Math.floor(T[i] / 86400); if (s.j !== j) { s.j = j; s.pv = 0; s.v = 0; } s.pv += x * (V[i] || 1); s.v += V[i] || 1; return s.pv / s.v; },
      "ta.obv": (s) => { s.v = (s.v || 0) + (i ? (C[i] > C[i - 1] ? V[i] : C[i] < C[i - 1] ? -V[i] : 0) : 0); return s.v; },
      "ta.linreg": (s, a) => { const l = len(a[1]), off = Math.round(nombre(a[2]) || 0), b = tampon(s, nombre(a[0]), l); if (!pleinOk(b, l)) return NA;
        let sx = 0, sy = 0, sxy = 0, sxx = 0; b.forEach((y, k) => { sx += k; sy += y; sxy += k * y; sxx += k * k; }); const pente = (l * sxy - sx * sy) / (l * sxx - sx * sx), ord = (sy - pente * sx) / l; return ord + pente * (l - 1 - off); },
      "ta.supertrend": (s, a) => { const f = nombre(a[0]), at = rma(sous(s, "a"), vraieAmpl(i), len(a[1])); if (estNa(at)) return [NA, NA];
        const m = (H[i] + Lo[i]) / 2; let up = m - f * at, dn = m + f * at; const pc = i ? C[i - 1] : C[i];
        if (s.up !== undefined) { up = up > s.up || pc < s.up ? up : s.up; dn = dn < s.dn || pc > s.dn ? dn : s.dn; }
        let dir = s.dir === undefined ? 1 : s.dir; if (s.st !== undefined) dir = s.st === s.dn ? (C[i] > dn ? -1 : 1) : (C[i] < up ? 1 : -1);
        s.up = up; s.dn = dn; s.dir = dir; s.st = dir === -1 ? up : dn; return [s.st, dir]; },
      "ta.dmi": (s, a) => { const l = len(a[0]), ls = len(a[1]), hu = i ? H[i] - H[i - 1] : 0, bd = i ? Lo[i - 1] - Lo[i] : 0;
        const pdm = hu > bd && hu > 0 ? hu : 0, mdm = bd > hu && bd > 0 ? bd : 0, tr = rma(sous(s, "t"), vraieAmpl(i), l), pp = rma(sous(s, "p"), pdm, l), mm = rma(sous(s, "m"), mdm, l);
        const pdi = 100 * pp / tr, mdi = 100 * mm / tr, dx = pdi + mdi ? 100 * Math.abs(pdi - mdi) / (pdi + mdi) : 0; return [pdi, mdi, rma(sous(s, "x"), dx, ls)]; },
      "math.sum": (s, a) => { const l = len(a[1]), b = tampon(s, nombre(a[0]), l); return pleinOk(b, l) ? b.reduce((p, y) => p + y, 0) : NA; },
      "ta.median": (s, a) => { const l = len(a[1]), b = tampon(s, nombre(a[0]), l); if (!pleinOk(b, l)) return NA; const t = [...b].sort((x, y) => x - y); return l % 2 ? t[(l - 1) / 2] : (t[l / 2 - 1] + t[l / 2]) / 2; },
    };
    const SIMPLES = {
      "math.abs": a => Math.abs(nombre(a[0])), "math.max": a => Math.max(...a.map(nombre)), "math.min": a => Math.min(...a.map(nombre)),
      "math.round": a => { const x = nombre(a[0]), p = a.length > 1 ? Math.pow(10, nombre(a[1])) : 1; return Math.round(x * p) / p; },
      "math.floor": a => Math.floor(nombre(a[0])), "math.ceil": a => Math.ceil(nombre(a[0])), "math.sqrt": a => Math.sqrt(nombre(a[0])), "math.pow": a => Math.pow(nombre(a[0]), nombre(a[1])),
      "math.log": a => Math.log(nombre(a[0])), "math.log10": a => Math.log10(nombre(a[0])), "math.exp": a => Math.exp(nombre(a[0])), "math.sign": a => Math.sign(nombre(a[0])),
      "math.avg": a => a.map(nombre).reduce((p, y) => p + y, 0) / a.length, "math.sin": a => Math.sin(nombre(a[0])), "math.cos": a => Math.cos(nombre(a[0])), "math.tan": a => Math.tan(nombre(a[0])),
      "math.atan": a => Math.atan(nombre(a[0])), "math.round_to_mintick": a => { const m = ctxt.mintick || 0.00001; return Math.round(nombre(a[0]) / m) * m; },
      "nz": a => (estNa(a[0]) ? (a.length > 1 ? a[1] : 0) : a[0]), "na": a => estNa(a[0]), "fixnan": a => a[0],
      "int": a => Math.trunc(nombre(a[0])), "float": a => nombre(a[0]), "bool": a => vrai(a[0]),
      "str.tostring": a => (estNa(a[0]) ? "NaN" : typeof a[0] === "number" && a.length > 1 ? a[0].toFixed(Math.max(0, String(a[1]).replace(/[^0]/g, "").length - 1)) : String(a[0])),
      "str.format": a => String(a[0]).replace(/\{(\d+)[^}]*\}/g, (_, k) => String(a[+k + 1])),
      "color.new": a => { const c = rgbDe(a[0]); return c ? rgba(c[0], c[1], c[2], c[3] * (1 - Math.min(100, Math.max(0, nombre(a[1]) || 0)) / 100)) : a[0]; },
      "color.rgb": a => rgba(nombre(a[0]), nombre(a[1]), nombre(a[2]), 1 - (a.length > 3 ? nombre(a[3]) : 0) / 100),
      "color.from_gradient": a => { const x = nombre(a[0]), b = nombre(a[1]), t = nombre(a[2]), c1 = rgbDe(a[3]), c2 = rgbDe(a[4]); if (!c1 || !c2) return a[3]; const k = t === b ? 0 : Math.min(1, Math.max(0, (x - b) / (t - b))); return rgba(c1[0] + (c2[0] - c1[0]) * k, c1[1] + (c2[1] - c1[1]) * k, c1[2] + (c2[2] - c1[2]) * k, c1[3] + (c2[3] - c1[3]) * k); },
    };
    const IGNORES = new Set(["plotshape", "plotchar", "plotarrow", "plotcandle", "plotbar", "barcolor", "fill", "alert", "alertcondition", "label.new", "line.new", "box.new", "table.new", "label.delete", "line.delete", "box.delete",
      "label.set_xy", "label.set_text", "line.set_xy1", "line.set_xy2", "box.set_lefttop", "box.set_rightbottom", "table.cell", "strategy.entry", "strategy.exit", "strategy.close", "strategy.order", "strategy.cancel", "runtime.error", "log.info", "log.warning"]);
    const SIGN = {                               // noms des paramètres dans l'ordre, pour les appels avec noms (title=…, color=…)
      plot: ["series", "title", "color", "linewidth", "style", "trackprice", "histbase", "offset", "join", "editable", "show_last", "display"],
      hline: ["price", "title", "color", "linestyle", "linewidth", "editable", "display"],
      bgcolor: ["color", "offset", "editable", "show_last", "title", "display"],
      indicator: ["title", "shorttitle", "overlay", "format", "precision", "scale", "max_bars_back", "timeframe", "timeframe_gaps", "explicit_plot_zorder", "max_lines_count", "max_labels_count", "max_boxes_count", "calc_bars_count", "max_polylines_count", "dynamic_requests", "behind_chart"],
      input: ["defval", "title", "tooltip", "inline", "group", "confirm", "display"],
    };
    const arg = (sig, pos, noms, nom, def) => { const k = sig.indexOf(nom); if (noms[nom] !== undefined) return noms[nom]; if (k >= 0 && pos[k] !== undefined) return pos[k]; return def; };

    function evalArgs(nd, port, cle) { const pos = nd.args.map(a => ev(a, port, cle)), noms = {}; for (const k in nd.noms) noms[k] = ev(nd.noms[k], port, cle); return { pos, noms }; }

    function entree(nd, port, cle, type) {
      const { pos, noms } = evalArgs(nd, port, cle);
      const def = arg(SIGN.input, pos, noms, "defval", type === "source" ? "close" : 0);
      let titre = String(arg(SIGN.input, pos, noms, "title", "") || "");
      let e = entreesVues.get(nd.id);
      if (!e) {
        if (!titre) titre = "Entrée " + (res.entrees.length + 1);
        let cleE = titre, k = 2; while (res.entrees.some(x => x.cle === cleE)) cleE = titre + " " + k++;
        const options = noms.options || pos.find((x, j) => j > 1 && Array.isArray(x));
        let defNorm = def;
        if (type === "source") defNorm = nd.args[0] && nd.args[0].t === "nom" ? nd.args[0].v : nd.noms.defval && nd.noms.defval.t === "nom" ? nd.noms.defval.v : "close";
        e = { cle: cleE, titre, type, def: defNorm, options: Array.isArray(options) ? options : null, min: noms.minval, max: noms.maxval };
        entreesVues.set(nd.id, e); res.entrees.push(e);
      }
      const v = Object.prototype.hasOwnProperty.call(valeurs, e.cle) ? valeurs[e.cle] : e.def;
      if (type === "source") { const s = serieIntegree(String(v), 0); return s === undefined ? C[i] : s; }
      if (type === "int") return Math.round(nombre(v)); if (type === "float") return nombre(v); if (type === "bool") return v === true || v === "true";
      return v;
    }

    function appel(nd, port, cle) {
      let nom = nd.nom;
      if (fonctions.has(nom)) {                                  // fonction écrite dans le script
        const f = fonctions.get(nom), args = nd.args.map(a => ev(a, port, cle)), cleF = cle + ">" + nd.id;
        let pf = portees.get(cleF); if (!pf) { pf = new Portee(globale); portees.set(cleF, pf); }
        f.params.forEach((p, k) => { const v = k < args.length ? args[k] : nd.noms[p] !== undefined ? ev(nd.noms[p], port, cle) : NA; affecter(pf, p, v, true); });
        let r = NA; for (const ins of f.corps) r = executerInstr(ins, pf, cleF);
        return r;
      }
      if (!TA[nom] && !SIMPLES[nom] && TA["ta." + nom]) nom = "ta." + nom;                 // anciens noms (version 4) : sma(…) = ta.sma(…)
      if (!TA[nom] && !SIMPLES[nom] && SIMPLES["math." + nom]) nom = "math." + nom;
      if (nom === "sum") nom = "math.sum";
      if (TA[nom]) { const a = nd.args.map(x => ev(x, port, cle)); for (const k in nd.noms) a.push(ev(nd.noms[k], port, cle)); return TA[nom](etat(cle + ":" + nd.id), a); }
      if (SIMPLES[nom]) { const a = nd.args.map(x => ev(x, port, cle)); if (nd.noms.transp !== undefined) a[1] = ev(nd.noms.transp, port, cle); return SIMPLES[nom](a); }
      if (nom === "input" || nom === "input.int" || nom === "input.float" || nom === "input.bool" || nom === "input.color" || nom === "input.string" || nom === "input.source" || nom === "input.timeframe" || nom === "input.symbol" || nom === "input.session" || nom === "input.price" || nom === "input.time" || nom === "input.text_area") {
        let type = nom === "input" ? null : nom.slice(6);
        if (type === "price") type = "float"; if (["timeframe", "symbol", "session", "text_area", "time"].includes(type)) type = "string";
        if (!type) { const d0 = nd.args[0] || nd.noms.defval; const v0 = d0 ? ev(d0, port, cle) : 0; type = d0 && d0.t === "nom" && serieIntegree(d0.v, 0) !== undefined ? "source" : typeof v0 === "boolean" ? "bool" : typeof v0 === "string" ? (rgbDe(v0) ? "color" : "string") : Number.isInteger(v0) ? "int" : "float"; }
        return entree(nd, port, cle, type);
      }
      if (nom === "indicator" || nom === "study" || nom === "strategy") {
        if (i === 0) { const { pos, noms } = evalArgs(nd, port, cle); res.titre = String(arg(SIGN.indicator, pos, noms, "title", res.titre)); res.court = String(arg(SIGN.indicator, pos, noms, "shorttitle", "") || ""); res.overlay = !!arg(SIGN.indicator, pos, noms, "overlay", false);
          if (nom === "strategy") averti("Les ordres de stratégie (strategy.entry…) ne sont pas exécutés : seuls les tracés s'affichent."); }
        return NA;
      }
      if (nom === "plot") {
        const { pos, noms } = evalArgs(nd, port, cle);
        let p = plots.get(cle + ":" + nd.id);
        if (!p) { p = { titre: String(arg(SIGN.plot, pos, noms, "title", "") || "Tracé " + (plots.size + 1)), data: new Array(n).fill(null), couleurs: new Array(n).fill(null), couleur: null,
            w: nombre(arg(SIGN.plot, pos, noms, "linewidth", 1)) || 1, style: String(arg(SIGN.plot, pos, noms, "style", "plot.style_line")), decalage: Math.round(nombre(arg(SIGN.plot, pos, noms, "offset", 0)) || 0) };
          plots.set(cle + ":" + nd.id, p); }
        const v = nombre(pos[0] !== undefined ? pos[0] : noms.series), col = arg(SIGN.plot, pos, noms, "color", null);
        const j = i + p.decalage; if (j >= 0 && j < n) { p.data[j] = estNa(v) ? null : v; p.couleurs[j] = estNa(col) ? null : col; }
        if (!p.couleur && typeof col === "string") p.couleur = col;
        return NA;
      }
      if (nom === "hline") {
        if (i === 0) { const { pos, noms } = evalArgs(nd, port, cle); const v = nombre(arg(SIGN.hline, pos, noms, "price", NA)); if (!estNa(v)) res.niveaux.push({ prix: v, titre: String(arg(SIGN.hline, pos, noms, "title", "") || ""), couleur: arg(SIGN.hline, pos, noms, "color", null) }); }
        return NA;
      }
      if (nom === "bgcolor") { const { pos, noms } = evalArgs(nd, port, cle), c = arg(SIGN.bgcolor, pos, noms, "color", null); if (typeof c === "string") res.fonds.push([i, c]); return NA; }
      if (nom === "request.security") { averti("request.security : la donnée est prise sur l'unité de temps affichée."); return nd.args[2] ? ev(nd.args[2], port, cle) : NA; }
      if (IGNORES.has(nom) || /^(label|line|box|table|array|matrix|map|strategy|polyline|chart\.point)\./.test(nom)) { averti(`« ${nom} » n'est pas encore affiché dans MaBoussole (ignoré).`); return NA; }
      erreur(`Fonction inconnue « ${nom} »`, nd.ligne);
    }

    function lireVar(nom, port, k) {
      const v = port.trouver(nom);
      if (v) { const j = i - k; return j < 0 ? NA : (v.vals[j] === undefined ? NA : v.vals[j]); }
      const s = serieIntegree(nom, k); if (s !== undefined) return s;
      if (nom === "ta.obv" || nom === "ta.vwap") return TA[nom](etat("intégré:" + nom), []);
      const c = constante(nom); if (c !== undefined) return c;
      erreur(`Nom inconnu « ${nom} »`, ligneCour);
    }
    function ev(nd, port, cle) {
      switch (nd.t) {
        case "val": return nd.v;
        case "nom": return lireVar(nd.v, port, 0);
        case "hist": {
          const k = Math.round(nombre(ev(nd.k, port, cle))); if (!(k >= 0)) return NA;
          if (nd.e.t === "nom") return lireVar(nd.e.v, port, k);
          const s = etat(cle + ":h" + nd.id), vals = s.vals || (s.vals = []); vals[i] = ev(nd.e, port, cle); return i - k >= 0 && vals[i - k] !== undefined ? vals[i - k] : NA;
        }
        case "appel": ligneCour = nd.ligne; return appel(nd, port, cle);
        case "tuple": return nd.el.map(e => ev(e, port, cle));
        case "tern": return vrai(ev(nd.c, port, cle)) ? ev(nd.a, port, cle) : ev(nd.b, port, cle);
        case "ou": return vrai(ev(nd.g, port, cle)) || vrai(ev(nd.d, port, cle));
        case "et": return vrai(ev(nd.g, port, cle)) && vrai(ev(nd.d, port, cle));
        case "non": return !vrai(ev(nd.e, port, cle));
        case "neg": return -nombre(ev(nd.e, port, cle));
        case "bin": {
          const a = ev(nd.g, port, cle), b = ev(nd.d, port, cle);
          if (nd.o === "+" && (typeof a === "string" || typeof b === "string")) return String(a) + String(b);
          if (nd.o === "==") return typeof a === "string" || typeof b === "string" || typeof a === "boolean" ? a === b : nombre(a) === nombre(b);
          if (nd.o === "!=") return typeof a === "string" || typeof b === "string" || typeof a === "boolean" ? a !== b : !(nombre(a) === nombre(b));
          const x = nombre(a), y = nombre(b);
          switch (nd.o) { case "+": return x + y; case "-": return x - y; case "*": return x * y; case "/": return y === 0 ? NA : x / y; case "%": return x % y; case "<": return x < y; case ">": return x > y; case "<=": return x <= y; case ">=": return x >= y; }
        }
      }
      erreur("Expression non comprise", nd.ligne);
    }
    function affecter(port, nom, v, local) {
      let x = local ? port.vars.get(nom) : port.trouver(nom);
      if (!x) { x = { vals: [] }; port.vars.set(nom, x); }
      x.vals[i] = v; return v;
    }
    function executerInstr(ins, port, cle) {
      ligneCour = ins.ligne || ligneCour;
      switch (ins.t) {
        case "rien": case "fonc": return NA;
        case "expr": return ev(ins.e, port, cle);
        case "decl": {
          let x = port.vars.get(ins.nom);
          if (ins.persistant) { if (!x || !x.init) { const v = ev(ins.e, port, cle); x = x || { vals: [] }; x.init = true; x.persistant = true; port.vars.set(ins.nom, x); x.vals[i] = v; } return x.vals[i]; }
          return affecter(port, ins.nom, ev(ins.e, port, cle), true);
        }
        case "affect": {
          const x = port.trouver(ins.nom); if (!x) erreur(`« ${ins.nom} » doit d'abord être déclarée avec « = »`, ins.ligne);
          let v = ev(ins.e, port, cle);
          if (ins.op !== ":=") { const a = nombre(x.vals[i]), b = nombre(v); v = ins.op === "+=" ? a + b : ins.op === "-=" ? a - b : ins.op === "*=" ? a * b : ins.op === "/=" ? a / b : a % b; }
          x.vals[i] = v; return v;
        }
        case "tuple": { const v = ev(ins.e, port, cle); if (!Array.isArray(v)) erreur("Cette fonction ne renvoie pas plusieurs valeurs", ins.ligne); ins.noms.forEach((nm, k) => affecter(port, nm, v[k], true)); return v; }
        case "si": {
          let r = NA;
          if (vrai(ev(ins.c, port, cle))) { for (const s of ins.alors) r = executerInstr(s, port, cle); }
          else if (ins.sinon) { for (const s of ins.sinon) r = executerInstr(s, port, cle); }
          return r;
        }
        case "pour": {
          const de = nombre(ev(ins.de, port, cle)), a = nombre(ev(ins.a, port, cle)), pas = ins.pas ? Math.abs(nombre(ev(ins.pas, port, cle))) || 1 : 1;
          let r = NA, tours = 0; const sens = a >= de ? 1 : -1;
          for (let k = de; sens > 0 ? k <= a : k >= a; k += sens * pas) { if (++tours > 5000) erreur("Boucle trop longue (plus de 5000 tours)", ins.ligne); affecter(port, ins.v, k, true); for (const s of ins.corps) r = executerInstr(s, port, cle); }
          return r;
        }
      }
      return NA;
    }

    for (const ins of prog.instr) if (ins.t === "fonc") fonctions.set(ins.nom, ins);
    const toutesPortees = () => [globale, ...portees.values()];
    for (i = 0; i < n; i++) {
      for (const p of toutesPortees()) for (const x of p.vars.values()) if (x.persistant && i > 0) x.vals[i] = x.vals[i - 1];   // les « var » gardent leur valeur
      for (const ins of prog.instr) executerInstr(ins, globale, "g");
    }
    if (!n) for (const ins of prog.instr) if (ins.t === "expr" && ins.e.t === "appel" && /^(indicator|study|strategy)$/.test(ins.e.nom)) { i = 0; try { executerInstr(ins, globale, "g"); } catch (e) { /* rien */ } }
    res.plots = [...plots.values()].map(p => {
      const st = p.style, hist = /histogram|columns|area/.test(st), points = /circles|cross/.test(st);
      const unie = p.couleurs.every(c => c === null || c === p.couleur);
      return { titre: p.titre, data: p.data, couleur: p.couleur || "#2962FF", couleurs: unie ? null : p.couleurs.map(c => c || p.couleur || "#2962FF"), w: Math.min(4, Math.max(1, p.w)), type: hist ? "hist" : "ligne", points };
    });
    return res;
  }

  racine.MBPine = { analyser, executer, PineErreur };
  if (typeof module !== "undefined") module.exports = racine.MBPine;
})(typeof window !== "undefined" ? window : globalThis);
