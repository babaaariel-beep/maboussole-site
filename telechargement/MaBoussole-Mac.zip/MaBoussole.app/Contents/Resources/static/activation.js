"use strict";
  const $ = s => document.querySelector(s);
  const ouvrir = () => setTimeout(() => location.href = "/", 800);
  function afficher(e) {
    if (e.ok) { location.href = "/"; return; }
    $("#machine").textContent = e.machine || "?";
    $("#jours").textContent = e.essai_jours || 3;
    for (const a of [$("#acheter"), $("#acheter2")]) a.href = e.site || "#";
    $("#blocEssai").hidden = !e.essai_possible;
    $("#blocFini").hidden = !e.essai_termine;
    $("#lienAchat").hidden = !e.site || !!e.essai_termine;
    if (e.essai_termine) $("#intro").textContent = "Merci d'avoir essayé MaBoussole Graphiques.";
    if (e.raison && !/pas encore activé|essai gratuit/.test(e.raison)) $("#raison").textContent = "Clé actuelle refusée : " + e.raison;
  }
  fetch("/api/licence").then(r => r.json()).then(afficher).catch(() => { $("#machine").textContent = "serveur injoignable"; });

  $("#essayer").onclick = async () => {
    $("#essayer").disabled = true; $("#msgEssai").style.color = ""; $("#msgEssai").textContent = "Démarrage de l'essai…";
    try {
      const r = await (await fetch("/api/licence/essai", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
      if (r.ok && r.licence.ok) { $("#msgEssai").style.color = "var(--vert)"; $("#msgEssai").textContent = "Essai gratuit démarré ✓ Ouverture…"; ouvrir(); return; }
      if (r.licence) afficher(r.licence);
      $("#msgEssai").style.color = "var(--rouge)"; $("#msgEssai").textContent = r.message || (r.licence && r.licence.raison) || "Essai impossible.";
    } catch (x) { $("#msgEssai").style.color = "var(--rouge)"; $("#msgEssai").textContent = "Serveur injoignable."; }
    $("#essayer").disabled = false;
  };

  $("#activer").onclick = async () => {
    $("#msg").style.color = ""; $("#msg").textContent = "Vérification…";
    try {
      const r = await (await fetch("/api/licence/activer", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ cle: $("#cle").value }) })).json();
      if (r.ok && r.licence.ok) { $("#msg").style.color = "var(--vert)"; $("#msg").textContent = "Activé ✓ Ouverture…"; ouvrir(); return; }
      $("#msg").style.color = "var(--rouge)"; $("#msg").textContent = r.message || (r.licence && r.licence.raison) || "Clé refusée.";
    } catch (x) { $("#msg").style.color = "var(--rouge)"; $("#msg").textContent = "Serveur injoignable."; }
  };
