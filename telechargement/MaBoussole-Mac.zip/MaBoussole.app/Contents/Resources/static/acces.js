"use strict";
  document.getElementById("f").onsubmit = async e => {
    e.preventDefault();
    const b = document.getElementById("b"), err = document.getElementById("err");
    b.disabled = true; err.textContent = "";
    try {
      const r = await fetch("/api/acces", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code: document.getElementById("code").value }) });
      const j = await r.json();
      if (j.ok) { location.href = "/"; return; }
      err.textContent = j.message || "Accès refusé.";
    } catch (x) { err.textContent = "Serveur injoignable. Le PC de l'administrateur est-il allumé ?"; }
    b.disabled = false;
  };
