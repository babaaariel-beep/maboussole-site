/* MaBoussole Graphiques : langue de l'interface (français / anglais).
   La page est écrite en français ; en anglais, ce fichier remplace les textes affichés (textes, infobulles, champs, dessins du graphique).
   Le choix est gardé sur ce PC (menu du compte → Langue). */
(function () {
  "use strict";
  let langue = "fr";
  try { langue = localStorage.getItem("mbgLangue") || "fr"; } catch (e) { /* rien */ }
  if (langue !== "en") langue = "fr";
  window.MBG_LANGUE = langue;
  document.documentElement.setAttribute("translate", "no");          // le navigateur (Chrome, Edge) ne traduit jamais la page lui-même :
  document.documentElement.classList.add("notranslate");             // sa traduction se battrait avec celle du logiciel et bloquerait tout
  window.mbgChoisirLangue = l => { try { localStorage.setItem("mbgLangue", l === "en" ? "en" : "fr"); } catch (e) { /* rien */ } location.reload(); };
  window.mbgT = s => s;
  if (langue === "fr") return;
  document.documentElement.lang = "en";

  const EN = {
    // ---------------------------------------------------------------- barre du haut, menus
    "Indicateurs": "Indicators", "Comparer": "Compare", "Alerte": "Alert", "Replay": "Replay", "Partager": "Share", "Installer": "Install",
    "Marché fermé": "Market closed", "Marché ouvert": "Market open", "Mon compte": "My account", "Réglages": "Settings", "Réglages…": "Settings…",
    "Réglages du graphique": "Chart settings", "Plein écran (F11)": "Full screen (F11)", "Prendre une photo du graphique": "Take a snapshot of the chart",
    "Annuler (Ctrl+Z)": "Undo (Ctrl+Z)", "Rétablir (Ctrl+Y)": "Redo (Ctrl+Y)", "Type de graphique": "Chart type", "Unité de temps": "Timeframe", "Unité": "Timeframe",
    "Rechercher un actif (tapez simplement le nom au clavier)": "Search a symbol (just type its name)", "Rechercher un symbole": "Symbol search",
    "Symbole ou nom (ex. EURUSD, or, nasdaq)": "Symbol or name (e.g. EURUSD, gold, nasdaq)", "Symbole": "Symbol",
    "Disposition (plusieurs graphiques) et mises en page": "Layout (several charts) and saved layouts",
    "Enregistrer cette analyse (capture, stratégie, biais, notes)": "Save this analysis (snapshot, strategy, bias, notes)",
    "Comparer : afficher un autre actif sur ce graphique (en %)": "Compare: show another symbol on this chart (in %)",
    "Créer une alerte de prix (puis touchez le niveau sur le graphique)": "Create a price alert (then click the level on the chart)",
    "Replay : rejouer le marché bougie par bougie": "Replay: replay the market bar by bar", "Choisir la bougie de départ": "Pick the starting bar",
    "Reculer d'une bougie (←)": "Step back one bar (←)", "Lecture / pause (espace)": "Play / pause (space)", "Avancer d'une bougie (→)": "Step forward one bar (→)",
    "Vitesse": "Speed", "Aller à une date": "Go to a date", "Aller à cette date": "Go to this date", "Quitter le replay et revenir au direct": "Exit replay and go back to live",
    "Admin : partager sur le réseau local avec des codes d'accès": "Admin: share on the local network with access codes",
    "Installer MaBoussole Graphiques sur ce PC (application, menu Démarrer, bureau)": "Install MaBoussole Graphiques on this PC (app, Start menu, desktop)",
    "Nouvel onglet : ouvrir un autre actif (Ctrl + T)": "New tab: open another symbol (Ctrl + T)", "Onglets de graphiques": "Chart tabs",
    "Ouvrir un actif dans un nouvel onglet": "Open a symbol in a new tab", "Dupliquer l'onglet": "Duplicate tab", "Fermer l'onglet": "Close tab",
    "Fermer les autres onglets": "Close other tabs", "Fermer les onglets à droite": "Close tabs to the right",
    "Bougies": "Candles", "Bougies creuses": "Hollow candles", "Heikin Ashi": "Heikin Ashi", "Barres": "Bars", "Ligne": "Line", "Ligne avec marqueurs": "Line with markers",
    "Ligne en escalier": "Step line", "Zone": "Area", "Ligne de base": "Baseline", "Colonnes": "Columns",
    "Toutes les unités de temps (ou tapez un nombre au clavier : 5, 45, 2h, 15s, 3M…)": "All timeframes (or type a number: 5, 45, 2h, 15s, 3M…)",
    "Unité personnalisée": "Custom timeframe", "Retirer cette unité personnalisée": "Remove this custom timeframe", "Ajouter à la barre": "Add to toolbar",
    "Retirer de la barre": "Remove from toolbar", "Unité impossible :": "Invalid timeframe:", "Secondes": "Seconds", "Minutes": "Minutes", "Heures": "Hours",
    "Jours": "Days", "Semaines": "Weeks", "Mois": "Months", "Direct": "Live", "Temps réel": "Real time", "temps réel": "real time",
    "Sauvegarder la mise en page": "Save layout", "Sauvegarde automatique": "Autosave", "Partager la mise en page (fichier)…": "Share layout (file)…",
    "Créer une copie…": "Make a copy…", "Renommer…": "Rename…", "Télécharger les données du graphique…": "Download chart data…",
    "＋ Créer une nouvelle mise en page…": "＋ Create new layout…", "Importer une mise en page…": "Import layout…", "Récemment utilisé": "Recently used",
    "Ouvrir la mise en page…": "Open layout…", "Ouvrir la mise en page": "Open layout", "Sans nom": "Unnamed", "Rechercher": "Search", "Fermer": "Close",
    "Nom de la mise en page :": "Layout name:", "Nom de la copie :": "Copy name:", "Nouveau nom de la mise en page :": "New layout name:",
    "Nom de la nouvelle mise en page :": "New layout name:", "Nom de la mise en page importée :": "Imported layout name:",
    "Aucune mise en page enregistrée. Utilisez « Sauvegarder la mise en page » (Ctrl + S).": "No saved layout. Use “Save layout” (Ctrl + S).",
    "Mise en page": "Layout",
    "Mises en page": "Layouts", "Aucune mise en page enregistrée.": "No saved layout.", "Synchroniser le curseur entre les graphiques": "Sync crosshair between charts",
    "Ouvrir sur le graphique principal (avec tous les outils)": "Open on the main chart (with all tools)", "Changer d'actif": "Change symbol",
    "Fuseau horaire": "Time zone", "Fuseau horaire du graphique (cliquer pour changer)": "Chart time zone (click to change)", "Heure de ce PC": "This PC's time",
    "Plus d'outils": "More tools", "Récemment utilisé": "Recently used", "Paramètres": "Settings", "Paramètres…": "Settings…",
    // ---------------------------------------------------------------- outils de dessin
    "Curseur": "Cursor", "Croix": "Cross", "Point": "Dot", "Démonstration": "Demonstration", "Gomme": "Eraser",
    "Lignes": "Lines", "Ligne de tendance": "Trend line", "Rayon": "Ray", "Ligne d'info": "Info line", "Ligne étendue": "Extended line", "Angle de tendance": "Trend angle",
    "Ligne horizontale": "Horizontal line", "Rayon horizontal": "Horizontal ray", "Ligne verticale": "Vertical line", "Ligne transversale": "Cross line",
    "Canaux": "Channels", "Canal parallèle": "Parallel channel", "Tendance régressive": "Regression trend", "Haut/bas plat": "Flat top/bottom", "Canal disjoint": "Disjoint channel",
    "Fourches": "Pitchforks", "Fourche": "Pitchfork", "Fourche de Schiff": "Schiff pitchfork", "Fourche de Schiff modifiée": "Modified Schiff pitchfork", "Fourche intérieure": "Inside pitchfork",
    "Fibonacci": "Fibonacci", "Retracement de Fibonacci": "Fib retracement", "Extension de Fibonacci basée sur la tendance": "Trend-based Fib extension",
    "Canal de Fibonacci": "Fib channel", "Zone temporelle de Fibonacci": "Fib time zone", "Éventail de résistance de vitesse": "Fib speed resistance fan",
    "Temps de Fibonacci basé sur la tendance": "Trend-based Fib time", "Cercles de Fibonacci": "Fib circles", "Spirale de Fibonacci": "Fib spiral",
    "Arcs de résistance de vitesse": "Fib speed resistance arcs", "Coin de Fibonacci": "Fib wedge", "Éventail de fourche": "Pitchfan",
    "Gann": "Gann", "Boîte de Gann": "Gann box", "Carré de Gann": "Gann square", "Éventail de Gann": "Gann fan",
    "Motifs graphiques": "Chart patterns", "Motif XABCD": "XABCD pattern", "Motif de chiffrement (Cypher)": "Cypher pattern", "Tête et épaules": "Head and shoulders",
    "Motif ABCD": "ABCD pattern", "Motif en triangle": "Triangle pattern", "Motif « Three Drives »": "Three drives pattern",
    "Vagues d'Elliott": "Elliott waves", "Vague d'impulsion d'Elliott (1-2-3-4-5)": "Elliott impulse wave (1-2-3-4-5)", "Vague de correction d'Elliott (A-B-C)": "Elliott correction wave (A-B-C)",
    "Vague triangulaire d'Elliott (A-B-C-D-E)": "Elliott triangle wave (A-B-C-D-E)", "Double vague combinée d'Elliott (W-X-Y)": "Elliott double combo wave (W-X-Y)",
    "Vague triple combo d'Elliott (W-X-Y-X-Z)": "Elliott triple combo wave (W-X-Y-X-Z)", "Cycles": "Cycles", "Lignes cycliques": "Cyclic lines", "Cycles de temps": "Time cycles",
    "Ligne sinusoïdale": "Sine line", "Prévisions": "Forecasting", "Position longue": "Long position", "Position courte": "Short position", "Prévision de position": "Forecast",
    "Ghost feed (double-clic pour finir)": "Ghost feed (double-click to finish)", "Profil de volume ancré": "Anchored volume profile", "Profil de volume à gamme fixe": "Fixed range volume profile",
    "VWAP ancré": "Anchored VWAP", "Basé sur le volume": "Volume-based", "Mesureurs": "Measurers", "Plage de prix": "Price range", "Plage de dates": "Date range",
    "Plage de date et de prix": "Date and price range", "Règle : glisser pour mesurer": "Ruler: drag to measure", "Formes": "Shapes", "Brosse": "Brush", "Brosses": "Brushes",
    "Surligneur": "Highlighter", "Flèche": "Arrow", "Flèches": "Arrows", "Marqueur fléché": "Arrow marker", "Flèche vers le haut": "Arrow up", "Flèche vers le bas": "Arrow down",
    "Rectangle": "Rectangle", "Rectangle pivoté": "Rotated rectangle", "Chemin": "Path", "Cercle": "Circle", "Ellipse": "Ellipse", "Polyligne": "Polyline", "Triangle": "Triangle",
    "Arc": "Arc", "Courbe": "Curve", "Double courbe": "Double curve", "Secteur": "Sector", "Zone prolongée à droite (offre / demande)": "Zone extended to the right (supply / demand)",
    "Texte et notes": "Text and notes", "Texte": "Text", "Note": "Note", "Note de prix": "Price note", "Épingle": "Pin", "Tableau": "Table", "Callout": "Callout",
    "Commentaire": "Comment", "Étiquette de prix": "Price label", "Panneau": "Signpost", "Marque de drapeau": "Flag mark", "Image": "Image", "Icône": "Icon", "Icônes": "Icons",
    "Emojis": "Emojis", "Gestes et émoticônes": "Gestures and emoticons", "Symboles et drapeaux": "Symbols and flags", "Nature": "Nature", "Motif à barres": "Bars pattern",
    "Zoom avant (glisser sur la zone)": "Zoom in (drag over the area)", "Zoom arrière (revenir)": "Zoom out (go back)", "Mode aimant": "Magnet mode",
    "Aimant faible": "Weak magnet", "Aimant fort": "Strong magnet", "Masquer tous les dessins": "Hide all drawings", "Masquer tous les indicateurs": "Hide all indicators",
    "Masquer dessins et indicateurs": "Hide drawings and indicators", "Tout masquer": "Hide all", "Tout afficher": "Show all", "Supprimer les dessins": "Remove drawings",
    "Supprimer dessins et indicateurs": "Remove drawings and indicators", "Verrouiller tous les dessins": "Lock all drawings", "Favoris": "Favorites",
    "Ajoutés à la main": "Added manually", "Arborescence des objets": "Object tree", "Fenêtre de données": "Data window", "Liste de suivi": "Watchlist",
    // ---------------------------------------------------------------- barre flottante et fenêtre de style des dessins
    "Supprimer": "Remove", "Modèle ▾": "Template ▾", "Modèle": "Template", "Verrouiller": "Lock", "Déverrouiller": "Unlock", "Masquer": "Hide", "Afficher": "Show",
    "Style": "Style", "Coordonnées": "Coordinates", "Visibilité": "Visibility", "Couleur": "Color", "Épaisseur": "Thickness", "Plein": "Solid", "Tirets": "Dashed",
    "Pointillés": "Dotted", "Pointillé": "Dotted", "Normale": "Normal", "Comportement": "Behavior", "Verrouiller (ne peut plus être déplacé)": "Lock (can no longer be moved)",
    "Masquer ce dessin": "Hide this drawing", "Prix": "Price", "Date et heure": "Date and time", "Annuler": "Cancel", "D'accord": "OK", "OK": "OK",
    "Afficher ce dessin sur ces unités de temps": "Show this drawing on these timeframes", "Toutes": "All", "Seulement": "Only",
    "Modifier le texte (ou double-clic sur le texte)": "Edit text (or double-click the text)", "Enregistrer ce style ou appliquer un style enregistré": "Save this style or apply a saved style",
    "Appliquer ce style au dessin": "Apply this style to the drawing", "Utiliser par défaut pour les nouveaux dessins": "Use as default for new drawings",
    "Modèle par défaut : utilisé pour chaque nouveau dessin (cliquer pour retirer)": "Default template: used for every new drawing (click to remove)",
    "Supprimer ce modèle": "Delete this template", "Nom du modèle (ex. Support bleu)": "Template name (e.g. Blue support)", "Nom du modèle :": "Template name:", "Mon modèle": "My template",
    "Enregistrer": "Save", "Zone d'objectif (gain)": "Target zone (profit)", "Zone de stop (perte)": "Stop zone (loss)", "Ligne d'entrée": "Entry line",
    "Opacité des zones": "Zones opacity", "Épaisseur de la ligne d'entrée": "Entry line thickness", "Calcul": "Calculation", "Taille du compte": "Account size",
    "Risque (% du compte)": "Risk (% of account)", "Afficher les étiquettes (objectif, stop, ratio, quantité)": "Show labels (target, stop, ratio, quantity)",
    "Entrée": "Entry", "Stop": "Stop", "Objectif": "Target", "Fin de la zone": "End of zone", "Couleurs": "Colors", "Couleurs du texte": "Text colors", "Taille": "Size",
    // Fibonacci
    "Ligne des niveaux": "Levels line", "Prolonger": "Extend", "Ne pas élargir": "Don't extend", "Prolonger à gauche": "Extend left", "Prolonger à droite": "Extend right",
    "Prolonger des deux côtés": "Extend both", "Utiliser une couleur": "Use one color", "Arrière-plan": "Background", "Inverser": "Reverse", "Niveaux": "Levels",
    "Valeurs": "Values", "Pourcentages": "Percents", "Étiquettes": "Labels", "Gauche": "Left", "Centre": "Center", "Droite": "Right", "Haut": "Top", "Milieu": "Middle",
    "Bas": "Bottom", "Taille du texte": "Text size", "+ Ajouter un niveau": "+ Add level", "Niveaux par défaut": "Default levels", "Supprimer ce niveau": "Delete this level",
    "Afficher ce niveau": "Show this level", "Valeur du niveau (modifiable)": "Level value (editable)", "Couleur du niveau": "Level color",
    "Opacité de l'arrière-plan": "Background opacity", "0.5 équilibre": "0.5 equilibrium",
    // ---------------------------------------------------------------- indicateurs
    "Séances": "Sessions", "Séances (Asie, Londres, New York)": "Sessions (Asia, London, New York)", "Killzones": "Killzones",
    "Killzones (Asie 0-4h, Londres 7-10h, New York 12-15h UTC)": "Killzones (Asia 0-4h, London 7-10h, New York 12-15h UTC)",
    "Ouverture New York 8h30 (NYO)": "New York open 8:30 (NYO)", "Points pivots classiques (journaliers)": "Classic pivot points (daily)", "Pivots": "Pivots",
    "Plus haut / plus bas de la veille (PDH / PDL)": "Previous day high / low (PDH / PDL)", "Plus haut / plus bas de la semaine précédente (PWH / PWL)": "Previous week high / low (PWH / PWL)",
    "Premium / Discount (zones ICT : prime, équilibre, décote)": "Premium / Discount (ICT zones: premium, equilibrium, discount)", "Premium / Discount": "Premium / Discount",
    "Volume": "Volume", "Vol": "Vol", "Moyenne mobile simple": "Simple moving average", "Moyenne mobile exponentielle": "Exponential moving average",
    "Moyenne mobile pondérée": "Weighted moving average", "MM": "SMA", "MME": "EMA", "MMP": "WMA", "VWAP (prix moyen pondéré par le volume, journalier)": "VWAP (volume weighted average price, daily)",
    "Bandes de Bollinger": "Bollinger Bands", "Canaux de Keltner": "Keltner Channels", "Canaux de Donchian": "Donchian Channels", "Enveloppe": "Envelope", "Env": "Env",
    "Ichimoku Kinko Hyo": "Ichimoku Kinko Hyo", "SAR parabolique": "Parabolic SAR", "Supertrend": "Supertrend", "RSI (indice de force relative)": "RSI (relative strength index)",
    "Stochastique": "Stochastic", "RSI stochastique": "Stochastic RSI", "CCI (indice du canal des matières premières)": "CCI (commodity channel index)",
    "ADX / DMI (mouvement directionnel)": "ADX / DMI (directional movement)", "%R de Williams": "Williams %R", "Momentum": "Momentum", "Mom": "Mom",
    "Taux de variation (ROC)": "Rate of change (ROC)", "Awesome Oscillator": "Awesome Oscillator", "ATR (amplitude moyenne réelle)": "ATR (average true range)",
    "OBV (volume équilibré)": "OBV (on balance volume)", "MFI (indice du flux monétaire)": "MFI (money flow index)", "Tendance": "Trend", "Oscillateurs": "Oscillators",
    "Volatilité": "Volatility", "Calendrier": "Calendar", "Calendrier du propriétaire": "Owner's calendar", "Période": "Period", "Écart-type": "Std deviation",
    "Multiplicateur": "Multiplier", "Écart (%)": "Offset (%)", "Tenkan (conversion)": "Tenkan (conversion)", "Kijun (base)": "Kijun (base)", "Senkou B": "Senkou B",
    "Pas": "Step", "Maximum": "Maximum", "Moyenne rapide": "Fast length", "Moyenne lente": "Slow length", "Signal": "Signal", "Lissage %K": "%K smoothing",
    "Période RSI": "RSI length", "Période stochastique": "Stochastic length", "Lignes du 1er, du 15 et du 25": "Lines on the 1st, 15th and 25th",
    "Fond coloré des phases": "Colored phase background", "Nom des phases": "Phase names",
    "Taille des zones premium et discount (% de l'amplitude, 50 = deux moitiés)": "Premium and discount zone size (% of range, 50 = two halves)",
    "Bande d'équilibre (% de l'amplitude)": "Equilibrium band (% of range)", "Opacité du fond (%)": "Background opacity (%)",
    "Couleur premium (cher, zone de vente)": "Premium color (expensive, sell zone)", "Couleur équilibre (50 %)": "Equilibrium color (50 %)",
    "Couleur discount (bon marché, zone d'achat)": "Discount color (cheap, buy zone)", "Afficher les noms des zones": "Show zone names",
    "Afficher les prix (haut, 50 %, bas)": "Show prices (high, 50 %, low)", "Prolonger les zones vers la droite": "Extend zones to the right",
    "Premium": "Premium", "Discount": "Discount", "Équilibre": "Equilibrium", "Revenir aux réglages par défaut": "Reset to defaults", "Asie": "Asia", "Londres": "London",
    "Asie KZ": "Asia KZ", "Londres KZ": "London KZ", "New York KZ": "New York KZ", "NYO 8:30": "NYO 8:30", "est déjà sur le graphique.": "is already on the chart.",
    "ajouté.": "added.",
    // ---------------------------------------------------------------- volet de droite, liste de suivi, panneau du bas
    "Dernier": "Last", "Var.": "Chg", "Var. %": "Chg %", "Ajouter un actif": "Add symbol", "Ajouter à la liste de suivi": "Add to watchlist", "Forex": "Forex",
    "Matières premières": "Commodities", "Indices": "Indices", "Crypto": "Crypto", "Autres": "Others", "% aujourd'hui": "% today", "ajouté à la liste de suivi": "added to watchlist",
    "est déjà dans la liste de suivi": "is already in the watchlist", "Panneau de trading": "Trading panel", "Testeur de stratégie": "Strategy tester",
    "Liste des trades": "List of trades", "Mes analyses": "My analyses", "Alertes": "Alerts", "Mes backtests": "My backtests", "Positions": "Positions",
    "Acheter": "Buy", "Vendre": "Sell", "ACHETER": "BUY", "VENDRE": "SELL", "Achat": "Buy", "Vente": "Sell", "Au marché": "Market", "Limite / stop": "Limit / stop",
    "Ordre": "Order", "Ordre simulé": "Simulated order", "Sens": "Side", "Prix d'entrée": "Entry price", "Résultat": "Result", "Clôture": "Close",
    "Les positions restent simulées : aucun ordre réel n'est envoyé.": "Positions are simulated: no real order is sent.",
    "Aucune position. Utilisez Acheter / Vendre, les boutons du graphique, ou les outils « position acheteuse / vendeuse ».": "No positions. Use Buy / Sell, the chart buttons, or the long / short position tools.",
    "Annuler la position": "Cancel position", "Ratio R/R :": "R/R ratio:", "Stop :": "Stop:", "Objectif :": "Target:",
    "Nouveau backtest": "New backtest", "Nom du backtest": "Backtest name", "Terminer ce backtest": "End this backtest", "Tous les backtests": "All backtests",
    "Toutes les stratégies": "All strategies", "Tous les résultats": "All results", "Stratégie": "Strategy", "Total des trades": "Total trades", "Réussite": "Win rate",
    "Pourcentage de réussite": "Win rate", "Total en R": "Total in R", "Espérance": "Expectancy", "Facteur de profit": "Profit factor", "Drawdown max": "Max drawdown",
    "Bénéfice net": "Net profit", "Gain moyen / perte moyenne": "Avg win / avg loss", "Trade moyen (espérance)": "Average trade (expectancy)",
    "Courbe des résultats (R cumulés)": "Equity curve (cumulative R)", "Par stratégie": "By strategy", "Par actif": "By symbol", "Par séance": "By session",
    "Par unité de temps": "By timeframe", "Par jour": "By day", "Gagnantes": "Winners", "Perdantes": "Losers", "Annulées": "Cancelled",
    "Gagnante": "Win", "Perdante": "Loss", "Nulle (BE)": "Breakeven", "Annulée": "Cancelled", "En attente": "Pending", "Haussier": "Bullish", "Baissier": "Bearish", "Neutre": "Neutral",
    "Biais": "Bias", "Notes": "Notes", "Titre": "Title", "Ajouter un trade": "Add trade", "Trade ajouté.": "Trade added.", "Résultat en R": "Result in R",
    "Résultat en R (facultatif)": "Result in R (optional)", "Garder les trades": "Keep trades", "Supprimer les trades": "Delete trades",
    "Espérance positive sur un échantillon suffisant : la stratégie a un avantage mesuré.": "Positive expectancy on a sufficient sample: the strategy has a measured edge.",
    "Espérance faiblement positive : avantage fragile (écart et commissions non comptés).": "Slightly positive expectancy: fragile edge (spread and commissions not counted).",
    "Espérance négative : cette stratégie perd sur ce backtest.": "Negative expectancy: this strategy loses on this backtest.",
    "Winrate des analyses": "Analyses win rate", "Enregistrer l'analyse": "Save analysis", "Modifier l'analyse": "Edit analysis", "Analyse modifiée.": "Analysis updated.",
    "Analyse enregistrée : retrouvez-la dans « Mes analyses ».": "Analysis saved: find it in « My analyses ».", "Ouvrir sur le graphique": "Open on the chart",
    "Règles de la stratégie (facultatif)": "Strategy rules (optional)", "Conditions d'entrée, stop, objectif, séances…": "Entry conditions, stop, target, sessions…",
    "Contexte, confluences, plan d'entrée, ce que j'ai appris…": "Context, confluences, entry plan, what I learned…", "ex. Cassure de Londres": "e.g. London breakout",
    "ex. Cassure de Londres sur l'or, janvier à juin": "e.g. London breakout on gold, January to June", "ex. Vente sur la zone premium": "e.g. Sell in the premium zone",
    "ex. 2 (gagné) ou -1 (perdu)": "e.g. 2 (won) or -1 (lost)", "ex. 2 ou -1": "e.g. 2 or -1", "Indiquez la date du trade.": "Enter the trade date.",
    "Indiquez le résultat en R (ex. 2 pour un gain de 2R, -1 pour une perte).": "Enter the result in R (e.g. 2 for a 2R win, -1 for a loss).",
    "Aucune analyse enregistrée. Préparez votre graphique (dessins, niveaux), puis cliquez sur 💾 en haut ou sur « Enregistrer l'analyse en cours » : la capture, l'actif, la date, vos dessins, la stratégie et vos notes sont gardés. Indiquez ensuite si elle a été gagnante ou perdante pour suivre votre winrate.": "No saved analysis. Prepare your chart (drawings, levels), then click 💾 at the top: the snapshot, symbol, date, drawings, strategy and notes are kept. Then mark it as a win or a loss to track your win rate.",
    "Chaque position fermée est enregistrée ici. Vous pouvez aussi noter un trade fait ailleurs.": "Every closed position is recorded here. You can also log a trade taken elsewhere.",
    "Pas encore de trade. Lancez un replay sur n'importe lequel des 44 actifs, placez des positions : chaque position clôturée est enregistrée ici avec sa stratégie.": "No trades yet. Start a replay on any of the 44 symbols and place positions: every closed position is recorded here with its strategy.",
    "Aucun backtest en cours : le trade sera enregistré sans session.": "No backtest running: the trade will be saved without a session.",
    "Aucun backtest en cours : les trades sont enregistrés sans session.": "No backtest running: trades are saved without a session.",
    "Toutes les positions fermées (replay ou direct) et les trades ajoutés à la main seront rangés dans ce backtest jusqu'à ce que vous le terminiez.": "All closed positions (replay or live) and manually added trades will go into this backtest until you end it.",
    "Backtest terminé : ses résultats restent dans « Mes backtests ».": "Backtest ended: its results stay in « My backtests ».",
    "Le winrate compte les analyses gagnantes et perdantes (les nulles, annulées et en attente sont à part). Mettez à jour le résultat quand le trade se termine.": "The win rate counts winning and losing analyses (breakeven, cancelled and pending are separate). Update the result when the trade ends.",
    "Aucune alerte sur": "No alerts on", "Alerte de prix": "Price alert", "Événements": "Events", "Événement": "Event", "Impact fort": "High impact", "Impact moyen": "Medium impact",
    "Impact faible": "Low impact", "Calendrier économique": "Economic calendar", "à venir": "upcoming", "réel": "actual",
    // ---------------------------------------------------------------- réglages du graphique
    "Échelles et lignes": "Scales and lines", "Échelle": "Scale", "Échelles": "Scales", "Échelle des prix": "Price scale", "Échelle normale": "Regular scale",
    "Échelle logarithmique": "Logarithmic scale", "Échelle en pourcentage": "Percent scale", "Échelle indexée à 100": "Indexed to 100 scale", "Échelle inversée": "Inverted scale",
    "Logarithmique": "Logarithmic", "Pourcentage": "Percent", "Indexée à 100": "Indexed to 100", "Inverser l'échelle": "Invert scale",
    "Réglages de l'échelle": "Scale settings", "Réglages de l'échelle…": "Scale settings…", "Réinitialiser l'échelle des prix": "Reset price scale",
    "Réinitialiser l'affichage": "Reset chart view", "Ligne du dernier prix": "Last price line", "Étiquette du dernier prix": "Last price label",
    "Prix des dessins sur l'échelle": "Drawing prices on the scale", "Valeurs des indicateurs sur l'échelle": "Indicator values on the scale", "Ligne d'état": "Status line",
    "Compte à rebours de la bougie": "Bar countdown", "Colorer les bougies selon la clôture précédente": "Color bars based on previous close", "Variation de la bougie": "Bar change values",
    "Corps": "Body", "Bordures": "Borders", "Mèches": "Wicks", "Couleur unie": "Solid color", "Dégradé": "Gradient", "Couleur du fond": "Background color", "Fond": "Background",
    "Grille": "Grid", "Lignes horizontales": "Horizontal lines", "Lignes verticales": "Vertical lines", "Filigrane": "Watermark", "Toile": "Canvas", "Marges": "Margins",
    "Thème": "Theme", "Clair": "Light", "Sombre": "Dark", "Thème sombre": "Dark theme", "Graphique": "Chart", "Symbole ": "Symbol ", "Trading": "Trading",
    "Enregistrer les réglages comme modèle…": "Save settings as template…", "Par défaut": "Default", "Par défaut (selon l'actif)": "Default (per symbol)",
    "Données": "Data", "Courtier MetaTrader": "MetaTrader broker", "Courtier MetaTrader :": "MetaTrader broker:", "Utiliser MetaTrader 5 s'il est ouvert (bougies de votre broker)": "Use MetaTrader 5 when it is open (your broker's candles)",
    "Utiliser Deriv : cotations réelles d'un courtier, sans compte (recommandé)": "Use Deriv: real broker quotes, no account needed (recommended)",
    "Utiliser OANDA": "Use OANDA", "Données OANDA": "OANDA data", "Jeton personnel": "Personal token", "collez votre jeton ici": "paste your token here",
    "Vérifier et enregistrer": "Check and save", "Retirer le jeton": "Remove token", "Type de compte": "Account type", "compte démo gratuit": "free demo account", "démo": "demo",
    "Uniquement le temps réel : les actifs sans temps réel sont masqués.": "Real time only: symbols without real-time data are hidden.",
    "Uniquement les cotations temps réel (aucune cotation Yahoo ; les actifs sans temps réel sont masqués)": "Real-time quotes only (no Yahoo quotes; symbols without real-time data are hidden)",
    "Tous les actifs sont affichés (certains viennent de Yahoo, parfois en différé).": "All symbols are shown (some come from Yahoo, sometimes delayed).",
    "Pastilles en bas du graphique ; survolez-les pour voir l'heure, le réel, le prévu et le précédent. En replay, les annonces futures sont cachées.": "Dots at the bottom of the chart; hover them to see time, actual, forecast and previous. In replay, future releases are hidden.",
    "Réduire": "Collapse", "Agrandir": "Expand", "Fermer": "Close", "Retour": "Back", "Confirmer": "Confirm", "Continuer": "Continue", "Commencer": "Start", "Retirer": "Remove",
    "Retirer la comparaison": "Remove comparison", "Comparer un actif (affiché en %)": "Compare a symbol (shown in %)", "Actif": "Symbol", "Actif de ce graphique": "Symbol of this chart",
    "Retirez les actifs comparés pour changer d'échelle.": "Remove compared symbols to change the scale.",
    "3 actifs comparés au maximum : retirez-en un (✕ dans la légende).": "3 compared symbols at most: remove one (✕ in the legend).",
    "C'est déjà l'actif du graphique.": "This is already the chart's symbol.", "Aucun actif trouvé.": "No symbol found.",
    // ---------------------------------------------------------------- menu du compte, mise à jour
    "Accueil": "Home", "Centre d'aide": "Help center", "Demandes au support": "Support requests", "Quoi de neuf": "What's new", "Rechercher une mise à jour": "Check for updates",
    "Panneau de dessin": "Drawing panel", "Langue": "Language", "Raccourcis clavier": "Keyboard shortcuts", "Déconnexion": "Sign out", "Se déconnecter": "Sign out",
    "Propriétaire": "Owner", "Propriétaire · accès illimité": "Owner · unlimited access", "Accès illimité": "Unlimited access", "Accès jusqu'au": "Access until",
    "Essai gratuit": "Free trial", "h restantes": "h left", "Français": "Français", "English": "English",
    "Les clés achetées sur le site affichent ici l'e-mail du paiement.": "Keys bought on the website show the payment email here.",
    "Se déconnecter de ce PC ?\n\nPour revenir, il suffira de recoller votre clé d'activation (celle reçue par e-mail) : elle reste liée à ce PC.": "Sign out of this PC?\n\nTo come back, just paste your activation key again (the one you received by email): it stays linked to this PC.",
    "Nouvelle version disponible": "New version available", "Quoi de neuf :": "What's new:", "Mettre à jour": "Update", "Télécharger": "Download", "Plus tard": "Later",
    "La mise à jour se fait toute seule : MaBoussole redémarre en quelques secondes, vos dessins et réglages sont gardés.": "The update is automatic: MaBoussole restarts in a few seconds, your drawings and settings are kept.",
    "Téléchargez la nouvelle version, fermez MaBoussole puis lancez le fichier téléchargé.": "Download the new version, close MaBoussole, then run the downloaded file.",
    "Téléchargement de la nouvelle version…": "Downloading the new version…", "Installation…": "Installing…", "Redémarrage de MaBoussole…": "Restarting MaBoussole…",
    "Mise à jour terminée ✓": "Update complete ✓", "Vous avez déjà la dernière version ✓": "You already have the latest version ✓",
    "Cette copie (PC du propriétaire) est toujours à jour.": "This copy (owner's PC) is always up to date.", "Aucune note pour cette version.": "No notes for this version.",
    "Impossible de vérifier : pas de connexion Internet ?": "Could not check: no Internet connection?", "Votre version": "Your version",
    "Nouvelle version installée : rechargement…": "New version installed: reloading…", "Fermer": "Close",
    // ---------------------------------------------------------------- raccourcis
    "Maj : ligne droite": "Shift: straight line", "Maj en traçant : ligne droite (horizontale, verticale ou 45°), carré, cercle": "Shift while drawing: straight line (horizontal, vertical or 45°), square, circle",
    "Maj + glisser un dessin : déplacement horizontal ou vertical seulement": "Shift + drag a drawing: horizontal or vertical move only",
    "Ctrl en traçant ou en déplaçant un point : aimant temporaire": "Ctrl while drawing or moving a point: temporary magnet",
    "Ctrl + glisser un dessin : le dupliquer · Ctrl + clic : sélectionner plusieurs dessins": "Ctrl + drag a drawing: duplicate it · Ctrl + click: select several drawings",
    "Ctrl+C / Ctrl+V : copier / coller un dessin · Ctrl+Alt+H : masquer / afficher les dessins": "Ctrl+C / Ctrl+V: copy / paste a drawing · Ctrl+Alt+H: hide / show drawings",
    "Flèches : déplacer le dessin sélectionné (Maj : plus vite) · Suppr : supprimer": "Arrows: move the selected drawing (Shift: faster) · Del: delete",
    "Maj + clic : règle de mesure · Échap : annuler le dessin en cours": "Shift + click: measure ruler · Esc: cancel the drawing in progress",
    "Ctrl+T : nouvel onglet · Maj+R : replay (→ / ← / Espace pendant le replay)": "Ctrl+T: new tab · Shift+R: replay (→ / ← / Space during replay)",
    "Alt+T ligne de tendance · Alt+H horizontale · Alt+J rayon horizontal · Alt+V verticale · Alt+C croix · Alt+F Fibonacci · Alt+Maj+R rectangle · Alt+A alerte": "Alt+T trend line · Alt+H horizontal · Alt+J horizontal ray · Alt+V vertical · Alt+C cross · Alt+F Fibonacci · Alt+Shift+R rectangle · Alt+A alert",
    "Alt+G : aller à une date · Alt+R : réinitialiser la vue · Alt+S : capture · Alt+I : inverser · Alt+L : logarithmique · Alt+P : pourcentage · Alt+W : ajouter à la liste": "Alt+G: go to date · Alt+R: reset view · Alt+S: snapshot · Alt+I: invert · Alt+L: logarithmic · Alt+P: percent · Alt+W: add to watchlist",
    // ---------------------------------------------------------------- messages
    "Chargement…": "Loading…", "Chargement de l'historique plus ancien…": "Loading older history…", "Chargement de la suite de l'historique…": "Loading more history…",
    "Pas de données plus récentes disponibles pour cette période.": "No more recent data available for this period.", "Serveur injoignable.": "Server unreachable.",
    "serveur injoignable": "server unreachable", "échec": "failed", "Le replay est arrivé au présent.": "Replay reached the present.",
    "En replay, on ne peut pas regarder le futur : utilisez ▶ ou ⏭.": "In replay you cannot look at the future: use ▶ or ⏭.", "Cliquez sur la bougie de départ": "Click the starting bar",
    "Fermez d'abord vos positions pour revenir en arrière.": "Close your positions first to go back.", "Stop du mauvais côté : remis à sa place.": "Stop on the wrong side: put back in place.",
    "Pour un achat, le stop doit être sous l'entrée.": "For a buy, the stop must be below entry.", "Pour une vente, le stop doit être au-dessus de l'entrée.": "For a sell, the stop must be above entry.",
    "L'objectif doit être du côté du gain.": "The target must be on the profit side.", "Dessin supprimé · Ctrl+Z pour le récupérer": "Drawing deleted · Ctrl+Z to restore it",
    "Dessin supprimé (Ctrl+Z pour annuler)": "Drawing deleted (Ctrl+Z to undo)", "Dessin effacé avec la gomme · Ctrl+Z pour le récupérer": "Drawing erased · Ctrl+Z to restore it",
    "Dernier dessin annulé (Ctrl+Z) · Ctrl+Y pour le remettre": "Last drawing undone (Ctrl+Z) · Ctrl+Y to bring it back", "Action annulée (Ctrl+Z) · Ctrl+Y pour la refaire": "Action undone (Ctrl+Z) · Ctrl+Y to redo",
    "Rétabli": "Redone", "Dessin copié · Ctrl+V pour le coller": "Drawing copied · Ctrl+V to paste", "Dessin collé": "Drawing pasted", "Dessins affichés": "Drawings shown",
    "Dessins masqués · Ctrl+Alt+H pour les réafficher": "Drawings hidden · Ctrl+Alt+H to show them", "Vos dessins étaient masqués : ils sont de nouveau affichés.": "Your drawings were hidden: they are shown again.",
    "Dessin masqué : réaffichez-le depuis l'arborescence des objets (barre de droite).": "Drawing hidden: show it again from the object tree (right bar).",
    "Ce dessin est masqué (ou caché sur cette unité de temps).": "This drawing is hidden (or hidden on this timeframe).", "Image prête : tracez maintenant son cadre sur le graphique.": "Image ready: now draw its frame on the chart.",
    "Plein écran refusé": "Full screen refused", "Supprimer les dessins de": "Delete drawings of", "Confirmer la suppression": "Confirm deletion",
    "Tableau : colonnes séparées par | et lignes par « ; » (ex. Entrée|1.1020 ; Stop|1.0990)": "Table: columns separated by | and rows by « ; » (e.g. Entry|1.1020 ; Stop|1.0990)",
    "Texte :": "Text:", "Texte de l'épingle (facultatif) :": "Pin text (optional):", "Sans nom": "Untitled", "Sans limite": "No limit",
    "Quittez le replay pour ouvrir une analyse plus récente que le replay en cours.": "Exit replay to open an analysis more recent than the current replay.",
    "Retirez les actifs comparés pour changer de mode": "Remove compared symbols to change mode",
    // ---------------------------------------------------------------- activation, licence, accès invité, partage
    "Activation · MaBoussole Graphiques": "Activation · MaBoussole Graphiques", "Accès · MaBoussole Graphiques": "Access · MaBoussole Graphiques",
    "Essayer gratuitement": "Try for free", "J'ai une clé": "I have a key", "Activer": "Activate", "Acheter ma clé": "Buy my key", "Acheter une clé sur le site": "Buy a key on the website",
    "Essayez gratuitement, ou activez votre clé.": "Try it for free, or activate your key.", "Toutes les fonctions, sans paiement, pour voir comment ça marche. Une seule fois par PC.": "All features, no payment, to see how it works. Once per PC.",
    "Collez la clé reçue après votre paiement. Elle sera liée à ce PC et ne fonctionnera sur aucun autre.": "Paste the key you received after payment. It will be linked to this PC and won't work on any other.",
    "Code de ce PC (seulement si le vendeur vous le demande) :": "This PC's code (only if the seller asks for it):", "Votre essai gratuit est terminé": "Your free trial has ended",
    "Merci d'avoir essayé MaBoussole Graphiques.": "Thank you for trying MaBoussole Graphiques.",
    "Pour continuer, achetez votre clé sur le site : vous la recevez tout de suite après le paiement. Collez-la ensuite ci-dessous.": "To continue, buy your key on the website: you receive it right after payment. Then paste it below.",
    "Essai gratuit démarré ✓ Ouverture…": "Free trial started ✓ Opening…", "Activé ✓ Ouverture…": "Activated ✓ Opening…", "Essai impossible.": "Trial not possible.", "Clé refusée.": "Key refused.",
    "Vérification…": "Checking…", "Vérification en cours…": "Checking…", "Votre clé se termine dans": "Your key expires in", "jours": "days", "jusqu'au": "until",
    "Entrez le code d'accès personnel que l'administrateur vous a donné.": "Enter the personal access code the administrator gave you.", "Entrer": "Enter",
    "Le code est personnel : il ne fonctionne que sur le premier appareil qui l'utilise.": "The code is personal: it only works on the first device that uses it.",
    "Le PC qui partage MaBoussole Graphiques ne répond plus": "The PC sharing MaBoussole Graphiques is not responding",
    "Il est peut-être éteint, en veille ou déconnecté du réseau. Demandez à la personne qui vous a donné le code de le rallumer.": "It may be off, asleep or disconnected. Ask the person who gave you the code to turn it back on.",
    "Le logiciel MaBoussole Graphiques est arrêté sur ce PC": "MaBoussole Graphiques is stopped on this PC",
    "Ouvrez « MaBoussole Graphiques » depuis le menu Démarrer de Windows (ou son raccourci du Bureau) : il redémarre en quelques secondes.": "Open « MaBoussole Graphiques » from the Windows Start menu (or its desktop shortcut): it restarts in a few seconds.",
    "code d'accès requis": "access code required", "Mauvais code": "Wrong code", "Trop de requêtes": "Too many requests",
    "MaBoussole Graphiques est installé : il est dans le menu Démarrer et peut être épinglé à la barre des tâches.": "MaBoussole Graphiques is installed: it is in the Start menu and can be pinned to the taskbar.",
    "Partager MaBoussole Graphiques": "Share MaBoussole Graphiques", "Partager sur le réseau local": "Share on the local network", "Accès par le réseau local": "Local network access",
    "Nouveau code d'accès": "New access code", "Nom de la personne": "Person's name", "Nom de la personne (ex. Koffi)": "Person's name (e.g. Koffi)", "Créer le code": "Create code",
    "Aucun code. Créez-en un par personne.": "No codes. Create one per person.", "Codes": "Codes", "Révoqué": "Revoked", "Expiré": "Expired", "Désactivé": "Disabled",
    "Désactivé : personne d'autre ne peut se connecter.": "Disabled: nobody else can connect.", "Créée le": "Created on", "Dernière visite": "Last visit",
    "Révoquer ce code ? La personne perd l'accès tout de suite.": "Revoke this code? The person loses access immediately.",
    "Supprimer ce code ? La personne perd l'accès.": "Delete this code? The person loses access.",
    "Libérer ce code ? L'appareil actuel sera déconnecté et le code pourra être utilisé sur un nouvel appareil.": "Release this code? The current device will be disconnected and the code can be used on a new device.",
    "Journal de sécurité": "Security log", "Rien à signaler.": "Nothing to report.",
    // ---------------------------------------------------------------- divers
    "Bug de la page": "Page bug", "Bug du logiciel": "Software bug", "Bugs et pannes du logiciel": "Software bugs and failures", "Dessin": "Drawing", "Dessins": "Drawings",
    "Détail": "Details", "État": "Status", "Déplacer": "Move", "Dupliquer": "Duplicate", "Ajouter": "Add", "Analyses": "Analyses", "Mode": "Mode", "Date": "Date",
    "Contenu": "Content", "Devise": "Currency", "Ouverture": "Open", "Plus haut": "High", "Plus bas": "Low", "Amplitude": "Range", "Histogramme": "Histogram",
    "Longs tirets": "Long dashes", "Trait plein": "Solid line", "Exécution": "Execution", "Connexion": "Connection", "Blocage": "Block", "Panne": "Failure",
    "Ouvrir le dossier": "Open folder", "Ouvrir mon tableau de bord": "Open my dashboard", "Copier la clé": "Copy key", "Générer": "Generate", "Il reste": "Remaining",
    "Code machine": "Machine code", "Nombre de jours": "Number of days", "Date d'expiration": "Expiry date", "Nombre d'utilisations": "Number of uses",
    "1 jour": "1 day", "7 jours": "7 days", "30 jours": "30 days", "90 jours": "90 days", "Tous": "All", "Toutes": "All", "Variation": "Change",
    "Avec votre jeton personnel OANDA, les graphiques utilisent les": "With your personal OANDA token, charts use the", "vraies bougies d'OANDA": "real OANDA candles",
    "OANDA activé.": "OANDA enabled.", "OANDA désactivé : retour aux sources gratuites.": "OANDA disabled: back to free sources.",
    "OANDA activé : les graphiques utilisent maintenant les bougies d'OANDA.": "OANDA enabled: charts now use OANDA candles.", "Jeton OANDA retiré de ce PC.": "OANDA token removed from this PC.",
    "Deriv activé : cotations réelles.": "Deriv enabled: real quotes.", "MetaTrader 5 sera utilisé s'il est ouvert.": "MetaTrader 5 will be used when it is open.",
    // ---------------------------------------------------------------- actifs
    "Dollar américain": "US Dollar", "Euro": "Euro", "Livre sterling": "British Pound", "Yen japonais": "Japanese Yen", "Franc suisse": "Swiss Franc",
    "Dollar canadien": "Canadian Dollar", "Dollar australien": "Australian Dollar", "Dollar néo-zélandais": "New Zealand Dollar", "Dollar de Hong Kong": "Hong Kong Dollar",
    "Peso mexicain": "Mexican Peso", "Zloty polonais": "Polish Zloty", "Or / Dollar américain (XAUUSD)": "Gold / US Dollar (XAUUSD)", "Argent / Dollar américain (XAGUSD)": "Silver / US Dollar (XAGUSD)",
    "Platine / Dollar américain": "Platinum / US Dollar", "Palladium / Dollar américain (XPDUSD)": "Palladium / US Dollar (XPDUSD)", "Cuivre": "Copper", "Pétrole brut WTI": "WTI crude oil",
    "Pétrole Brent": "Brent crude oil", "Gaz naturel": "Natural gas", "Indice du dollar américain": "US Dollar Index", "Dow Jones 30 (US30)": "Dow Jones 30 (US30)",
    "DAX 40 (Allemagne)": "DAX 40 (Germany)", "FTSE 100 (Royaume-Uni)": "FTSE 100 (United Kingdom)", "CAC 40 (France)": "CAC 40 (France)", "IBEX 35 (Espagne)": "IBEX 35 (Spain)",
    "SMI 20 (Suisse)": "SMI 20 (Switzerland)", "AEX 25 (Pays-Bas)": "AEX 25 (Netherlands)", "ASX 200 (Australie)": "ASX 200 (Australia)", "Hang Seng (Hong Kong)": "Hang Seng (Hong Kong)",
    "Actions Europe": "European stocks", "ETF Or (GLD)": "Gold ETF (GLD)", "Bitcoin / Dollar américain": "Bitcoin / US Dollar", "Ethereum / Dollar américain": "Ethereum / US Dollar",
    // ---------------------------------------------------------------- compléments
    "simulées": "simulated", "Pertes d'affilée max": "Max consecutive losses", "Gains d'affilée max": "Max consecutive wins",
    ": aucun ordre réel n'est envoyé. Stop et objectif touchés dans la même bougie : compté perdant (prudence). Écart et commissions non comptés.": ": no real order is sent. Stop and target hit in the same bar: counted as a loss (to be safe). Spread and commissions not counted.",
    "Bouton « Alerte » en haut, puis touchez le niveau sur le graphique. Les alertes sonnent tant que l'application est ouverte sur cet actif (en direct ou en replay).": "« Alert » button at the top, then click the level on the chart. Alerts ring while the app is open on this symbol (live or replay).",
    "Annulée (pas déclenchée)": "Cancelled (not triggered)", "Icônes et émojis": "Icons and emojis", "Zoom avant : glisser sur la période à agrandir": "Zoom in: drag over the period to enlarge",
    "Continue à dessiner (garder l'outil après un dessin)": "Stay in drawing mode (keep the tool after drawing)", "Verrouiller tous les outils de dessin": "Lock all drawing tools",
    "Afficher la barre des favoris": "Show favorites toolbar", "Auto (adapte les données à l'écran)": "Auto (fit data to screen)", "Chemin (double-clic pour finir)": "Path (double-click to finish)",
    "Testeur de stratégie et panneau de trading": "Strategy tester and trading panel", "Démo (fxTrade Practice)": "Demo (fxTrade Practice)", "Réel (fxTrade)": "Live (fxTrade)",
    "Ouvrez un compte sur le site d'OANDA (le compte de démonstration est gratuit).": "Open an account on the OANDA website (the demo account is free).",
    "Copiez le jeton affiché et collez-le ci-dessous. Ne le donnez à personne et ne l'envoyez dans aucune conversation.": "Copy the token shown and paste it below. Never give it to anyone or send it in any conversation.",
    "Le jeton est vérifié auprès d'OANDA, puis gardé": "The token is checked with OANDA, then kept", "chiffré par Windows": "encrypted by Windows",
    "sur ce PC : il n'est plus jamais affiché, n'est pas envoyé aux invités et n'est pas mis dans le fichier à installer. L'application ne fait que": "on this PC: it is never shown again, never sent to guests and never put in the installer. The app only",
    "des bougies : elle n'envoie aucun ordre. Si un actif n'existe pas chez OANDA, les sources gratuites prennent le relais.": "candles: it never sends orders. If a symbol doesn't exist at OANDA, free sources take over.",
    "lire": "reads", "Connectez-vous, puis ouvrez": "Sign in, then open", "(Gérer l'accès API) et cliquez sur": "(Manage API Access) and click",
    "Vérifier maintenant": "Check now", "Envoyer une alerte d'essai": "Send a test alert", "M'alerter sur Telegram en cas de bug ou de tentative d'intrusion": "Alert me on Telegram for bugs or intrusion attempts",
    "Le logiciel surveille ses propres erreurs et, toutes les 2 minutes, vérifie que les cotations (temps réel, Yahoo, crypto), la place sur le disque et MaBoussole répondent. Tout est noté ci-dessous. Sur Telegram, vous ne recevez que les vrais bugs du logiciel et les tentatives d'intrusion (codes forcés, connexion recopiée, envoi depuis un autre site, adresse détournée) ; fermer la fenêtre ou une panne de cotations n'envoie rien.": "The software watches its own errors and, every 2 minutes, checks that quotes (real time, Yahoo, crypto), disk space and MaBoussole respond. Everything is logged below. On Telegram you only receive real software bugs and intrusion attempts; closing the window or a quote outage sends nothing.",
    "Contrôle de la jambe": "Leg control", "Pause / clôture": "Pause / close", "Jambe mensuelle": "Monthly leg",
    "Envoyer le logiciel à installer": "Send the software to install", "1. Téléchargement : l'application à envoyer": "1. Download: the app to send",
    "Version installable, sans Python : un double-clic suffit chez la personne.": "Installable version, no Python: one double-click is enough.",
    "⬇ Télécharger pour Windows": "⬇ Download for Windows", "⬇ Télécharger pour Mac": "⬇ Download for Mac", "Créer le fichier .zip": "Create the .zip file",
    "Ou : le dossier .zip (pour un PC qui a Python)": "Or: the .zip folder (for a PC with Python)", "Clés déjà données": "Keys already given", "3. Générateur de licence": "3. License generator",
    "2. La personne l'installe et vous envoie son code machine": "2. The person installs it and sends you their machine code",
    "Utilisateurs actifs (jour, 7 jours, 30 jours), essais gratuits, clés activées, ventes et chiffre d'affaires : dans votre tableau de bord (feuille Google, privée).": "Active users (day, 7 days, 30 days), free trials, activated keys, sales and revenue: in your dashboard (private Google sheet).",
    "Seulement MaBoussole Graphiques : ni le reste de MaBoussole, ni vos données, ni vos dessins, ni votre clé privée.": "Only MaBoussole Graphiques: not the rest of MaBoussole, nor your data, drawings or private key.",
    "Nombre d'ouvertures du logiciel": "Number of software launches", "téléchargements depuis le site :": "downloads from the website:",
    "Contexte, confluences, plan d'entrée, ce que j'ai appris…": "Context, confluences, entry plan, what I learned…", "Conditions d'entrée, stop, objectif, séances…": "Entry conditions, stop, target, sessions…",
    // réglages du graphique
    "Replay, direct et manuels": "Replay, live and manual", "ou R:R": "or R:R", "Précision des prix": "Price precision", "La plateforme ouverte": "The open platform",
    "Temps réel : forex, or, argent, platine, palladium, indices, dollar (DXY), indices synthétiques et crypto. L'historique du flux remonte à 1 an ; au-delà, il vient de Dukascopy (banque suisse), jamais de Yahoo.": "Real time: forex, gold, silver, platinum, palladium, indices, dollar (DXY), synthetic indices and crypto. The feed history goes back 1 year; older history comes from Dukascopy (Swiss bank), never Yahoo.",
    "Une plateforme MetaTrader 5 par courtier (Pepperstone, IC Markets, FXCM, Forex.com…) : installez celle du courtier avec un compte démo gratuit, ouvrez-la, puis choisissez-la ici. MetaTrader reste la source principale quand il est coché.": "One MetaTrader 5 platform per broker (Pepperstone, IC Markets, FXCM, Forex.com…): install your broker's platform with a free demo account, open it, then pick it here. MetaTrader stays the main source when checked.",
    "Sans MetaTrader : Yahoo Finance, Binance et Dukascopy, gratuits. MetaTrader n'est jamais lancé par l'application.": "Without MetaTrader: Yahoo Finance, Binance and Dukascopy, free. The app never launches MetaTrader.",
    "Deriv donne les vraies bougies de 32 actifs sur 44 (forex, or, argent, platine, indices US, DAX, FTSE, Nikkei ; la crypto vient de Binance), mises à jour toutes les 3 secondes, avec 1 an d'historique. Les autres actifs et l'historique plus ancien viennent des sources gratuites.": "Deriv gives real candles for 32 of the 44 symbols (forex, gold, silver, platinum, US indices, DAX, FTSE, Nikkei; crypto comes from Binance), updated every 3 seconds, with 1 year of history. Other symbols and older history come from free sources.",
    "Si OANDA est disponible dans votre pays.": "If OANDA is available in your country.", "Données OANDA (jeton personnel)…": "OANDA data (personal token)…",
    "Nom de l'actif et unité de temps": "Symbol name and timeframe", "Source des données": "Data source", "Noms et paramètres": "Names and parameters",
    "Lignes et étiquettes": "Lines and labels", "Espace à droite": "Right margin", "Symbole et unité de temps au centre": "Symbol and timeframe in the center",
    "Lignes des échelles": "Scale lines", "Boutons Vendre / Acheter sur le graphique": "Sell / Buy buttons on the chart",
    "Positions et ordres sur le graphique (entrée, stop, objectif)": "Positions and orders on the chart (entry, stop, target)",
    "Demander confirmation avant de fermer une position": "Ask for confirmation before closing a position", "Son à la clôture d'une position": "Sound when a position closes",
    "Sur le graphique": "On the chart", "Lignes des alertes": "Alert lines", "Quand une alerte se déclenche": "When an alert triggers", "Jouer un son": "Play a sound",
    "Supprimer l'alerte une fois déclenchée": "Remove the alert once triggered", "Afficher les annonces économiques des devises de l'actif": "Show economic releases for the symbol's currencies",
    "Séparateurs de jours": "Day separators", "✔ sur le graphique": "✔ on the chart", "Symbole": "Symbol", "Toile": "Canvas", "Événements": "Events",
    "Ligne de tendance (Alt + T · Maj : ligne droite)": "Trend line (Alt + T · Shift: straight line)", "Continuer à dessiner (garder l'outil après un dessin)": "Stay in drawing mode (keep the tool after drawing)",
    "Mon compte : Propriétaire": "My account: Owner"
  };

  // ---------------------------------------------------------------- moteur
  const dico = new Map(Object.entries(EN));
  const morceaux = [...dico.keys()].filter(k => k.length >= 8 && /\S \S/.test(k) && /[a-zà-ÿ]/i.test(k)).sort((a, b) => b.length - a.length);
  const echap = s => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const rxMorceaux = morceaux.length ? new RegExp("(^|[^A-Za-zÀ-ÿ])(" + morceaux.map(echap).join("|") + ")(?=$|[^A-Za-zÀ-ÿ])", "g") : null;
  const pl = (n, un, plusieurs) => n + " " + (+n === 1 ? un : plusieurs);
  const REGLES = [                                  // unités de temps et textes avec un nombre
    [/\b(\d+) secondes?\b/g, (m, n) => pl(n, "second", "seconds")], [/\b(\d+) minutes?\b/g, (m, n) => pl(n, "minute", "minutes")],
    [/\b(\d+) heures?\b/g, (m, n) => pl(n, "hour", "hours")], [/\b(\d+) jours?\b/g, (m, n) => pl(n, "day", "days")],
    [/\b(\d+) semaines?\b/g, (m, n) => pl(n, "week", "weeks")], [/\b(\d+) mois\b/g, (m, n) => pl(n, "month", "months")],
    [/\b(\d+) ans?\b/g, (m, n) => pl(n, "year", "years")], [/^Chargement de (.+)…$/, (m, x) => "Loading " + x + "…"],
    [/(\d+) trade\(s\) : il en faut au moins 30 pour juger une stratégie\./, (m, n) => n + " trade(s): you need at least 30 to judge a strategy."],
    [/\bjusqu'au\b/g, () => "until"], [/^Essai gratuit · /, () => "Free trial · "], [/ h restantes\b/, () => " h left"]
  ];
  const cache = new Map();
  function tr(s) {
    if (typeof s !== "string" || !s || !/[A-Za-zÀ-ÿ]/.test(s)) return s;
    if (cache.has(s)) return cache.get(s);
    const brut = s.trim(); let r = s;
    if (dico.has(brut)) r = s.replace(brut, dico.get(brut));
    else if (rxMorceaux) r = s.replace(rxMorceaux, (m, avant, k) => avant + dico.get(k));
    for (const [rx, f] of REGLES) r = r.replace(rx, f);
    if (cache.size > 5000) cache.clear();
    cache.set(s, r); return r;
  }
  window.mbgT = tr;
  const ATTRS = ["title", "placeholder", "aria-label", "alt"];
  const IGNORER = new Set(["SCRIPT", "STYLE", "CODE", "PRE"]);
  const tours = new WeakMap();                      // garde-fou anti-boucle : au plus 20 retraductions d'un même nœud par 10 s
  let fenetre = Date.now();
  function tropSouvent(n) {
    if (Date.now() - fenetre > 10000) { fenetre = Date.now(); }
    const t = tours.get(n); const k = t && t.f === fenetre ? t.k + 1 : 1;
    tours.set(n, { f: fenetre, k: k });
    return k > 20;
  }
  function traduireNoeud(n) {
    if (n.nodeType === 3) {
      const p = n.parentNode; if (!p || IGNORER.has(p.nodeName) || p.nodeName === "TEXTAREA" || (p.closest && p.closest("[data-notr],[contenteditable=true]"))) return;
      const v = n.nodeValue, t = tr(v); if (t !== v && !tropSouvent(n)) n.nodeValue = t;
      return;
    }
    if (n.nodeType !== 1 || IGNORER.has(n.nodeName) || n.hasAttribute("data-notr")) return;
    for (const a of ATTRS) { const v = n.getAttribute(a); if (v) { const t = tr(v); if (t !== v && !tropSouvent(n)) n.setAttribute(a, t); } }
    if (n.nodeName === "INPUT" && (n.type === "button" || n.type === "submit") && n.value) n.value = tr(n.value);
    if (n.nodeName === "OPTION" || n.childNodes.length) for (const c of n.childNodes) traduireNoeud(c);
  }
  let enAttente = new Set(), prevu = false;
  function planifier(n) { enAttente.add(n); if (!prevu) { prevu = true; queueMicrotask(vider); } }   // pas requestAnimationFrame : il s'arrête quand la fenêtre est cachée
  function vider() { prevu = false; const l = enAttente; enAttente = new Set(); for (const n of l) if (n.isConnected !== false) traduireNoeud(n); }
  const obs = new MutationObserver(ms => {
    for (const m of ms) {
      if (m.type === "childList") m.addedNodes.forEach(planifier);
      else if (m.type === "characterData") planifier(m.target);
      else if (m.type === "attributes") planifier(m.target);
    }
  });
  function demarrer() {
    traduireNoeud(document.body); document.title = tr(document.title);
    obs.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
    const t = document.querySelector("title"); if (t) new MutationObserver(() => { const v = tr(document.title); if (v !== document.title) document.title = v; }).observe(t, { childList: true });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", demarrer); else demarrer();
  // textes dessinés sur le graphique (étiquettes des outils et des indicateurs)
  const P = CanvasRenderingContext2D.prototype, fill = P.fillText, stroke = P.strokeText, mesure = P.measureText;
  const trCanvas = s => (typeof s === "string" && /[A-Za-zÀ-ÿ]{2}/.test(s)) ? tr(s) : s;
  P.fillText = function (s, ...a) { return fill.call(this, trCanvas(s), ...a); };
  P.strokeText = function (s, ...a) { return stroke.call(this, trCanvas(s), ...a); };
  P.measureText = function (s) { return mesure.call(this, trCanvas(s)); };
  // boîtes du navigateur éventuelles
  const al = window.alert, cf = window.confirm, pr = window.prompt;
  window.alert = m => al(tr(String(m))); window.confirm = m => cf(tr(String(m))); window.prompt = (m, v) => pr(tr(String(m)), v);
})();
