/* MaBoussole Graphiques : graphique (TradingView Lightweight Charts, licence Apache 2.0), outils de dessin, indicateurs,
   alertes, replay, positions simulées, liste de suivi et testeur de stratégie.
   Aucun ordre réel n'est envoyé. */
(function () {
  "use strict";
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const LW = window.LightweightCharts;
  // TradingView Lightweight Charts v5 : les séries se créent avec addSeries(Type, options) et le filigrane est un module à part.
  // nouveauGraphique() garde les anciens noms (addCandlestickSeries…) et l'option « watermark », pour tout le reste du code.
  const TYPES_SERIE = { addCandlestickSeries: "CandlestickSeries", addLineSeries: "LineSeries", addAreaSeries: "AreaSeries",
    addBarSeries: "BarSeries", addBaselineSeries: "BaselineSeries", addHistogramSeries: "HistogramSeries" };
  function filigraneV5(ch, w) {
    if (!w || !LW.createTextWatermark) return;
    const opts = { visible: w.visible !== false && !!w.text, horzAlign: w.horzAlign || "center", vertAlign: w.vertAlign || "center",
      lines: [{ text: w.text || "", color: w.color || "rgba(0,0,0,.07)", fontSize: w.fontSize || 72 }] };
    try {
      if (!ch._filigrane) ch._filigrane = LW.createTextWatermark(ch.panes()[0], opts); else ch._filigrane.applyOptions(opts);
    } catch (e) { /* le graphique n'est pas encore prêt : le filigrane suivra au prochain réglage */ }
  }
  function nouveauGraphique(el, options) {
    const o = Object.assign({}, options), w = o.watermark; delete o.watermark;
    const ch = LW.createChart(el, o);
    if (ch.addSeries) for (const [ancien, type] of Object.entries(TYPES_SERIE)) if (!ch[ancien]) ch[ancien] = (opts, pane) => ch.addSeries(LW[type], opts, pane);
    const reglerV4 = ch.applyOptions.bind(ch);
    ch.applyOptions = opts => {
      if (opts && opts.watermark) { filigraneV5(ch, opts.watermark); opts = Object.assign({}, opts); delete opts.watermark; }
      return reglerV4(opts);
    };
    filigraneV5(ch, w);
    return ch;
  }
  // Unités de temps : toutes celles de TradingView (1 seconde à 12 mois) + les unités personnalisées de l'utilisateur.
  // Code : S5 = 5 secondes, M45 = 45 minutes, H3 = 3 heures, D2 = 2 jours, W2 = 2 semaines, MN = 1 mois, N3 = 3 mois.
  const UNITES_TV = ["S1", "S5", "S10", "S15", "S30", "S45", "M1", "M2", "M3", "M5", "M10", "M15", "M30", "M45", "H1", "H2", "H3", "H4", "D1", "W1", "MN", "N3", "N6", "N12"];
  const UNITES = [...UNITES_TV];                     // + unités personnalisées, ajoutées après la lecture des préférences
  const LIMITES_U = { S: [1, 59], M: [1, 1439], H: [1, 24], D: [1, 365], W: [1, 52], N: [1, 12] };
  const SEC_U = { S: 1, M: 60, H: 3600, D: 86400, W: 604800, N: 2592000 };
  const NOMS_U = { S: ["seconde", "secondes"], M: ["minute", "minutes"], H: ["heure", "heures"], D: ["jour", "jours"], W: ["semaine", "semaines"], N: ["mois", "mois"] };
  const analyserU = u => u === "MN" ? ["N", 1] : [String(u)[0], parseInt(String(u).slice(1), 10)];
  const secondesU = u => { const [t, k] = analyserU(u); return (SEC_U[t] || 0) * k; };
  const ordreU = (a, b) => secondesU(a) - secondesU(b);
  const uniteValide = u => { if (u === "MN") return true; const m = /^([SMHDWN])(\d{1,4})$/.exec(String(u)); return !!m && +m[2] >= LIMITES_U[m[1]][0] && +m[2] <= LIMITES_U[m[1]][1]; };
  function normaliserU(t, k) {                       // 60 minutes -> 1 heure, 24 heures -> 1 jour, 1 mois -> MN…
    if (t === "M" && k % 60 === 0 && k / 60 <= 24) { t = "H"; k /= 60; }
    if (t === "H" && k === 24) { t = "D"; k = 1; }
    if (t === "N" && k === 1) return "MN";
    return t + k;
  }
  const EN = window.MBG_LANGUE === "en", LOC = EN ? "en-US" : "fr-FR";      // langue choisie (menu du compte) : dates, nombres, unités
  const libU = u => { const [t, k] = analyserU(u); return t === "S" ? k + "s" : t === "M" ? k + "m" : t === "H" ? k + "h" : t === "D" ? (k === 1 ? (EN ? "D" : "J") : k + (EN ? "D" : "J")) : t === "W" ? (k === 1 ? (EN ? "W" : "S") : k + (EN ? "W" : "S")) : (k === 1 ? "M" : k + "M"); };
  const filiU = u => { const [t, k] = analyserU(u); return t === "M" ? String(k) : t === "S" ? k + "s" : t === "H" ? k + "H" : t === "D" ? k + (EN ? "D" : "J") : t === "W" ? k + (EN ? "W" : "S") : k + "M"; };
  const nomLongU = u => { const [t, k] = analyserU(u); return k + " " + (NOMS_U[t] || ["", ""])[k > 1 ? 1 : 0]; };
  const LIB_UNITE = new Proxy({}, { get: (_, u) => typeof u === "string" && uniteValide(u) ? libU(u) : undefined });
  const FILI_UNITE = new Proxy({}, { get: (_, u) => typeof u === "string" && uniteValide(u) ? filiU(u) : undefined });
  const VERT = "#089981", ROUGE = "#f23645", BLEU = "#2962ff", ORANGE = "#ff9800";
  const SEANCE = { asie: ["Asie", "#ff9800"], londres: ["Londres", "#4caf50"], newyork: ["New York", "#9c27b0"] };
  const KZ = [["Asie KZ", 0, 4, "#ff9800"], ["Londres KZ", 7, 10, "#4caf50"], ["New York KZ", 12, 15, "#9c27b0"]];
  const SMV = { S1: ["#089981"], S15: ["#f7a600"], S25: ["#f23645"] };
  const libSMV = s => (s && (s.libelle || s.nom)) || "";
  const COULEURS = ["#2962ff", "#f23645", "#089981", "#ff9800", "#9c27b0", "#00bcd4", "#787b86", "#131722"];

  // ================================================================== indicateurs disponibles
  const CATS_IND = ["Tendance", "Oscillateurs", "Volatilité", "Volume", "Niveaux", "Séances"];
  const INDS = {
    smv: { nom: "Calendrier du propriétaire", court: "Calendrier", cat: "Séances", calque: true, p: { lignes: true, phases: true, libelles: true } },
    seances: { nom: "Séances (Asie, Londres, New York)", court: "Séances", cat: "Séances", calque: true, p: {} },
    kz: { nom: "Killzones (Asie 0-4h, Londres 7-10h, New York 12-15h UTC)", court: "Killzones", cat: "Séances", calque: true, p: {} },
    ictkz: { nom: "ICT Session Killzones (sessions, killzones, CBDR, hauts et bas)", court: "ICT Killzones", cat: "Séances", calque: true,
      p: { asie: "0000-0700", londres: "0800-1330", newyork: "1330-2100", asieKz: "0000-0400", lokz: "0700-1000", nykz: "1200-1500", lckz: "1500-1700", cbdr: "1900-0100",
        decalage: 0, cAsie: "#ff9800", cLondres: "#2962ff", cNewyork: "#089981", cLckz: "#9c27b0", cCbdr: "#787b86", opacite: 10, noms: true, hautsBas: true } },
    filigraneAG: { nom: "Filigrane AG FX", court: "AG FX", cat: "Séances", calque: true,
      p: { texte: "AG FX", sousTitre: "STRUCTURE | LIQUIDITÉ | CONFIRMATION", position: "centre", taille: 72, couleur: "#787b86", opacite: 18, infos: true, tailleInfos: 16 } },
    nyo: { nom: "Ouverture New York 8h30 (NYO)", court: "NYO 8:30", cat: "Séances", calque: true, p: {} },
    pivots: { nom: "Points pivots classiques (journaliers)", court: "Pivots", cat: "Niveaux", calque: true, p: { couleur: "#787b86" } },
    pdhl: { nom: "Plus haut / plus bas de la veille (PDH / PDL)", court: "PDH / PDL", cat: "Niveaux", calque: true, p: { couleur: "#2962ff" } },
    pwhl: { nom: "Plus haut / plus bas de la semaine précédente (PWH / PWL)", court: "PWH / PWL", cat: "Niveaux", calque: true, p: { couleur: "#9c27b0" } },
    premium: { nom: "Premium / Discount (zones ICT : prime, équilibre, décote)", court: "Premium / Discount", cat: "Niveaux", calque: true,
      p: { periode: 100, largeur: 50, bandeEq: 5, opacite: 12, premium: "#f23645", equilibre: "#787b86", discount: "#089981", noms: true, prix: true, prolonger: true } },
    vol: { nom: "Volume", court: "Vol", cat: "Volume", p: {} },
    sma: { nom: "Moyenne mobile simple", court: "MM", cat: "Tendance", p: { periode: 20, couleur: "#2962ff" } },
    ema: { nom: "Moyenne mobile exponentielle", court: "MME", cat: "Tendance", p: { periode: 21, couleur: "#e91e63" } },
    wma: { nom: "Moyenne mobile pondérée", court: "MMP", cat: "Tendance", p: { periode: 20, couleur: "#00bcd4" } },
    vwap: { nom: "VWAP (prix moyen pondéré par le volume, journalier)", court: "VWAP", cat: "Volume", p: { couleur: "#9c27b0" } },
    bb: { nom: "Bandes de Bollinger", court: "BB", cat: "Volatilité", p: { periode: 20, ecart: 2, couleur: "#2962ff" } },
    keltner: { nom: "Canaux de Keltner", court: "KC", cat: "Volatilité", p: { periode: 20, multi: 2, couleur: "#00897b" } },
    donchian: { nom: "Canaux de Donchian", court: "DC", cat: "Volatilité", p: { periode: 20, couleur: "#ff6d00" } },
    enveloppe: { nom: "Enveloppe", court: "Env", cat: "Tendance", p: { periode: 20, pct: 0.5, couleur: "#795548" } },
    ichimoku: { nom: "Ichimoku Kinko Hyo", court: "Ichimoku", cat: "Tendance", p: { tenkan: 9, kijun: 26, senkou: 52 } },
    psar: { nom: "SAR parabolique", court: "SAR", cat: "Tendance", p: { pas: 0.02, max: 0.2, couleur: "#2962ff" } },
    supertrend: { nom: "Supertrend", court: "Supertrend", cat: "Tendance", p: { periode: 10, multi: 3 } },
    rsi: { nom: "RSI (indice de force relative)", court: "RSI", cat: "Oscillateurs", osc: true, niveaux: [70, 50, 30], p: { periode: 14, couleur: "#7e57c2" } },
    macd: { nom: "MACD", court: "MACD", cat: "Oscillateurs", osc: true, niveaux: [0], p: { rapide: 12, lente: 26, signal: 9 } },
    stoch: { nom: "Stochastique", court: "Stoch", cat: "Oscillateurs", osc: true, niveaux: [80, 20], p: { k: 14, lissage: 3, d: 3 } },
    stochrsi: { nom: "RSI stochastique", court: "Stoch RSI", cat: "Oscillateurs", osc: true, niveaux: [80, 20], p: { rsi: 14, stoch: 14, k: 3, d: 3 } },
    cci: { nom: "CCI (indice du canal des matières premières)", court: "CCI", cat: "Oscillateurs", osc: true, niveaux: [100, -100], p: { periode: 20, couleur: "#2196f3" } },
    adx: { nom: "ADX / DMI (mouvement directionnel)", court: "DMI", cat: "Oscillateurs", osc: true, niveaux: [25], p: { periode: 14 } },
    williams: { nom: "%R de Williams", court: "%R", cat: "Oscillateurs", osc: true, niveaux: [-20, -80], p: { periode: 14, couleur: "#7e57c2" } },
    momentum: { nom: "Momentum", court: "Mom", cat: "Oscillateurs", osc: true, niveaux: [0], p: { periode: 10, couleur: "#2196f3" } },
    roc: { nom: "Taux de variation (ROC)", court: "ROC", cat: "Oscillateurs", osc: true, niveaux: [0], p: { periode: 9, couleur: "#2196f3" } },
    ao: { nom: "Awesome Oscillator", court: "AO", cat: "Oscillateurs", osc: true, niveaux: [0], p: {} },
    atr: { nom: "ATR (amplitude moyenne réelle)", court: "ATR", cat: "Volatilité", osc: true, p: { periode: 14, couleur: "#b71c1c" } },
    obv: { nom: "OBV (volume équilibré)", court: "OBV", cat: "Volume", osc: true, p: { couleur: "#2962ff" } },
    tdi: { nom: "TDI (Traders Dynamic Index)", court: "TDI", cat: "Oscillateurs", osc: true, niveaux: [68, 50, 32],
      p: { rsi: 13, bande: 34, ecart: 1.6185, prix: 2, signal: 7, cPrix: "#089981", cSignal: "#f23645", cBandes: "#2962ff", cMilieu: "#ff9800" } },
    mfi: { nom: "MFI (indice du flux monétaire)", court: "MFI", cat: "Volume", osc: true, niveaux: [80, 20], p: { periode: 14, couleur: "#7e57c2" } },
  };
  const NOMS_PARAM = { periode: "Période", couleur: "Couleur", ecart: "Écart-type", multi: "Multiplicateur", pct: "Écart (%)", tenkan: "Tenkan (conversion)",
    kijun: "Kijun (base)", senkou: "Senkou B", pas: "Pas", max: "Maximum", rapide: "Moyenne rapide", lente: "Moyenne lente", signal: "Signal",
    k: "%K", lissage: "Lissage %K", d: "%D", rsi: "Période RSI", stoch: "Période stochastique", lignes: "Lignes du 1er, du 15 et du 25",
    phases: "Fond coloré des phases", libelles: "Nom des phases",
    largeur: "Taille des zones premium et discount (% de l'amplitude, 50 = deux moitiés)", bandeEq: "Bande d'équilibre (% de l'amplitude)", opacite: "Opacité du fond (%)",
    premium: "Couleur premium (cher, zone de vente)", equilibre: "Couleur équilibre (50 %)", discount: "Couleur discount (bon marché, zone d'achat)",
    asie: "Session Asie (HHMM-HHMM, vide = masquée)", londres: "Session Londres (HHMM-HHMM)", newyork: "Session New York (HHMM-HHMM)",
    asieKz: "Killzone Asie", lokz: "Killzone Londres (LOKZ)", nykz: "Killzone New York (NYKZ)", lckz: "Killzone clôture de Londres (LCKZ)", cbdr: "CBDR (Central Bank Dealers Range)",
    decalage: "Décalage horaire des heures ci-dessus (h, 0 = UTC)", cAsie: "Couleur Asie", cLondres: "Couleur Londres", cNewyork: "Couleur New York", cLckz: "Couleur clôture de Londres", cCbdr: "Couleur CBDR",
    hautsBas: "Hauts et bas des killzones prolongés jusqu'à être touchés",
    infos: "Date du jour et « SYMBOLE | UNITÉ » en bas du graphique", tailleInfos: "Taille de la date et du symbole",
    texte: "Texte", sousTitre: "Sous-titre", position: "Position (haut, centre, bas)", taille: "Taille du texte", bande: "Période des bandes", prix: "Ligne de prix (MM du RSI)",
    cPrix: "Couleur ligne de prix", cSignal: "Couleur ligne de signal", cBandes: "Couleur des bandes", cMilieu: "Couleur ligne du milieu",
    noms: "Afficher les noms des zones", prix: "Afficher les prix (haut, 50 %, bas)", prolonger: "Prolonger les zones vers la droite" };

  // ================================================================== outils de dessin
  // [nom, nombre de points (ou "multi" / "libre" / 0), raccourci]
  const OUTILS = {
    curseur: ["Croix", 0], point: ["Point", 0], flechec: ["Flèche", 0], demo: ["Démonstration", 0], gomme: ["Gomme", 0],
    trend: ["Ligne de tendance", 2, "Alt + T"], rayon: ["Rayon", 2], info: ["Ligne d'info", 2], etendue: ["Ligne étendue", 2], angle: ["Angle de tendance", 2],
    hline: ["Ligne horizontale", 1, "Alt + H"], hray: ["Rayon horizontal", 1, "Alt + J"], vline: ["Ligne verticale", 1, "Alt + V"], croix: ["Ligne transversale", 1, "Alt + C"],
    canal: ["Canal parallèle", 3], regression: ["Tendance régressive", 2], hautbas: ["Haut/bas plat", 3], disjoint: ["Canal disjoint", 3],
    fourche: ["Fourche", 3], schiff: ["Fourche de Schiff", 3], schiffmod: ["Fourche de Schiff modifiée", 3], fourcheint: ["Fourche intérieure", 3],
    fibo: ["Retracement de Fibonacci", 2, "Alt + F"], fiboext: ["Extension de Fibonacci basée sur la tendance", 3], fibocanal: ["Canal de Fibonacci", 3],
    fibotemps: ["Zone temporelle de Fibonacci", 2], fiboeventail: ["Éventail de résistance de vitesse", 2], fibotempstend: ["Temps de Fibonacci basé sur la tendance", 3],
    fibocercles: ["Cercles de Fibonacci", 2], fibospirale: ["Spirale de Fibonacci", 2], fiboarcs: ["Arcs de résistance de vitesse", 2], fibocoin: ["Coin de Fibonacci", 3],
    pitchfan: ["Éventail de fourche", 3], gannboite: ["Boîte de Gann", 2], ganncarre: ["Carré de Gann", 2], ganneventail: ["Éventail de Gann", 2],
    xabcd: ["Motif XABCD", 5], cypher: ["Motif de chiffrement (Cypher)", 5], tete: ["Tête et épaules", 7], abcd: ["Motif ABCD", 4], trianglemotif: ["Motif en triangle", 4],
    threedrives: ["Motif « Three Drives »", 7], elliott: ["Vague d'impulsion d'Elliott (1-2-3-4-5)", 6], ellcor: ["Vague de correction d'Elliott (A-B-C)", 4],
    elltri: ["Vague triangulaire d'Elliott (A-B-C-D-E)", 6], ellwxy: ["Double vague combinée d'Elliott (W-X-Y)", 4], ellwxyxz: ["Vague triple combo d'Elliott (W-X-Y-X-Z)", 6],
    cycliques: ["Lignes cycliques", 2], cyclestemps: ["Cycles de temps", 2], sinus: ["Ligne sinusoïdale", 2],
    long: ["Position longue", 1], short: ["Position courte", 1], prevision: ["Prévision de position", 2], motifbarres: ["Motif à barres", 2], ghost: ["Ghost feed (double-clic pour finir)", "multi"],
    secteur: ["Secteur", 3], vwapancre: ["VWAP ancré", 1], profilfixe: ["Profil de volume à gamme fixe", 2], profilancre: ["Profil de volume ancré", 1],
    fprix: ["Plage de prix", 2], fdate: ["Plage de dates", 2], fprixdate: ["Plage de date et de prix", 2],
    pinceau: ["Brosse", "libre"], surligneur: ["Surligneur", "libre"], marqueurfleche: ["Marqueur fléché", 2], fleche: ["Flèche", 2], flechehaut: ["Flèche vers le haut", 1], flechebas: ["Flèche vers le bas", 1],
    rect: ["Rectangle", 2, "Alt + Shift + R"], zone: ["Zone prolongée à droite (offre / demande)", 2], rectpivote: ["Rectangle pivoté", 3], chemin: ["Chemin (double-clic pour finir)", "multi"],
    cercle: ["Cercle", 2], ellipse: ["Ellipse", 2], polyligne: ["Polyligne (double-clic pour finir)", "multi"], triangle: ["Triangle", 3], arc: ["Arc", 3], courbe: ["Courbe", 3], doublecourbe: ["Double courbe", 4],
    texte: ["Texte", 1], note: ["Note", 1], noteprix: ["Note de prix", 2], epingle: ["Épingle", 1], tableau: ["Tableau", 1], callout: ["Callout", 2], commentaire: ["Commentaire", 1],
    etiquette: ["Étiquette de prix", 1], panneau: ["Panneau", 1], drapeau: ["Marque de drapeau", 1], image: ["Image", 2],
    icone: ["Icône", 1], regle: ["Règle (mesurer)", 2], zoom: ["Zoom avant (glisser sur la zone)", 2], alerte: ["Alerte de prix", 1],
  };
  const GROUPES = [
    { id: "curseurs", sections: [["", ["curseur", "point", "flechec", "demo"]], ["", ["gomme"]]] },
    { id: "lignes", sections: [["Lignes", ["trend", "rayon", "info", "etendue", "angle", "hline", "hray", "vline", "croix"]], ["Canaux", ["canal", "regression", "hautbas", "disjoint"]], ["Fourches", ["fourche", "schiff", "schiffmod", "fourcheint"]]] },
    { id: "fibo", sections: [["Fibonacci", ["fibo", "fiboext", "fibocanal", "fibotemps", "fiboeventail", "fibotempstend", "fibocercles", "fibospirale", "fiboarcs", "fibocoin", "pitchfan"]], ["Gann", ["gannboite", "ganncarre", "ganneventail"]]] },
    { id: "motifs", sections: [["Motifs graphiques", ["xabcd", "cypher", "tete", "abcd", "trianglemotif", "threedrives"]], ["Vagues d'Elliott", ["elliott", "ellcor", "elltri", "ellwxy", "ellwxyxz"]], ["Cycles", ["cycliques", "cyclestemps", "sinus"]]] },
    { id: "prevision", sections: [["Prévisions", ["long", "short", "prevision", "motifbarres", "ghost", "secteur"]], ["Basé sur le volume", ["vwapancre", "profilfixe", "profilancre"]], ["Mesureurs", ["fprix", "fdate", "fprixdate"]]] },
    { id: "formes", sections: [["Brosses", ["pinceau", "surligneur"]], ["Flèches", ["marqueurfleche", "fleche", "flechehaut", "flechebas"]], ["Formes", ["rect", "zone", "rectpivote", "chemin", "cercle", "ellipse", "polyligne", "triangle", "arc", "courbe", "doublecourbe"]]] },
    { id: "texte", sections: [["Texte et notes", ["texte", "note", "noteprix", "epingle", "tableau", "callout", "commentaire", "etiquette", "panneau", "drapeau"]], ["Contenu", ["image"]]] },
  ];
  const ICONES = {
    "Gestes et émoticônes": ["👍", "👎", "👌", "✋", "👉", "👈", "👆", "👇", "🙂", "😀", "😮", "😢", "😡", "🤔", "🙏", "💪"],
    "Symboles et drapeaux": ["🚩", "🏁", "⭐", "❤", "✅", "❌", "➕", "➖", "❓", "❗", "⚠", "🔥", "💡", "🎯", "📌", "📍", "🔔", "⏰", "🔒", "🔓", "👁", "💰", "🚀", "💥"],
    "Nature": ["🌙", "☀", "⚡", "🌊", "🍀", "❄", "🌪", "🐂", "🐻"],
    "Devise": ["€", "£", "$", "₹", "¥", "₽", "₩", "₺", "₿"],
    "Flèches": ["⬆", "⬇", "⬅", "➡", "↗", "↘", "↙", "↖", "🔼", "🔽"],
    "Icônes": ["●", "○", "■", "□", "▲", "▼", "◆", "◇", "★", "☆", "✓", "✗", "✚", "⚑", "⌖", "⊕", "⊗", "♥", "☾", "☼", "?", "!", "i"],
  };
  const st = '" fill="none" stroke="currentColor" stroke-width="1.1" vector-effect="non-scaling-stroke" stroke-linecap="round" stroke-linejoin="round"';
  const ICO = {
    curseur: `<path d="M12 4v6M12 14v6M4 12h6M14 12h6${st}/>`, point: '<circle cx="12" cy="12" r="2.5" fill="currentColor"/>',
    flechec: `<path d="M7 4l11 9-5 1 3 6-2 1-3-6-4 3z${st}/>`, demo: `<circle cx="12" cy="12" r="8${st}/><path d="M10 8l6 4-6 4z${st}/>`,
    gomme: `<path d="M4 16l8-8 6 6-5 5H8zM8 19h12${st}/>`,
    trend: `<path d="M6 18L18 6${st}/><circle cx="6" cy="18" r="1.8${st}/><circle cx="18" cy="6" r="1.8${st}/>`,
    rayon: `<path d="M6 18L21 3${st}/><circle cx="6" cy="18" r="1.8${st}/><circle cx="12" cy="12" r="1.8${st}/>`,
    info: `<path d="M5 18L16 7${st}/><circle cx="16" cy="7" r="1.8${st}/><rect x="13" y="14" width="7" height="5${st}/>`,
    etendue: `<path d="M2 22L22 2${st}/><circle cx="8" cy="16" r="1.8${st}/><circle cx="16" cy="8" r="1.8${st}/>`,
    angle: `<path d="M5 18L18 6M5 18h15M11 18a6 6 0 0 0-1.5-4${st}/>`,
    hline: `<path d="M3 12h18${st}/><circle cx="12" cy="12" r="1.8${st}/>`, hray: `<path d="M7 12h14${st}/><circle cx="5" cy="12" r="1.8${st}/>`,
    vline: `<path d="M12 3v18${st}/><circle cx="12" cy="12" r="1.8${st}/>`, croix: `<path d="M12 3v18M3 12h18${st}/><circle cx="12" cy="12" r="1.8${st}/>`,
    canal: `<path d="M3 14L14 3M10 21L21 10${st}/>`, regression: `<path d="M3 12L21 6M3 17L21 11M3 7L21 1${st}/>`,
    hautbas: `<path d="M3 18L20 8M3 6h17${st}/>`, disjoint: `<path d="M3 16L20 8M3 6l17 12${st}/>`,
    fourche: `<path d="M3 12h18M7 6l14 3M7 18l14-3M3 12l4-6M3 12l4 6${st}/>`, schiff: `<path d="M3 9h18M7 5l14 2M7 15l14-2${st}/>`,
    schiffmod: `<path d="M5 11h16M7 6l14 3M7 16l14-3${st}/>`, fourcheint: `<path d="M8 12h13M8 6l13 4M8 18l13-4${st}/>`,
    fibo: `<path d="M3 5h18M3 9.5h18M3 14h18M3 19h18${st}/>`, fiboext: `<path d="M3 20l5-10 5 6M13 5h8M13 10h8M13 15h8${st}/>`,
    fibocanal: `<path d="M3 15L15 3M5 19L19 5M9 21L21 9${st}/>`, fibotemps: `<path d="M4 3v18M7 3v18M11 3v18M18 3v18${st}/>`,
    fiboeventail: `<path d="M3 21L21 3M3 21L21 9M3 21L21 15M3 21L9 3${st}/>`, fibotempstend: `<path d="M3 18l5-8 4 5M14 3v18M17 3v18M21 3v18${st}/>`,
    fibocercles: `<circle cx="12" cy="12" r="3${st}/><circle cx="12" cy="12" r="6${st}/><circle cx="12" cy="12" r="9${st}/>`,
    fibospirale: `<path d="M12 12a2 2 0 1 1 2 2 4 4 0 1 1-4-4 7 7 0 1 1 7 7${st}/>`, fiboarcs: `<path d="M4 20a8 8 0 0 1 8-8M4 20a13 13 0 0 1 13-13M4 20a17 17 0 0 1 17-17${st}/>`,
    fibocoin: `<path d="M3 20L21 6M3 20L21 18M14 11a12 12 0 0 1 0 8M9 14a6 6 0 0 1 0 4${st}/>`, pitchfan: `<path d="M3 20L20 4M3 20L21 10M3 20L21 16M20 4v12${st}/>`,
    gannboite: `<rect x="3" y="4" width="18" height="16${st}/><path d="M3 4l18 16M3 20L21 4M12 4v16M3 12h18${st}/>`,
    ganncarre: `<rect x="3" y="3" width="18" height="18${st}/><path d="M3 3l18 18M3 21L21 3M7.5 3v18M12 3v18M16.5 3v18${st}/>`,
    ganneventail: `<path d="M3 21L21 3M3 21L21 12M3 21L12 3M3 21L21 17M3 21L7 3${st}/>`,
    xabcd: `<path d="M3 17l4-11 4 8 4-6 6 10M3 17l8-3M11 14l10 3${st}/>`, cypher: `<path d="M3 17l4-12 4 9 4-7 6 11${st}/><circle cx="7" cy="5" r="1.4${st}/>`,
    tete: `<path d="M2 18l3-6 3 4 4-10 4 10 3-4 3 6M5 16h15${st}/>`, abcd: `<path d="M3 18l5-12 6 8 7-11${st}/>`,
    trianglemotif: `<path d="M3 6l5 12 5-9 5 6M3 6l15 6M8 18l10-6${st}/>`, threedrives: `<path d="M2 20l3-6 2 2 4-7 2 2 4-8 2 2${st}/>`,
    elliott: `<path d="M2 20l4-7 3 3 5-10 3 4 5-7${st}/>`, ellcor: `<path d="M3 6l6 10 4-5 7 9${st}/>`, elltri: `<path d="M2 12l4-6 4 10 4-7 4 5 4-3${st}/>`,
    ellwxy: `<path d="M3 6l6 9 5-5 7 10${st}/>`, ellwxyxz: `<path d="M2 6l4 8 3-4 4 7 3-4 6 9${st}/>`,
    cycliques: `<path d="M5 4v16M11 4v16M17 4v16${st}/><path d="M5 9a3 3 0 0 1 6 0a3 3 0 0 1 6 0${st}/>`, cyclestemps: `<path d="M2 15a4 4 0 0 1 8 0a4 4 0 0 1 8 0a3 3 0 0 1 4-2${st}/>`,
    sinus: `<path d="M2 12c3-9 6-9 9 0s6 9 9 0${st}/>`,
    long: '<rect x="4" y="4" width="16" height="8" fill="#08998133" stroke="#089981"/><rect x="4" y="12" width="16" height="7" fill="#f2364533" stroke="#f23645"/>',
    short: '<rect x="4" y="5" width="16" height="7" fill="#f2364533" stroke="#f23645"/><rect x="4" y="12" width="16" height="8" fill="#08998133" stroke="#089981"/>',
    prevision: `<path d="M4 16h4V9h4v4h3V6h4${st}/><path d="M17 6l2-2 2 2${st}/>`, motifbarres: `<path d="M5 6v10M9 4v12M13 8v9M17 5v11M5 9h2M9 7h2M13 11h2M17 8h2${st}/>`,
    ghost: `<path d="M4 10v8M8 7v8M12 12v6M16 6v8M20 9v7${st} stroke-dasharray="2 2"/>`, secteur: `<path d="M4 20L20 8M4 20L18 20M18 20a14 14 0 0 0 2-12${st}/>`,
    vwapancre: `<path d="M3 16c4-6 8-1 11-5s5-3 7-5M6 6v14M4 10h4${st}/>`, profilfixe: `<path d="M4 4v16M4 6h6M4 9h10M4 12h14M4 15h9M4 18h5${st}/>`,
    profilancre: `<path d="M20 4v16M20 6h-6M20 9h-10M20 12h-14M20 15h-9M20 18h-5${st}/>`,
    fprix: `<path d="M5 4h14M5 20h14M12 5v14M9 8l3-3 3 3${st}/>`, fdate: `<path d="M4 5v14M20 5v14M5 12h14M16 9l3 3-3 3${st}/>`,
    fprixdate: `<rect x="4" y="4" width="16" height="16${st}/><path d="M12 6v12M6 12h12${st}/>`,
    pinceau: `<path d="M4 18c3-1 3-5 6-6s4 3 7 1 3-6 3-6${st}/>`, surligneur: '<path d="M4 16c4-3 8-6 16-8" fill="none" stroke="currentColor" stroke-width="5" opacity=".35"/>',
    marqueurfleche: `<path d="M4 20l11-11-3-3h8v8l-3-3L6 22z${st}/>`, fleche: `<path d="M5 19L19 5M12 5h7v7${st}/>`,
    flechehaut: `<path d="M12 4l7 8h-4v8H9v-8H5z${st}/>`, flechebas: `<path d="M12 20l7-8h-4V4H9v8H5z${st}/>`,
    rect: `<rect x="4" y="6" width="16" height="12${st}/>`, zone: '<rect x="4" y="7" width="18" height="10" fill="currentColor" opacity=".3"/><path d="M4 7v10" stroke="currentColor" stroke-width="1.5"/>',
    rectpivote: `<path d="M8 3l13 7-5 10L3 13z${st}/>`, chemin: `<path d="M3 18l5-8 5 5 8-10${st}/><path d="M18 5h3v3${st}/>`,
    cercle: `<circle cx="12" cy="12" r="8${st}/><circle cx="12" cy="12" r="1.3" fill="currentColor"/>`, ellipse: `<ellipse cx="12" cy="12" rx="9" ry="6${st}/>`,
    polyligne: `<path d="M4 10l6-6 9 3-2 11H6z${st}/>`, triangle: `<path d="M4 19L12 5l8 14z${st}/>`, arc: `<path d="M4 18a10 10 0 0 1 16 0z${st}/>`,
    courbe: `<path d="M4 18C6 8 14 4 20 6${st}/>`, doublecourbe: `<path d="M3 18c4-10 8 4 12-4s4-8 6-8${st}/>`,
    texte: `<path d="M5 6h14M12 6v13${st} stroke-width="1.8"/>`, note: `<rect x="5" y="4" width="14" height="11${st}/><path d="M12 15v5M9 8h6M12 8v5${st}/>`,
    noteprix: `<rect x="5" y="4" width="14" height="11${st}/><path d="M12 15v5M12 6v7M10 8h3.5a1.5 1.5 0 0 1 0 3h-3a1.5 1.5 0 0 0 0 3H14${st}/>`,
    epingle: `<path d="M12 21s-6-6-6-11a6 6 0 0 1 12 0c0 5-6 11-6 11z${st}/><circle cx="12" cy="10" r="2${st}/>`,
    tableau: `<rect x="3" y="5" width="18" height="14${st}/><path d="M3 10h18M3 14.5h18M9 5v14M15 5v14${st}/>`,
    callout: `<path d="M4 5h16v10H10l-5 4 1-4H4z${st}/>`, commentaire: `<rect x="3" y="6" width="18" height="11" rx="5${st}/>`,
    etiquette: `<path d="M3 8h13l5 4-5 4H3z${st}/>`, panneau: `<circle cx="12" cy="9" r="6${st}/><path d="M12 15v6M12 6l1 2 2 .3-1.5 1.4.4 2.1-1.9-1-1.9 1 .4-2.1L9 8.3 11 8z${st}/>`,
    drapeau: `<path d="M6 21V4h12l-3 4 3 4H6${st}/>`, image: `<rect x="3" y="5" width="18" height="14${st}/><path d="M3 16l5-5 4 4 3-3 6 6${st}/><circle cx="16" cy="9" r="1.5${st}/>`,
    icones: `<path d="M12 20s-8-5-8-11a4.5 4.5 0 0 1 8-2.5A4.5 4.5 0 0 1 20 9c0 6-8 11-8 11z${st}/>`,
    regle: `<path d="M3 17L17 3l4 4L7 21zM7 13l2 2M10 10l2 2M13 7l2 2${st}/>`, zoom: `<circle cx="10.5" cy="10.5" r="6.5${st}/><path d="M15.5 15.5L21 21M10.5 7.5v6M7.5 10.5h6${st}/>`,
    dezoom: `<circle cx="10.5" cy="10.5" r="6.5${st}/><path d="M15.5 15.5L21 21M7.5 10.5h6${st}/>`,
    aimant: `<path d="M6 4v8a6 6 0 0 0 12 0V4h-4v8a2 2 0 0 1-4 0V4zM6 8h4M14 8h4${st}/>`,
    continuer: `<path d="M4 20l1-4L15 6l3 3L8 19zM13 8l3 3${st}/><rect x="15" y="15" width="6" height="5" rx="1${st}/><path d="M16.5 15v-1.5a1.5 1.5 0 0 1 3 0V15${st}/>`,
    verrou: `<rect x="5" y="11" width="14" height="9" rx="1${st}/><path d="M8 11V8a4 4 0 0 1 8 0${st}/>`,
    masquer: `<path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6S2 12 2 12z${st}/><circle cx="12" cy="12" r="2.5${st}/>`,
    effacer: `<path d="M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13${st}/>`, favoris: `<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z${st}/>`,
    alerte: `<circle cx="12" cy="13" r="7${st}/><path d="M12 9v4l3 2${st}/>`,
  };
  // Icônes au style TradingView (grille 28 px, trait fin, petites poignées rondes où le trait s'arrête) : dessins propres à MaBoussole.
  const icK = 'fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"';
  const icP = (d, plus = "") => `<path d="${d}" ${icK} ${plus}/>`;
  const icO = (x, y, r = 1.9) => `<circle cx="${x}" cy="${y}" r="${r}" ${icK}/>`;
  const icT = d => icP(d, 'stroke-dasharray="1.6 2"');
  function icS(x1, y1, x2, y2, a = 1, b = 1, r = 2.4) {        // segment raccourci au bord des poignées
    const l = Math.hypot(x2 - x1, y2 - y1) || 1, u = (x2 - x1) / l, v = (y2 - y1) / l, f = n => +n.toFixed(2);
    return `M${f(x1 + (a ? u * r : 0))} ${f(y1 + (a ? v * r : 0))}L${f(x2 - (b ? u * r : 0))} ${f(y2 - (b ? v * r : 0))}`;
  }
  const icL = (x1, y1, x2, y2, a = 1, b = 1) => icP(icS(x1, y1, x2, y2, a, b)) + (a ? icO(x1, y1) : "") + (b ? icO(x2, y2) : "");
  function icV(pts, r = 1.5) {                                    // ligne brisée avec une poignée à chaque sommet
    let d = ""; for (let i = 0; i + 1 < pts.length; i++) d += icS(...pts[i], ...pts[i + 1], 1, 1, r + 0.5);
    return icP(d) + pts.map(q => icO(q[0], q[1], r)).join("");
  }
  const icR = (x, y, fins) => icO(x, y) + icP(fins.map(([u, v]) => icS(x, y, u, v, 1, 0)).join(""));
  const ICO_TV = {
    curseur: icP("M14 5v7M14 16v7M5 14h7M16 14h7"), point: '<circle cx="14" cy="14" r="2.4" fill="currentColor"/>',
    flechec: icP("M9 5.5v15.5l4.2-4 3.1 6.4 2.4-1.1-3.1-6.3h5.9z"), demo: icO(14, 14, 9) + icP("M12 10l6 4-6 4z"),
    gomme: icP("M6.5 18.5l9-9a1.6 1.6 0 0 1 2.2 0l3.8 3.8a1.6 1.6 0 0 1 0 2.2l-6.2 6.5H9.5zM11.2 13.8l5.5 5.5M9.5 22H23"),
    trend: icL(7, 21, 21, 7), rayon: icL(7, 21, 14, 14) + icP(icS(14, 14, 24, 4, 1, 0)),
    info: icL(5, 19, 17, 7) + `<rect x="14.5" y="16.5" width="9" height="6.5" rx="1" ${icK}/>` + icP("M19 18.6v2.6"),
    etendue: icP(icS(3, 25, 9, 19, 0, 1)) + icL(9, 19, 19, 9) + icP(icS(19, 9, 25, 3, 1, 0)),
    angle: icL(7, 21, 20, 8) + icP("M9.4 21H23M15 21a8 8 0 0 0-2.4-5.6"),
    hline: icP("M4 14h7.6M16.4 14H24") + icO(14, 14), hray: icO(7, 14) + icP("M9.4 14H24"), vline: icP("M14 4v7.6M14 16.4V24") + icO(14, 14),
    croix: icP("M14 4v7.6M14 16.4V24M4 14h7.6M16.4 14H24") + icO(14, 14),
    canal: icL(5, 15, 15, 5) + icL(13, 23, 23, 13) + icT("M9 19L19 9"), regression: icL(5, 17, 23, 11) + icT("M5 12L23 6M5 22L23 16"),
    hautbas: icL(5, 22, 22, 14) + icP("M5 7h14.6") + icO(22, 7), disjoint: icL(5, 21, 22, 15) + icL(5, 7, 22, 10),
    fourche: icO(5, 14) + icP("M7.4 14H24") + icO(16, 7) + icO(16, 21) + icP("M16 9.4v9.2M18.4 7H24M18.4 21H24"),
    schiff: icO(5, 21) + icP(icS(5, 21, 24, 13, 1, 0)) + icO(15, 8) + icO(17, 20) + icP(icS(15, 8, 17, 20) + icS(15, 8, 24, 5.5, 1, 0) + icS(17, 20, 24, 18, 1, 0)),
    schiffmod: icO(5, 18) + icP(icS(5, 18, 24, 14, 1, 0)) + icO(15, 8) + icO(16, 20) + icP(icS(15, 8, 16, 20) + icS(15, 8, 24, 6, 1, 0) + icS(16, 20, 24, 19, 1, 0)),
    fourcheint: icO(5, 14) + icP("M7.4 14H24") + icO(14, 8) + icO(14, 20) + icP("M14 10.4v7.2M16.4 9.2L24 11M16.4 18.8L24 17"),
    fibo: icO(6, 22) + icO(22, 6) + icP("M4 6h15.6M4 11h20M4 17h20M8.4 22H24") + icT("M7.7 20.3L20.3 7.7"),
    fiboext: icV([[4, 21], [10, 8], [15, 16]]) + icP("M17 6h8M17 11h8M17 16h8M17 21h8"),
    fibocanal: icL(4, 14, 14, 4) + icP("M6 20L20 6M10 24L24 10"), fibotemps: icP("M5 4v20M9 4v20M14 4v20M23 4v20"),
    fiboeventail: icR(5, 23, [[24, 4], [24, 11], [24, 17], [11, 4]]), fibotempstend: icV([[3, 21], [8, 11], [12, 18]]) + icP("M16 4v20M19.5 4v20M24.5 4v20"),
    fibocercles: icO(14, 14, 3.5) + icO(14, 14, 7) + icO(14, 14, 10.5), fiboarcs: icO(5, 23) + icP("M5 15a8 8 0 0 1 8 8M5 10a13 13 0 0 1 13 13M5 5a18 18 0 0 1 18 18"),
    fibocoin: icO(5, 22) + icP(icS(5, 22, 24, 7, 1, 0) + icS(5, 22, 24, 22, 1, 0)) + icP("M16 13a12 12 0 0 1 0 9M11 17a6 6 0 0 1 0 5"),
    pitchfan: icR(5, 22, [[24, 5], [24, 12], [24, 18]]) + icP("M23 5v13"),
    ganneventail: icR(5, 23, [[24, 4], [24, 13], [14, 4], [24, 18], [9, 4]]),
    xabcd: icV([[4, 19], [9, 7], [14, 15], [19, 9], [24, 21]]) + icT("M6 18.5L12 15.3M16 15.3L22 20"),
    cypher: icV([[4, 21], [9, 6], [13, 15], [18, 9], [24, 22]]), abcd: icV([[5, 21], [11, 8], [17, 16], [23, 5]]),
    tete: icV([[3, 21], [7, 13], [10.5, 17], [14, 6], [17.5, 17], [21, 13], [25, 21]], 1.3), trianglemotif: icV([[4, 7], [10, 21], [16, 10], [22, 17]]),
    threedrives: icV([[3, 23], [7, 15], [10.5, 18], [15, 10], [18.5, 13], [24, 5]], 1.3),
    elliott: icV([[3, 23], [7, 14], [10.5, 18], [16, 7], [19.5, 12], [25, 4]], 1.3), ellcor: icV([[5, 6], [12, 19], [17, 12], [23, 22]]),
    elltri: icV([[3, 9], [8, 20], [13, 9], [18, 17], [22, 11], [25, 15]], 1.3), ellwxy: icV([[4, 6], [11, 17], [16, 11], [24, 22]]),
    ellwxyxz: icV([[3, 6], [8, 15], [12, 10], [17, 19], [21, 14], [25, 22]], 1.3),
    long: `<rect x="5" y="6" width="18" height="9" fill="currentColor" opacity=".16"/>` + icP("M5 6h18v16H5zM5 15h18M10 11.5l4-3.5 4 3.5"),
    short: `<rect x="5" y="13" width="18" height="9" fill="currentColor" opacity=".16"/>` + icP("M5 6h18v16H5zM5 13h18M10 16.5l4 3.5 4-3.5"),
    fprix: icP("M6 5h16M6 23h16M14 7v14M11 9.5L14 6.5 17 9.5M11 18.5l3 3 3-3"), fdate: icP("M5 6v16M23 6v16M7 14h14M9.5 11L6.5 14l3 3M18.5 11l3 3-3 3"),
    fleche: icP("M6 22L21 7M13 7h8v8"), rect: icO(6, 7) + icO(22, 21) + icP("M8.4 7H22v11.6M19.6 21H6V9.4"),
    cercle: icO(14, 14, 9) + '<circle cx="14" cy="14" r="1.4" fill="currentColor"/>', ellipse: `<ellipse cx="14" cy="14" rx="10" ry="6.5" ${icK}/>`,
    triangle: icV([[5, 22], [14, 6], [23, 22], [5, 22]]), chemin: icV([[4, 21], [10, 12], [15, 17], [23, 6]]),
    polyligne: icV([[5, 11], [11, 5], [22, 9], [20, 22], [7, 21], [5, 11]], 1.3),
    texte: icP("M7 7.5h14M14 7.5V22M11 22h6M7 7.5v2.2M21 7.5v2.2", 'stroke-width="1.4"'),
    pinceau: icP("M5 22.5c2.6.3 4.4-.9 4.9-3.2l1-1.1 1.9 1.9-1 1.2c-1.4 1.3-4 1.6-6.8 1.2zM12.6 17.4L22 7.2a1.4 1.4 0 0 0-2-2L10.7 15.5"),
    surligneur: '<path d="M5 19c5-4 10-7 18-10" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round" opacity=".35"/>',
    regle: icP("M4 19.5L19.5 4l4.5 4.5L8.5 24zM8 15.5l2 2M11 12.5l2 2M14 9.5l2 2M17 6.5l2 2"),
    zoom: icO(12, 12, 7) + icP("M17.2 17.2L23 23M12 9v6M9 12h6"),
    aimant: icP("M7 5v9a7 7 0 0 0 14 0V5h-4.5v9a2.5 2.5 0 0 1-5 0V5zM7 9.5h4.5M16.5 9.5H21"),
    verrou: `<rect x="7" y="13" width="14" height="10" rx="1.5" ${icK}/>` + icP("M10 13V9.5a4 4 0 0 1 8 0V13M14 17v2"),
    masquer: icP("M3 14s4.5-7 11-7 11 7 11 7-4.5 7-11 7S3 14 3 14z") + icO(14, 14, 3),
    effacer: icP("M6 8h16M11 8V5.5h6V8M8.5 8l1 15h9l1-15M12 12v7M16 12v7"),
    favoris: icP("M14 4.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L14 19.4l-5.9 3.1 1.2-6.5-4.8-4.6 6.6-.9z"),
    motifbarres: icP("M6 8v12M10 5v13M14 10v11M18 6v12M22 9v10M4 12h2M10 8h2M12 15h2M18 10h2M20 14h2"),
    icones: icP("M14 22.5s-9-5.6-9-12a5 5 0 0 1 9-3 5 5 0 0 1 9 3c0 6.4-9 12-9 12z"),
    continuer: icP("M5 23l1.2-4.6L17 7.6l3.4 3.4L9.6 21.8zM15.2 9.4l3.4 3.4") + `<rect x="17" y="17" width="7" height="6" rx="1" ${icK}/>` + icP("M18.6 17v-1.6a1.9 1.9 0 0 1 3.8 0V17"),
    alerte: icO(14, 15, 8) + icP("M14 10.5V15l3 2M7 6.5L9.5 4M21 6.5L18.5 4"),
  };
  const svg = id => ICO_TV[id] ? `<svg viewBox="0 0 28 28">${ICO_TV[id]}</svg>` : `<svg viewBox="0 0 24 24">${ICO[id] || ICO.trend}</svg>`;

  // ================================================================== état et préférences
  const S = {
    actif: "EURUSD", unite: "M30", type: "bougies", theme: "clair", couleurs: "tv", filigrane: true, grille: true, rebours: true, echelle: 0, inverse: false,
    fuseau: "local", vitesse: 1, listeVisible: true, basReduit: false, aimant: false, verrou: false, masquer: false,
    groupeOutil: { lignes: "trend", fibo: "fibo", motifs: "xabcd", prevision: "long", formes: "rect", texte: "texte" },
    curseur: "curseur", continuer: false, masquerInd: false, voirFavoris: true, favPos: null, iconesRecentes: [], ongletIcones: "Emojis",
    favoris: ["trend", "rect", "chemin", "courbe", "callout", "etiquette", "hray", "vline", "xabcd", "texte", "long", "polyligne", "fibo", "hline", "short"],   // comme la barre des favoris de TradingView
    inds: [{ uid: "i1", id: "vol", p: {} }, { uid: "i2", id: "smv", p: { lignes: true, phases: true, libelles: true } }, { uid: "i3", id: "seances", p: {} }, { uid: "i4", id: "nyo", p: {} }],
    liste: ["SILVER", "EURUSD", "GOLD", "USDJPY", "DXY", "BITCOIN", "DOW", "USDCAD", "NZDJPY", "NASDAQ"],
  };

  // ================================================================== réglages du graphique (fenêtre « Réglages »)
  const TOILES = {
    clair: { fond: "#ffffff", fond2: "#ffffff", grilleVC: "#f0f3fa", grilleHC: "#f0f3fa", texteC: "#131722", bordC: "#e0e3eb", curseurC: "#9598a1", filigraneC: "#131722" },
    sombre: { fond: "#131722", fond2: "#131722", grilleVC: "#1e222d", grilleHC: "#1e222d", texteC: "#d1d4dc", bordC: "#2a2e39", curseurC: "#758696", filigraneC: "#d1d4dc" },
  };
  const REG_DEF = theme => Object.assign({
    corps: true, corpsH: VERT, corpsB: ROUGE, bord: true, bordH: VERT, bordB: ROUGE, meche: true, mecheH: VERT, mecheB: ROUGE, clotPrec: false, precision: "auto",
    lTitre: true, lSource: true, lOHLC: true, lVar: true, lVol: false, lIndTitres: true, lIndValeurs: true,
    ligneDernier: true, etiqDernier: true, etiqInd: true, etiqDessins: true, margeHaut: 8, margeBas: 4, margeDroite: 12,
    fondType: "uni", grilleV: true, grilleH: true, curseurStyle: 3, taille: 12,
    tOrdreRapide: true, tPositions: true, tConfirmer: false, tSon: true,
    aLignes: true, aCouleur: ORANGE, aSon: true, aNotif: true, aSupprAuto: false,
    evEco: true, evFort: true, evMoyen: true, evFaible: false, evSeparateurs: false,
  }, TOILES[theme === "sombre" ? "sombre" : "clair"]);
  // Réglages et onglets : copie dans ce navigateur + copie dans le logiciel (la plus récente gagne).
  // Ainsi les onglets ouverts reviennent même si l'on ouvre l'application par une autre icône ou un autre navigateur.
  {
    let local = null, serveur = null;
    try { local = JSON.parse(localStorage.getItem("mbgPrefs2") || "null"); } catch (e) { /* stockage indisponible */ }
    try { const x = new XMLHttpRequest(); x.open("GET", "/api/prefs", false); x.send(); if (x.status === 200) serveur = (JSON.parse(x.responseText) || {}).prefs; } catch (e) { /* serveur injoignable */ }
    if (serveur && !Object.keys(serveur).length) serveur = null;
    const choisi = serveur && (!local || (serveur._t || 0) > (local._t || 0)) ? serveur : local;
    if (choisi) Object.assign(S, choisi);
  }
  if (!S.reg) {   // première ouverture avec la fenêtre Réglages : on reprend les anciens choix
    S.reg = REG_DEF(S.theme);
    if (S.grille === false) { S.reg.grilleV = false; S.reg.grilleH = false; }
    if (S.couleurs === "bleu") Object.assign(S.reg, { corpsH: BLEU, bordH: BLEU, mecheH: BLEU, corpsB: "#131722", bordB: "#131722", mecheB: "#131722" });
  }
  S.reg = Object.assign(REG_DEF(S.theme), S.reg);
  S.unitesFav = Array.isArray(S.unitesFav) ? S.unitesFav.filter(uniteValide) : ["M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1", "MN"];
  S.unitesPerso = Array.isArray(S.unitesPerso) ? S.unitesPerso.filter(uniteValide) : [];
  for (const u of S.unitesPerso) if (!UNITES.includes(u)) UNITES.push(u);
  UNITES.sort(ordreU);
  if (!uniteValide(S.unite)) S.unite = "M30";
  S.inds = S.inds.filter(x => INDS[x.id]);
  // Premier coup d'œil : les bougies sont demandées tout de suite, pendant que le reste de la page se met en place.
  const urlPremieresBougies = () => {
    const natif = ["M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1", "MN"].includes(S.unite);
    const n = !natif ? 1000 : secondesU(S.unite) >= 86400 ? 1500 : 650;   // petit lot d'abord, le reste arrive juste après en arrière-plan
    return `/api/bougies?actif=${S.actif}&unite=${S.unite}&n=${n}`;
  };
  let PRECHARGE = null;
  try { const u = urlPremieresBougies(); PRECHARGE = { url: u, rep: fetch(u).then(r => r.json()) }; } catch (e) { PRECHARGE = null; }
  let minuteurPrefs = null;
  const sauverPrefs = () => {
    S._t = Date.now();
    try { localStorage.setItem("mbgPrefs2", JSON.stringify(S)); } catch (e) { /* rien */ }
    if (typeof sauvegardeAutoMise === "function") try { sauvegardeAutoMise(); } catch (e) { /* rien */ }
    clearTimeout(minuteurPrefs);                       // envoi au logiciel regroupé (une fois par seconde au plus)
    minuteurPrefs = setTimeout(() => { fetch("/api/prefs", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prefs: S }) }).catch(() => {}); }, 800);
  };
  window.addEventListener("pagehide", () => {          // fermeture de la fenêtre : dernier envoi immédiat
    try { if (minuteurPrefs) { clearTimeout(minuteurPrefs); navigator.sendBeacon && fetch("/api/prefs", { method: "POST", keepalive: true, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prefs: S }) }); } } catch (e) { /* rien */ }
  });
  const G = { bars: [], sec: 1800, chiffres: 5, source: "", smv: [], seances: [], mode: "direct", rt: null, outil: "curseur",
    dessins: [], annuler: [], refaire: [], crea: null, sel: -1, mesure: null, positions: [], hover: null, play: null, live: null, drag: null,
    catalogue: [], prix: {}, charge: false, indSeries: {}, dernierPrix: null, zooms: [], trace: [] };
  G.multi = new Set();                                   // Ctrl + clic : plusieurs dessins sélectionnés (comme TradingView)
  const selection = () => { const s = new Set(G.multi); if (G.dessins[G.sel]) s.add(G.dessins[G.sel]); return [...s].filter(d => G.dessins.includes(d)); };

  // ================================================================== heure
  const dstUS = d => { const y = d.getUTCFullYear(), m = new Date(Date.UTC(y, 2, 1)), n = new Date(Date.UTC(y, 10, 1));
    const deb = Date.UTC(y, 2, 1 + (7 - m.getUTCDay()) % 7 + 7, 7), fin = Date.UTC(y, 10, 1 + (7 - n.getUTCDay()) % 7, 6); return d >= deb && d < fin; };
  const dstUE = d => { const y = d.getUTCFullYear(), dm = new Date(Date.UTC(y, 2, 31)), do_ = new Date(Date.UTC(y, 9, 31));
    return d >= Date.UTC(y, 2, 31 - dm.getUTCDay(), 1) && d < Date.UTC(y, 9, 31 - do_.getUTCDay(), 1); };
  function decalage(t) {
    const d = new Date(t * 1000);
    if (S.fuseau === "utc") return 0;
    if (S.fuseau === "ny") return (dstUS(d) ? -4 : -5) * 3600;
    if (S.fuseau === "paris") return (dstUE(d) ? 2 : 1) * 3600;
    return -d.getTimezoneOffset() * 60;
  }
  const lt = t => t + decalage(t);
  const chiffres = () => S.reg.precision === "auto" ? G.chiffres : +S.reg.precision;
  const fp = (p, ch) => p == null || isNaN(p) ? "—" : Number(p).toFixed(ch ?? chiffres());
  const hexA = (h, a) => { const n = parseInt(String(h).slice(1, 7), 16) || 0; return `rgba(${n >> 16},${n >> 8 & 255},${n & 255},${a})`; };
  const fdate = t => new Date(lt(t) * 1000).toLocaleString(LOC, { timeZone: "UTC", weekday: "short", day: "2-digit", month: "short", year: "2-digit", hour: "2-digit", minute: "2-digit" });
  const nomActif = a => (G.catalogue.find(x => x.code === a) || {}).nom || a;
  const catActif = a => (G.catalogue.find(x => x.code === a) || {}).categorie || "";
  function toast(t, ok = true) {
    const el = document.createElement("div"); el.className = "toast"; el.style.borderLeftColor = ok ? VERT : ROUGE; el.textContent = t;
    $("#toasts").appendChild(el); setTimeout(() => el.remove(), 5500);
  }
  // Fenêtre de confirmation dans la page, façon TradingView (jamais la boîte « localhost indique » du navigateur).
  // demander("Supprimer ?", { ok: "Supprimer" }) -> Promise<boolean> ; saisir("Nom :", "défaut") -> Promise<texte|null>
  function boiteDialogue(message, { ok = "Supprimer", annuler = "Annuler", danger = true, titre = "", valeur = null } = {}) {
    return new Promise(fin => {
      const fond = document.createElement("div"); fond.className = "boite-fond";
      fond.innerHTML = `<div class="boite" role="dialog" aria-modal="true">${titre ? `<div class="boite-titre">${esc(titre)}</div>` : ""}
        <div class="boite-texte"></div>${valeur != null ? `<input class="boite-saisie" maxlength="60">` : ""}
        <div class="boite-boutons">${annuler != null ? `<button class="boite-non">${esc(annuler)}</button>` : ""}<button class="boite-oui ${danger ? "danger" : ""}">${esc(ok)}</button></div></div>`;
      fond.querySelector(".boite-texte").textContent = message;
      const champ = fond.querySelector(".boite-saisie"); if (champ) champ.value = valeur;
      const fermer = r => { document.removeEventListener("keydown", touche, true); fond.remove(); fin(r); };
      const oui = () => fermer(champ ? champ.value : true), non = () => fermer(champ ? null : false);
      const touche = e => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); non(); } else if (e.key === "Enter") { e.preventDefault(); e.stopPropagation(); oui(); } };
      fond.querySelector(".boite-oui").onclick = oui; if (fond.querySelector(".boite-non")) fond.querySelector(".boite-non").onclick = non;
      fond.addEventListener("mousedown", e => { if (e.target === fond) non(); });
      document.addEventListener("keydown", touche, true);
      document.body.appendChild(fond);
      (champ || fond.querySelector(".boite-oui")).focus(); if (champ) champ.select();
    });
  }
  const demander = (message, o) => boiteDialogue(message, o);
  const saisir = (message, valeur = "", o = {}) => boiteDialogue(message, Object.assign({ ok: "Enregistrer", danger: false, valeur }, o));
  // Erreurs JavaScript de la page : remontées au journal de sécurité (une fois par message et par ouverture)
  {
    const vus = new Set();
    const remonter = (message, source, ligne) => {
      const cle = String(message).slice(0, 120); if (!cle || vus.has(cle) || vus.size > 20) return; vus.add(cle);
      try { fetch("/api/erreur-page", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: cle, source: String(source || "").slice(-60), ligne: ligne || 0 }) }).catch(() => {}); } catch (e) { /* rien */ }
    };
    window.addEventListener("error", e => { if (e.message && !/ResizeObserver|Script error/.test(e.message)) remonter(e.message, e.filename, e.lineno); });
    window.addEventListener("unhandledrejection", e => { const m = e.reason && (e.reason.message || String(e.reason)); if (m && !/Failed to fetch|NetworkError|aborted|ServiceWorker/i.test(m)) remonter("Promesse : " + m, "", 0); });
  }
  // Serveur injoignable (PC redémarré, serveur arrêté) : message clair, puis rechargement tout seul dès qu'il revient
  let serveurPerdu = null;
  function signalerServeurPerdu() {
    if (serveurPerdu) return;
    serveurPerdu = document.createElement("div");
    serveurPerdu.style.cssText = "position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(19,23,34,.88);color:#fff;font:15px sans-serif;text-align:center;padding:24px";
    const invite = location.port === "8781";
    serveurPerdu.innerHTML = '<div style="max-width:520px;line-height:1.5"><b style="font-size:18px">'
      + (invite ? "Le PC qui partage MaBoussole Graphiques ne répond plus" : "Le logiciel MaBoussole Graphiques est arrêté sur ce PC") + "</b><br><br>"
      + (invite ? "Il est peut-être éteint, en veille ou déconnecté du réseau. Demandez à la personne qui vous a donné le code de le rallumer.<br><br>"
                : "Ouvrez « MaBoussole Graphiques » depuis le menu Démarrer de Windows (ou son raccourci du Bureau) : il redémarre en quelques secondes.<br><br>")
      + '<span style="opacity:.75">Cette page se recharge toute seule dès qu’il répond.</span></div>';
    document.body.appendChild(serveurPerdu);
    const essai = async () => {
      try { const r = await fetch("/api/ping", { cache: "no-store" }); if (r.ok) { location.reload(); return; } } catch (e) { /* toujours arrêté */ }
      setTimeout(essai, 3000);
    };
    setTimeout(essai, 3000);
  }
  async function api(url, corps) {
    let r;
    try { r = await fetch(url, corps ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(corps) } : undefined); }
    catch (e) { signalerServeurPerdu(); throw e; }
    if (r.status === 401) { location.href = "/acces"; throw new Error("code d'accès requis"); }   // invité dont le code a été révoqué
    return r.json();
  }

  // ================================================================== graphique
  const zone = $("#zone"), calque = $("#calque");
  let chart, serie, sale = true;
  function couleursBougies() {
    const r = S.reg, tr = "rgba(0,0,0,0)";
    return { up: r.corps ? r.corpsH : tr, down: r.corps ? r.corpsB : tr, bordUp: r.bord ? r.bordH : r.corps ? r.corpsH : tr, bordDown: r.bord ? r.bordB : r.corps ? r.corpsB : tr,
      mecheUp: r.meche ? r.mecheH : tr, mecheDown: r.meche ? r.mecheB : tr };
  }
  function optionsCurseur() {
    const r = S.reg, cu = S.curseur || "curseur", lb = S.theme === "clair" ? "#131722" : "#363a45";
    const l = cu === "curseur" ? { visible: true, labelVisible: true, color: r.curseurC, style: +r.curseurStyle, labelBackgroundColor: lb } : { visible: false, labelVisible: cu === "point", labelBackgroundColor: lb };
    return { mode: LW.CrosshairMode.Normal, vertLine: l, horzLine: { ...l } };
  }
  function optionsTheme() {
    const r = S.reg;
    return {
      layout: { attributionLogo: false, textColor: r.texteC, fontSize: +r.taille || 12,
        background: r.fondType === "degrade" ? { type: LW.ColorType.VerticalGradient, topColor: r.fond, bottomColor: r.fond2 } : { type: LW.ColorType.Solid, color: r.fond },
        fontFamily: '-apple-system, BlinkMacSystemFont, "Trebuchet MS", Roboto, Ubuntu, sans-serif' },
      grid: { vertLines: { color: r.grilleVC, visible: r.grilleV }, horzLines: { color: r.grilleHC, visible: r.grilleH } },
      rightPriceScale: { borderColor: r.bordC, mode: S.comparer && S.comparer.length ? 2 : +S.echelle, invertScale: !!S.inverse },
      timeScale: { borderColor: r.bordC, timeVisible: true, secondsVisible: false, rightOffset: +r.margeDroite || 0 },
      crosshair: optionsCurseur(),
      watermark: { visible: S.filigrane && !(S.inds || []).some(x => x.id === "filigraneAG" && !x.cache) && !S.masquerInd, text: `${S.actif}, ${FILI_UNITE[S.unite]}`, fontSize: 72, color: hexA(r.filigraneC, 0.07), horzAlign: "center", vertAlign: "center" },
      localization: { locale: LOC, priceFormatter: p => fp(p) },
    };
  }
  function creerGraphique() {
    chart = nouveauGraphique($("#graph"), Object.assign({ autoSize: true }, optionsTheme()));
    chart.timeScale().applyOptions({ barSpacing: 6 });
    chart.timeScale().subscribeVisibleLogicalRangeChange(r => { sale = true; if (r && r.from < 500) chargerPlusAncien(); });   // comme TradingView : le passé arrive avant d'atteindre le bord
    chart.subscribeCrosshairMove(p => {
      const n = nVis(), i = p && p.logical != null ? Math.round(p.logical) : null;
      G.survol = i != null && i >= 0 && i < n ? i : null;
      legende(); sale = true;
    });
    creerSerie();
  }
  function creerSerie() {
    if (serie) { for (const p of G.positions) retirerLignes(p); chart.removeSeries(serie); }
    const c = couleursBougies(), pf = { type: "price", precision: chiffres(), minMove: Math.pow(10, -chiffres()) };
    const t = S.type;
    if (t === "barres") serie = chart.addBarSeries({ upColor: S.reg.corpsH, downColor: S.reg.corpsB, priceFormat: pf, thinBars: false });
    else if (t === "ligne" || t === "marqueurs" || t === "escalier") serie = chart.addLineSeries({ color: BLEU, lineWidth: 2, priceFormat: pf, lineType: t === "escalier" ? 1 : 0, pointMarkersVisible: t === "marqueurs" });
    else if (t === "zone") serie = chart.addAreaSeries({ lineColor: BLEU, topColor: "rgba(41,98,255,.28)", bottomColor: "rgba(41,98,255,.02)", lineWidth: 2, priceFormat: pf });
    else if (t === "base") serie = chart.addBaselineSeries({ baseValue: { type: "price", price: 0 }, priceFormat: pf, topLineColor: VERT, bottomLineColor: ROUGE,
      topFillColor1: "rgba(8,153,129,.28)", topFillColor2: "rgba(8,153,129,.05)", bottomFillColor1: "rgba(242,54,69,.05)", bottomFillColor2: "rgba(242,54,69,.28)" });
    else if (t === "colonnes") serie = chart.addHistogramSeries({ color: BLEU, priceFormat: pf });
    else serie = chart.addCandlestickSeries({
      upColor: t === "creuses" ? "rgba(0,0,0,0)" : c.up, downColor: c.down, borderUpColor: c.bordUp, borderDownColor: c.bordDown,
      wickUpColor: c.mecheUp, wickDownColor: c.mecheDown, priceFormat: pf });
    serie.applyOptions({ priceLineVisible: S.reg.ligneDernier, lastValueVisible: S.reg.etiqDernier });
    for (const p of G.positions) lignesPosition(p, true);
    for (const k in G.indSeries) { for (const s of G.indSeries[k]) chart.removeSeries(s); }
    G.indSeries = {};
  }
  function nVis() {
    if (G.mode !== "replay" || G.rt == null) return G.bars.length;
    let lo = 0, hi = G.bars.length;
    while (lo < hi) { const m = (lo + hi) >> 1; if (G.bars[m][0] + G.sec <= G.rt) lo = m + 1; else hi = m; }
    return lo;
  }
  function heikin(v) {
    const out = []; let po, pc;
    for (const b of v) {
      const c = (b[1] + b[2] + b[3] + b[4]) / 4, o = po == null ? (b[1] + b[4]) / 2 : (po + pc) / 2;
      out.push([b[0], o, Math.max(b[2], o, c), Math.min(b[3], o, c), c, b[5]]); po = o; pc = c;
    }
    return out;
  }
  function pointsSerie(v) {
    v = v.filter(b => b && b[0] != null && b[1] != null && b[2] != null && b[3] != null && b[4] != null);   // jamais de bougie incomplète au graphique
    const t = S.type;
    if (t === "heikin") v = heikin(v);
    if (["ligne", "marqueurs", "escalier", "zone", "base"].includes(t)) return v.map(b => ({ time: lt(b[0]), value: b[4] }));
    if (t === "colonnes") return v.map(b => ({ time: lt(b[0]), value: b[4], color: b[4] >= b[1] ? "rgba(8,153,129,.7)" : "rgba(242,54,69,.7)" }));
    if (S.reg.clotPrec) {
      const c = couleursBougies();
      return v.map((b, i) => {
        const h = b[4] >= (i ? v[i - 1][4] : b[1]), pt = { time: lt(b[0]), open: b[1], high: b[2], low: b[3], close: b[4] };
        if (t === "barres") pt.color = h ? S.reg.corpsH : S.reg.corpsB;
        else { pt.color = t === "creuses" && h ? "rgba(0,0,0,0)" : h ? c.up : c.down; pt.borderColor = h ? c.bordUp : c.bordDown; pt.wickColor = h ? c.mecheUp : c.mecheDown; }
        return pt;
      });
    }
    return v.map(b => ({ time: lt(b[0]), open: b[1], high: b[2], low: b[3], close: b[4] }));
  }
  function donnees() {
    const v = G.bars.slice(0, nVis());
    if (S.type === "base" && v.length) serie.applyOptions({ baseValue: { type: "price", price: v[Math.max(0, v.length - 300)][4] } });
    serie.setData(pointsSerie(v));
    indicateurs(v);
    if (G.compSeries && Object.keys(G.compSeries).length) majComparaisons();
    if (G.mode === "replay" && G.cells) G.cells.forEach(donneesCellule);
    legende(); sale = true;
  }
  function ajouterBougie(b) {
    if (S.type === "heikin" || S.reg.clotPrec) { donnees(); return; }
    const pts = pointsSerie([b]); serie.update(pts[0]);
    indicateurs(G.bars.slice(0, nVis()));
    legende(); sale = true;
  }

  // ================================================================== calculs des indicateurs
  const sma = (a, n) => { const o = Array(a.length).fill(null); let s = 0, k = 0; for (let i = 0; i < a.length; i++) { if (a[i] == null) { s = 0; k = 0; continue; } s += a[i]; k++; if (k > n) { s -= a[i - n]; k = n; } if (k === n) o[i] = s / n; } return o; };
  const ema = (a, n) => { const o = Array(a.length).fill(null); let e = null; const al = 2 / (n + 1); for (let i = 0; i < a.length; i++) { if (a[i] == null) continue; e = e == null ? a[i] : e + al * (a[i] - e); o[i] = e; } return o.map((x, i) => i < n - 1 ? null : x); };
  const rma = (a, n) => { const o = Array(a.length).fill(null); let r = null, s = 0, k = 0; for (let i = 0; i < a.length; i++) { if (a[i] == null) continue; if (r == null) { s += a[i]; k++; if (k === n) { r = s / n; o[i] = r; } } else { r = (r * (n - 1) + a[i]) / n; o[i] = r; } } return o; };
  const wma = (a, n) => a.map((_, i) => { if (i < n - 1) return null; let s = 0, w = 0; for (let j = 0; j < n; j++) { s += a[i - j] * (n - j); w += n - j; } return s / w; });
  const hh = (a, n) => a.map((_, i) => i < n - 1 ? null : Math.max(...a.slice(i - n + 1, i + 1)));
  const ll = (a, n) => a.map((_, i) => i < n - 1 ? null : Math.min(...a.slice(i - n + 1, i + 1)));
  const ecartType = (a, n) => { const m = sma(a, n); return a.map((_, i) => { if (m[i] == null) return null; let s = 0; for (let j = i - n + 1; j <= i; j++) s += (a[j] - m[i]) ** 2; return Math.sqrt(s / n); }); };
  const vrai = (H, L, C) => H.map((h, i) => i ? Math.max(h - L[i], Math.abs(h - C[i - 1]), Math.abs(L[i] - C[i - 1])) : h - L[i]);
  const op = (a, b, f) => a.map((x, i) => x == null || b[i] == null ? null : f(x, b[i]));
  const decaler = (a, k) => a.map((_, i) => { const j = i - k; return j >= 0 && j < a.length ? a[j] : null; });
  function rsiCalc(C, n) { const g = C.map((c, i) => i ? Math.max(c - C[i - 1], 0) : null), l = C.map((c, i) => i ? Math.max(C[i - 1] - c, 0) : null); const ag = rma(g, n), al = rma(l, n); return ag.map((x, i) => x == null || al[i] == null ? null : al[i] === 0 ? 100 : 100 - 100 / (1 + x / al[i])); }
  function calculer(ind, v) {
    const O = v.map(b => b[1]), H = v.map(b => b[2]), L = v.map(b => b[3]), C = v.map(b => b[4]), V = v.map(b => b[5] || 0);
    const p = Object.assign({}, INDS[ind.id].p, ind.p);
    const L1 = (data, couleur, nom, w = 1.5, extra = {}) => ({ type: "ligne", data, couleur, nom, w, ...extra });
    switch (ind.id) {
      case "vol": return [{ type: "hist", nom: "Vol", data: V, couleurs: v.map(b => b[4] >= b[1] ? "rgba(8,153,129,.35)" : "rgba(242,54,69,.35)"), echelle: "vol" }];
      case "sma": return [L1(sma(C, p.periode), p.couleur, "MM " + p.periode)];
      case "ema": return [L1(ema(C, p.periode), p.couleur, "MME " + p.periode)];
      case "wma": return [L1(wma(C, p.periode), p.couleur, "MMP " + p.periode)];
      case "vwap": {
        const o = []; let jour = null, pv = 0, vv = 0;
        v.forEach((b, i) => { const d = Math.floor(b[0] / 86400); if (d !== jour) { jour = d; pv = 0; vv = 0; } const tp = (H[i] + L[i] + C[i]) / 3, w = V[i] || 1; pv += tp * w; vv += w; o.push(pv / vv); });
        return [L1(o, p.couleur, "VWAP")];
      }
      case "bb": { const m = sma(C, p.periode), s = ecartType(C, p.periode);
        return [L1(m, "#ff6d00", "Base", 1), L1(op(m, s, (a, b) => a + p.ecart * b), p.couleur, "Haut"), L1(op(m, s, (a, b) => a - p.ecart * b), p.couleur, "Bas")]; }
      case "keltner": { const m = ema(C, p.periode), a = rma(vrai(H, L, C), p.periode);
        return [L1(m, p.couleur, "Base", 1), L1(op(m, a, (x, y) => x + p.multi * y), p.couleur, "Haut"), L1(op(m, a, (x, y) => x - p.multi * y), p.couleur, "Bas")]; }
      case "donchian": { const h = hh(H, p.periode), l = ll(L, p.periode);
        return [L1(h, p.couleur, "Haut"), L1(l, p.couleur, "Bas"), L1(op(h, l, (a, b) => (a + b) / 2), "#787b86", "Milieu", 1)]; }
      case "enveloppe": { const m = sma(C, p.periode);
        return [L1(m, p.couleur, "Base", 1), L1(m.map(x => x == null ? null : x * (1 + p.pct / 100)), p.couleur, "Haut"), L1(m.map(x => x == null ? null : x * (1 - p.pct / 100)), p.couleur, "Bas")]; }
      case "ichimoku": {
        const mid = n => op(hh(H, n), ll(L, n), (a, b) => (a + b) / 2), tk = mid(p.tenkan), kj = mid(p.kijun);
        return [L1(tk, "#2962ff", "Tenkan", 1), L1(kj, "#b71c1c", "Kijun", 1), L1(decaler(op(tk, kj, (a, b) => (a + b) / 2), p.kijun), "#43a047", "Senkou A", 1),
          L1(decaler(mid(p.senkou), p.kijun), "#ef5350", "Senkou B", 1), L1(decaler(C, -p.kijun), "rgba(67,160,71,.6)", "Chikou", 1)];
      }
      case "psar": {
        const o = Array(v.length).fill(null); if (v.length < 3) return [];
        let haussier = C[1] >= C[0], af = p.pas, ep = haussier ? H[0] : L[0], sar = haussier ? L[0] : H[0];
        for (let i = 1; i < v.length; i++) {
          sar = sar + af * (ep - sar);
          if (haussier) { sar = Math.min(sar, L[i - 1], i > 1 ? L[i - 2] : L[i - 1]); if (L[i] < sar) { haussier = false; sar = ep; ep = L[i]; af = p.pas; } else if (H[i] > ep) { ep = H[i]; af = Math.min(af + p.pas, p.max); } }
          else { sar = Math.max(sar, H[i - 1], i > 1 ? H[i - 2] : H[i - 1]); if (H[i] > sar) { haussier = true; sar = ep; ep = H[i]; af = p.pas; } else if (L[i] < ep) { ep = L[i]; af = Math.min(af + p.pas, p.max); } }
          o[i] = sar;
        }
        return [L1(o, p.couleur, "SAR", 1, { points: true })];
      }
      case "supertrend": {
        const a = rma(vrai(H, L, C), p.periode), haut = Array(v.length).fill(null), bas = Array(v.length).fill(null);
        let fu = null, fl = null, tend = 1;
        for (let i = 0; i < v.length; i++) {
          if (a[i] == null) continue;
          const m = (H[i] + L[i]) / 2, bu = m + p.multi * a[i], bl = m - p.multi * a[i];
          fu = fu == null || bu < fu || C[i - 1] > fu ? bu : fu; fl = fl == null || bl > fl || C[i - 1] < fl ? bl : fl;
          if (tend === 1 && C[i] < fl) tend = -1; else if (tend === -1 && C[i] > fu) tend = 1;
          if (tend === 1) bas[i] = fl; else haut[i] = fu;
        }
        return [L1(bas, VERT, "Haussier", 2), L1(haut, ROUGE, "Baissier", 2)];
      }
      case "rsi": return [L1(rsiCalc(C, p.periode), p.couleur, "RSI " + p.periode)];
      case "macd": { const m = op(ema(C, p.rapide), ema(C, p.lente), (a, b) => a - b), s = ema(m.map(x => x), p.signal);
        const sg = (() => { const idx = m.findIndex(x => x != null); if (idx < 0) return m; const e = ema(m.slice(idx), p.signal); return Array(idx).fill(null).concat(e); })();
        const h = op(m, sg, (a, b) => a - b);
        return [{ type: "hist", nom: "Histogramme", data: h, couleurs: h.map((x, i) => x == null ? null : x >= 0 ? (i && h[i - 1] != null && x < h[i - 1] ? "#b2dfdb" : "#26a69a") : (i && h[i - 1] != null && x > h[i - 1] ? "#ffcdd2" : "#ef5350")) },
          L1(m, "#2962ff", "MACD"), L1(sg, "#ff6d00", "Signal")]; void s; }
      case "stoch": { const h = hh(H, p.k), l = ll(L, p.k), raw = C.map((c, i) => h[i] == null ? null : h[i] === l[i] ? 50 : 100 * (c - l[i]) / (h[i] - l[i]));
        const k = sma(raw, p.lissage), d = sma(k, p.d); return [L1(k, "#2962ff", "%K"), L1(d, "#ff6d00", "%D")]; }
      case "stochrsi": { const r = rsiCalc(C, p.rsi), idx = r.findIndex(x => x != null); if (idx < 0) return [];
        const rr = r.slice(idx), h = hh(rr, p.stoch), l = ll(rr, p.stoch), raw = rr.map((x, i) => h[i] == null ? null : h[i] === l[i] ? 50 : 100 * (x - l[i]) / (h[i] - l[i]));
        const k = sma(raw, p.k), d = sma(k, p.d), pad = Array(idx).fill(null); return [L1(pad.concat(k), "#2962ff", "K"), L1(pad.concat(d), "#ff6d00", "D")]; }
      case "cci": { const tp = v.map((b, i) => (H[i] + L[i] + C[i]) / 3), m = sma(tp, p.periode);
        return [L1(tp.map((x, i) => { if (m[i] == null) return null; let md = 0; for (let j = i - p.periode + 1; j <= i; j++) md += Math.abs(tp[j] - m[i]); md /= p.periode; return md ? (x - m[i]) / (0.015 * md) : 0; }), p.couleur, "CCI " + p.periode)]; }
      case "adx": {
        const up = H.map((h, i) => i ? h - H[i - 1] : 0), dn = L.map((l, i) => i ? L[i - 1] - l : 0);
        const pdm = up.map((u, i) => u > dn[i] && u > 0 ? u : 0), mdm = dn.map((d, i) => d > up[i] && d > 0 ? d : 0);
        const tr = rma(vrai(H, L, C), p.periode), pp = rma(pdm, p.periode), mm = rma(mdm, p.periode);
        const pdi = op(pp, tr, (a, b) => b ? 100 * a / b : 0), mdi = op(mm, tr, (a, b) => b ? 100 * a / b : 0);
        const dx = op(pdi, mdi, (a, b) => a + b ? 100 * Math.abs(a - b) / (a + b) : 0);
        return [L1(rma(dx, p.periode), "#ff6d00", "ADX", 2), L1(pdi, "#2962ff", "+DI", 1), L1(mdi, "#f23645", "−DI", 1)];
      }
      case "williams": { const h = hh(H, p.periode), l = ll(L, p.periode); return [L1(C.map((c, i) => h[i] == null || h[i] === l[i] ? null : -100 * (h[i] - c) / (h[i] - l[i])), p.couleur, "%R " + p.periode)]; }
      case "momentum": return [L1(C.map((c, i) => i >= p.periode ? c - C[i - p.periode] : null), p.couleur, "Mom " + p.periode)];
      case "roc": return [L1(C.map((c, i) => i >= p.periode ? 100 * (c - C[i - p.periode]) / C[i - p.periode] : null), p.couleur, "ROC " + p.periode)];
      case "ao": { const m = v.map((b, i) => (H[i] + L[i]) / 2), a = op(sma(m, 5), sma(m, 34), (x, y) => x - y);
        return [{ type: "hist", nom: "AO", data: a, couleurs: a.map((x, i) => x == null ? null : i && a[i - 1] != null && x >= a[i - 1] ? "#26a69a" : "#ef5350") }]; }
      case "atr": return [L1(rma(vrai(H, L, C), p.periode), p.couleur, "ATR " + p.periode)];
      case "obv": { let s = 0; return [L1(C.map((c, i) => { if (i) s += c > C[i - 1] ? V[i] : c < C[i - 1] ? -V[i] : 0; return s; }), p.couleur, "OBV")]; }
      case "tdi": { const r = rsiCalc(C, p.rsi), idx = r.findIndex(x => x != null); if (idx < 0) return [];
        const rr = r.slice(idx), pad = a => Array(idx).fill(null).concat(a), m = sma(rr, p.bande), e = ecartType(rr, p.bande);
        return [L1(pad(op(m, e, (a, b) => a + p.ecart * b)), p.cBandes, "Bande haute", 1), L1(pad(op(m, e, (a, b) => a - p.ecart * b)), p.cBandes, "Bande basse", 1),
          L1(pad(m), p.cMilieu, "Ligne du marché", 1.5), L1(pad(sma(rr, p.prix)), p.cPrix, "Prix RSI", 2), L1(pad(sma(rr, p.signal)), p.cSignal, "Signal", 1.5)]; }
      case "mfi": { const tp = v.map((b, i) => (H[i] + L[i] + C[i]) / 3);
        return [L1(tp.map((x, i) => { if (i < p.periode) return null; let pos = 0, neg = 0; for (let j = i - p.periode + 1; j <= i; j++) { const f = tp[j] * (V[j] || 1); if (tp[j] > tp[j - 1]) pos += f; else if (tp[j] < tp[j - 1]) neg += f; } return neg ? 100 - 100 / (1 + pos / neg) : 100; }), p.couleur, "MFI " + p.periode)]; }
    }
    return [];
  }
  // gestion des séries des indicateurs et de la place des oscillateurs
  function indicateurs(v) {
    const actifs = S.inds.filter(x => !INDS[x.id].calque);
    for (const uid of Object.keys(G.indSeries)) if (!actifs.some(x => x.uid === uid)) { for (const s of G.indSeries[uid]) chart.removeSeries(s); delete G.indSeries[uid]; }
    const oscs = actifs.filter(x => INDS[x.id].osc && !x.cache);
    const h = oscs.length ? Math.min(0.22, 0.62 / oscs.length) : 0;
    G.oscZones = oscs.map((x, j) => ({ uid: x.uid, haut: 1 - (oscs.length - j) * h, bas: 1 - (oscs.length - j - 1) * h }));
    serie.priceScale().applyOptions({ scaleMargins: { top: (+S.reg.margeHaut || 0) / 100, bottom: oscs.length * h + (S.inds.some(x => x.id === "vol" && !x.cache) ? 0.02 : 0) + (+S.reg.margeBas || 0) / 100 } });
    G.valeursInd = {};
    for (const ind of actifs) {
      const sorties = calculer(ind, v), echelleOsc = "osc_" + ind.uid;
      let ss = G.indSeries[ind.uid];
      if (!ss || ss.length !== sorties.length || ss._type !== S.type) {
        if (ss) for (const s of ss) chart.removeSeries(s);
        ss = sorties.map(o => {
          const commun = { priceLineVisible: false, lastValueVisible: !!INDS[ind.id].osc && S.reg.etiqInd, crosshairMarkerVisible: false, priceScaleId: o.echelle || (INDS[ind.id].osc ? echelleOsc : "right") };
          if (o.type === "hist") return chart.addHistogramSeries(Object.assign(commun, { priceFormat: o.echelle === "vol" ? { type: "volume" } : { type: "price", precision: 4, minMove: 0.0001 } }));
          return chart.addLineSeries(Object.assign(commun, { color: o.couleur, lineWidth: o.w, lineVisible: !o.points, pointMarkersVisible: !!o.points, pointMarkersRadius: 1.5 }));
        });
        ss._type = S.type; G.indSeries[ind.uid] = ss;
        if (INDS[ind.id].niveaux && ss[0]) for (const n of INDS[ind.id].niveaux) ss[sorties.length - 1].createPriceLine({ price: n, color: "#9598a1", lineWidth: 1, lineStyle: 2, axisLabelVisible: false, title: "" });
      }
      sorties.forEach((o, k) => {
        ss[k].applyOptions({ visible: !ind.cache && !S.masquerInd, ...(o.type === "ligne" ? { color: o.couleur } : {}) });
        ss[k].setData(o.data.map((x, i) => x == null ? { time: lt(v[i][0]) } : o.type === "hist" ? { time: lt(v[i][0]), value: x, color: o.couleurs ? o.couleurs[i] : undefined } : { time: lt(v[i][0]), value: x }));
      });
      G.valeursInd[ind.uid] = sorties.map(o => ({ nom: o.nom, couleur: o.couleur || "#787b86", data: o.data }));
      const z = G.oscZones.find(x => x.uid === ind.uid);
      if (z) chart.priceScale(echelleOsc).applyOptions({ scaleMargins: { top: z.haut + 0.02, bottom: 1 - z.bas + 0.01 }, borderVisible: false });
      if (sorties.some(o => o.echelle === "vol")) chart.priceScale("vol").applyOptions({ scaleMargins: { top: 1 - oscs.length * h - 0.14, bottom: oscs.length * h } });
    }
  }

  // ================================================================== légende
  function legende() {
    const n = nVis(), i = G.survol != null ? G.survol : n - 1, b = G.bars[i];
    if (!b) { $("#legende").innerHTML = ""; return; }
    const v = b[4] - b[1], pct = b[1] ? v / b[1] * 100 : 0, c = v >= 0 ? VERT : ROUGE;
    const r = S.reg;
    let html = `<div class="l1">${r.lTitre ? `<b>${esc(nomActif(S.actif))}</b> · ${LIB_UNITE[S.unite]} · ` : ""}${r.lSource ? `<span class="discret">${esc(G.source.split(" (")[0])}</span>` : ""}
      ${r.lOHLC ? `&nbsp; O<b style="color:${c}">${fp(b[1])}</b> H<b style="color:${c}">${fp(b[2])}</b> B<b style="color:${c}">${fp(b[3])}</b> C<b style="color:${c}">${fp(b[4])}</b>` : ""}
      ${r.lVar ? `<span style="color:${c}">${v >= 0 ? "+" : ""}${fp(v)} (${v >= 0 ? "+" : ""}${pct.toFixed(2)} %)</span>` : ""}
      ${r.lVol && b[5] ? `&nbsp; Vol <b>${Math.round(b[5]).toLocaleString(LOC)}</b>` : ""}</div>`;
    for (const ind of (r.lIndTitres || r.lIndValeurs) ? S.inds : []) {
      const d = INDS[ind.id], p = Object.assign({}, d.p, ind.p);
      const params = d.calque ? "" : Object.entries(p).filter(([k, x]) => typeof x === "number").map(([, x]) => x).join(" ");
      let val = "";
      if (ind.id === "smv") { const ph = phaseSMV(G.bars[i] ? G.bars[i][0] : null); val = ph ? `<span class="val" style="color:${SMV[ph.nom][0]}">${esc(libSMV(ph))}</span>` : ""; }
      else if (G.valeursInd && G.valeursInd[ind.uid]) val = G.valeursInd[ind.uid].map(o => o.data[i] != null ? `<span class="val" style="color:${o.couleur}">${ind.id === "vol" ? Math.round(o.data[i]).toLocaleString(LOC) : fp(o.data[i], Math.abs(o.data[i]) > 50 ? 2 : G.chiffres)}</span>` : "").join(" ");
      html += `<div class="ligne-ind ${ind.cache ? "cachee" : ""}" data-uid="${ind.uid}">${r.lIndTitres ? `<span>${esc(d.court)} ${params}</span>` : ""} ${r.lIndValeurs ? val : ""}
        <span class="actions"><button data-act="voir" title="${ind.cache ? "Afficher" : "Masquer"}">${ind.cache ? "◌" : "👁"}</button>${Object.keys(d.p).length ? '<button data-act="param" title="Paramètres">⚙</button>' : ""}<button data-act="suppr" title="Retirer">✕</button></span></div>`;
    }
    (S.comparer || []).forEach((code, k) => {
      const d = G.compData[code] || [], t = b[0]; let x = null; for (let j = d.length - 1; j >= 0; j--) if (d[j][0] <= t) { x = d[j]; break; }
      html += `<div class="ligne-ind" data-comp="${code}"><span style="color:${COUL_COMP[k % 3]};font-weight:600">${esc(code)}</span> <span class="val">${x ? fp(x[4], x[4] > 500 ? 2 : x[4] > 20 ? 3 : 5) : "—"}</span>
        <span class="actions"><button data-act="comp-suppr" title="Retirer la comparaison">✕</button></span></div>`;
    });
    $("#legende").innerHTML = html;
    const last = G.bars[n - 1];
    if (last) { $("#qPrixV").textContent = fp(last[4]); $("#qPrixA").textContent = fp(last[4]); }
    $("#ordreRapide").style.top = ($("#legende").offsetHeight + 14) + "px";
    if (S.vueDroite === "donnees") majDonnees();
  }
  function phaseSMV(t) {
    if (t == null) return null; let ph = null;
    for (const s of G.smv) if (s.t <= t) ph = s;
    return ph;
  }

  // ================================================================== chargement
  async function charger(fin) {
    G.charge = true; $("#chargement").style.display = "flex";
    $("#chargement").textContent = "Chargement de " + S.actif + " " + LIB_UNITE[S.unite] + "…"
      + (fin && fin < Date.now() / 1000 - 360 * 86400 ? " (historique ancien : la première fois, jusqu'à une minute ; ensuite, instantané)" : "");
    // le reste de l'historique arrive quand on fait défiler vers la gauche ; les unités calculées (45 min, secondes…) partent de 1 000 bougies pour s'ouvrir vite
    const natif = ["M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1", "MN"].includes(S.unite);
    G.finHistorique = false; G.videsHisto = 0;
    let r;
    const cle = S.actif + "|" + S.unite, jeton = (G.jeton = (G.jeton || 0) + 1);
    const url = fin ? urlPremieresBougies() + "&fin=" + Math.floor(fin) : urlPremieresBougies();
    const pre = PRECHARGE && PRECHARGE.url === url ? PRECHARGE.rep : null; PRECHARGE = null;   // la demande lancée au démarrage, si c'est la même
    try { r = await (pre ? pre.catch(() => api(url)) : api(url)); } catch (e) { r = { erreur: "serveur injoignable" }; }
    if (jeton !== G.jeton || cle !== S.actif + "|" + S.unite) return false;     // un chargement plus récent a été demandé entre-temps
    G.charge = false; $("#chargement").style.display = "none";
    if (r.erreur) { toast("⚠ " + r.erreur, false); return false; }
    Object.assign(G, { bars: r.bougies || [], debutHisto: r.debut || null, sec: r.secondes, chiffres: r.chiffres, source: r.source, smv: r.smv || [], seances: r.seances || [] });
    if (r.smv_autorise === false) retirerSMV();
    chart.applyOptions(optionsTheme());
    creerSerie(); donnees();
    if (S.vueDroite === "objets") majObjets();
    S.comparer = S.comparer.filter(c => c !== S.actif); for (const c of Object.keys(G.compSeries)) { try { chart.removeSeries(G.compSeries[c]); } catch (e) { /* rien */ } } G.compSeries = {};
    if (S.comparer.length) chargerComparaisons(); else chart.priceScale("right").applyOptions({ mode: +S.echelle });
    $("#nomSymbole").textContent = S.actif;
    majOnglet();
    chargerEvenements();
    G.dernierPrix = G.bars.length ? G.bars[G.bars.length - 1][4] : null;
    if (G.mode === "replay" && G.rt != null) afficherPrixReplay();
    else document.title = `${S.actif} ${fp(G.dernierPrix)} · MaBoussole Graphiques`;
    if (!fin && G.mode !== "replay" && natif) setTimeout(() => chargerPlusAncien(), 50);   // le reste de l'historique (années anciennes comprises), sans attendre
    return true;
  }
  async function chargerEvenements() {
    const actif = S.actif;
    try { const r = await api(`/api/evenements?actif=${actif}&t0=${G.bars.length ? G.bars[0][0] : 0}`); if (actif === S.actif) { G.evenements = r.evenements || []; sale = true; } }
    catch (e) { G.evenements = []; }
  }
  // historique plus ancien, chargé par morceaux quand on fait défiler vers la gauche
  async function chargerPlusAncien() {
    if (G.chargePlus || G.finHistorique || G.charge || !G.bars.length || Date.now() < (G.attenteHisto || 0)) return;
    G.chargePlus = true;
    const premier = G.bars[0][0], cle = S.actif + "|" + S.unite;
    const att = setTimeout(() => toast("Chargement de l'historique plus ancien…"), 1500);
    let r = null;
    const lot = secondesU(S.unite) < 3600 ? 1500 : 3000;   // petites unités : lots plus petits, donc plus rapides
    try { r = await api(`/api/bougies?actif=${S.actif}&unite=${S.unite}&n=${lot}&fin=${premier - 1}`); } catch (e) { r = null; }
    clearTimeout(att); G.chargePlus = false;
    if (!r || r.erreur) {                                // source momentanément lente : on réessaie tout seul, sans conclure à la fin de l'historique
      G.attenteHisto = Date.now() + 15000;
      setTimeout(() => { const vu = chart.timeScale().getVisibleLogicalRange(); if (vu && vu.from < 500) chargerPlusAncien(); }, 15500);
      return;
    }
    if (cle !== S.actif + "|" + S.unite || !G.bars.length || G.bars[0][0] !== premier) return;
    const anciens = (r.bougies || []).filter(b => b[0] < premier);
    if (!anciens.length) {                          // vraie fin seulement après 3 réponses vides de suite (un raté passager arrive)
      G.videsHisto = (G.videsHisto || 0) + 1;
      if (G.videsHisto >= 3) G.finHistorique = true;
      return;
    }
    G.videsHisto = 0;
    const ts = chart.timeScale(), rg = ts.getVisibleLogicalRange(), k = anciens.length;
    G.bars = anciens.concat(G.bars);
    const vus = new Set(G.smv.map(x => x.t));
    G.smv = (r.smv || []).filter(x => !vus.has(x.t)).concat(G.smv).sort((a, b) => a.t - b.t);
    const debutSeances = G.seances.length ? G.seances[0][0] : Infinity;
    G.seances = (r.seances || []).filter(x => x[0] < debutSeances).concat(G.seances);
    donnees();
    if (rg) ts.setVisibleLogicalRange({ from: rg.from + k, to: rg.to + k });
    const vu = ts.getVisibleLogicalRange();             // toujours près du bord : on enchaîne le lot suivant
    if (vu && vu.from < 500) setTimeout(chargerPlusAncien, 30);
  }
  function normaliser(d) {                              // ancien format (t1, p1, t2, p2) -> points
    if (d.pts) return d;
    const pts = [{ t: d.t1 ?? (G.bars[0] ? G.bars[0][0] : 0), p: d.p1 }]; if (d.t2 != null) pts.push({ t: d.t2, p: d.p2 });
    return { id: Math.random().toString(36).slice(2, 10), type: d.type === "ray" ? "hray" : d.type, pts, c: d.couleur, txt: d.texte };
  }
  async function chargerDessins() {
    const actif = S.actif; let liste = [];
    try { liste = ((await api("/api/dessins?actif=" + actif)).dessins || []).map(normaliser); } catch (e) { liste = []; }
    if (actif !== S.actif) return;
    G.dessins = liste;
    G.annuler = []; G.refaire = []; G.sel = -1; G.multi.clear(); barreDessin(); tableAlertes();
  }
  let tSave = null;
  function sauverDessins(tout_de_suite) {
    clearTimeout(tSave);
    const actif = S.actif, liste = G.dessins;
    const envoyer = () => api("/api/dessins", { actif, dessins: liste }).then(r => { if (r && r.ok === false) toast("⚠ Dessins non enregistrés : " + (r.message || "erreur"), false); })
      .catch(() => toast("⚠ Dessins non enregistrés (serveur injoignable)", false));
    if (tout_de_suite) envoyer(); else tSave = setTimeout(envoyer, 400);
    tableAlertes(); if (S.vueDroite === "objets") majObjets();
  }
  function memoriser() { G.annuler.push(JSON.stringify(G.dessins)); if (G.annuler.length > 80) G.annuler.shift(); G.refaire = []; }
  function annuler() { if (!G.annuler.length) return; const n0 = G.dessins.length; G.refaire.push(JSON.stringify(G.dessins)); G.dessins = JSON.parse(G.annuler.pop()); G.sel = -1; G.multi.clear(); barreDessin(); sauverDessins(); sale = true;
    toast(G.dessins.length < n0 ? "Dernier dessin annulé (Ctrl+Z) · Ctrl+Y pour le remettre" : "Action annulée (Ctrl+Z) · Ctrl+Y pour la refaire"); }
  function refaire() { if (!G.refaire.length) return; G.annuler.push(JSON.stringify(G.dessins)); G.dessins = JSON.parse(G.refaire.pop()); G.sel = -1; G.multi.clear(); barreDessin(); sauverDessins(); sale = true; }

  // ================================================================== géométrie du calque
  function geo() {   // le moteur ne convertit que des index entiers : on interpole entre deux bougies voisines
    const ts = chart.timeScale(), r = ts.getVisibleLogicalRange() || { from: 0 };
    const ref = Math.round(r.from), base = ts.logicalToCoordinate(ref) ?? 0, sp = ((ts.logicalToCoordinate(ref + 1) ?? base + 6) - base) || 6;
    return { W: ts.width(), H: zone.clientHeight - ts.height(), sp, x: i => base + (i - ref) * sp, ix: x => ref + (x - base) / sp,
      y: p => serie.priceToCoordinate(p), py: y => serie.coordinateToPrice(y) };
  }
  function idxDe(t) {
    const b = G.bars, n = b.length;
    if (!n) return 0;
    if (t <= b[0][0]) return (t - b[0][0]) / G.sec;
    if (t >= b[n - 1][0]) return n - 1 + (t - b[n - 1][0]) / G.sec;
    let lo = 0, hi = n - 1;
    while (hi - lo > 1) { const m = (lo + hi) >> 1; if (b[m][0] <= t) lo = m; else hi = m; }
    return lo + Math.min(1, (t - b[lo][0]) / G.sec);
  }
  function tDe(i) {
    const b = G.bars, n = b.length;
    if (!n) return 0;
    if (i <= 0) return b[0][0] + i * G.sec;
    if (i >= n - 1) return b[n - 1][0] + (i - n + 1) * G.sec;
    const k = Math.floor(i); return b[k][0] + (i - k) * Math.min(G.sec, b[k + 1][0] - b[k][0]);
  }
  function tailleCalque() {
    const dpr = window.devicePixelRatio || 1, w = zone.clientWidth, h = zone.clientHeight;
    calque.width = w * dpr; calque.height = h * dpr; calque.style.width = w + "px"; calque.style.height = h + "px";
    calque.getContext("2d").setTransform(dpr, 0, 0, dpr, 0, 0); sale = true;
  }
  function rafraichir() { if (sale && serie) { sale = false; try { peindre(); } catch (e) { if (!G.charge) console.warn("calque", e); } } }
  function boucle() { rafraichir(); requestAnimationFrame(boucle); }
  setInterval(() => { sale = true; rafraichir(); }, 500);
  const indActif = id => !S.masquerInd && S.inds.find(x => x.id === id && !x.cache);
  const tirets = s => s === 1 ? [6, 4] : s === 2 ? [2, 3] : [];

  // ================================================================== peinture du calque
  function peindre() {
    const c = calque.getContext("2d"), g = geo(), n = nVis(), clair = S.theme === "clair";
    c.clearRect(0, 0, calque.width, calque.height);
    if (!n) return;
    const basPrix = (G.oscZones && G.oscZones.length ? G.oscZones[0].haut : 1) * g.H;   // bas de la zone des prix (au-dessus des oscillateurs)
    c.save(); c.beginPath(); c.rect(0, 0, g.W, basPrix); c.clip();
    const r = chart.timeScale().getVisibleLogicalRange() || { from: 0, to: n };
    const i0 = Math.max(0, Math.floor(r.from)), i1 = Math.min(n - 1, Math.ceil(r.to));
    const t0 = tDe(i0), t1 = tDe(i1 + 1), tFin = G.bars[n - 1][0] + G.sec, intraday = G.sec <= 3600;
    const X = t => g.x(idxDe(t) - 0.5);
    // Filigrane AG FX
    const fag = indActif("filigraneAG");
    if (G.agFili !== !!fag) { G.agFili = !!fag; try { chart.applyOptions({ watermark: optionsTheme().watermark }); } catch (e) { /* rien */ } }   // AG FX remplace le filigrane du symbole
    if (fag) {
      const p = Object.assign({}, INDS.filigraneAG.p, fag.p), T = Math.min(200, Math.max(12, +p.taille || 72)), pos = String(p.position || "centre").toLowerCase();
      const y = pos.startsWith("h") ? T + 20 : pos.startsWith("b") ? basPrix - T * 0.6 - 30 : basPrix / 2;
      c.save(); c.globalAlpha = Math.min(100, Math.max(1, +p.opacite || 18)) / 100; c.fillStyle = p.couleur; c.textAlign = "center"; c.textBaseline = "middle";
      c.font = `bold ${T}px sans-serif`; c.fillText(p.texte || "AG FX", g.W / 2, y);
      if (p.sousTitre) { c.font = `${Math.round(T * 0.22)}px sans-serif`; c.fillText(p.sousTitre, g.W / 2, y + T * 0.68); }
      if (p.infos) {                                   // en bas au centre, comme TradingView : « 19/11/2026 » puis « XAUUSD | D »
        const ti = Math.min(40, Math.max(9, +p.tailleInfos || 16)), u = S.unite || "", m = u.match(/^([SMHDWN])(\d+)$/);
        const cu = u === "MN" ? "M" : !m ? u : m[1] === "S" ? m[2] + "s" : m[1] === "M" ? m[2] : m[1] === "H" ? m[2] + "h" : m[1] === "D" ? (m[2] === "1" ? "D" : m[2] + "D") : m[1] === "W" ? (m[2] === "1" ? "W" : m[2] + "W") : m[2] + "M";
        const j = new Date(), date = [j.getDate(), j.getMonth() + 1].map(x => String(x).padStart(2, "0")).join("/") + "/" + j.getFullYear();
        c.globalAlpha = Math.min(1, (Math.min(100, Math.max(1, +p.opacite || 18)) / 100) * 3); c.font = `${ti}px sans-serif`;
        c.fillText(date, g.W / 2, basPrix - ti * 2.6); c.fillText(`${S.actif} | ${cu}`, g.W / 2, basPrix - ti * 1.2);
      }
      c.restore();
    }
    // Calendrier du propriétaire (lignes reçues de son serveur seulement)
    const smv = indActif("smv");
    if (smv) {
      const p = Object.assign({}, INDS.smv.p, smv.p), lignes = G.smv.filter(s => s.t <= tFin);
      lignes.forEach((s, k) => {
        const xa = X(s.t), xb = k + 1 < lignes.length ? X(lignes[k + 1].t) : g.x(n - 1 + 0.5);
        if (xb < 0 || xa > g.W) return;
        const col = SMV[s.nom][0];
        if (p.phases) { c.fillStyle = col + "0d"; c.fillRect(xa, 0, xb - xa, g.H); }
        if (p.lignes) { c.setLineDash([6, 4]); c.strokeStyle = col; c.lineWidth = 1.3; c.beginPath(); c.moveTo(xa, 0); c.lineTo(xa, g.H); c.stroke(); c.setLineDash([]); c.lineWidth = 1; }
        if (p.libelles && xb - xa > 60) { c.fillStyle = col; c.font = "bold 11px sans-serif"; c.fillText(libSMV(s) + (s.nom === "S1" ? " · " + s.mois : ""), Math.max(xa, 44) + 5, basPrix - 8); }
      });
    }
    // killzones
    if (indActif("kz") && intraday) {
      const d0 = Math.floor(t0 / 86400) * 86400;
      for (let d = d0; d <= t1; d += 86400) for (const [nom, a, b, col] of KZ) {
        if (d + a * 3600 > tFin) continue;
        const xa = X(d + a * 3600), xb = X(Math.min(d + b * 3600, tFin)); if (xb < 0 || xa > g.W) continue;
        c.fillStyle = col + "12"; c.fillRect(xa, 0, xb - xa, g.H); if (xb - xa > 40) { c.fillStyle = col; c.font = "10px sans-serif"; c.fillText(nom, xa + 3, 14); }
      }
    }
    // ICT Session Killzones : boîtes des sessions et killzones, CBDR, hauts et bas prolongés jusqu'à être touchés
    const ikz = indActif("ictkz");
    if (ikz && intraday) {
      const p = Object.assign({}, INDS.ictkz.p, ikz.p), dec = (+p.decalage || 0) * 3600, op = Math.min(60, Math.max(0, +p.opacite || 0)) / 100;
      const hm = v => { const m = String(v || "").replace(/\s/g, "").match(/^(\d{1,2}):?(\d{2})-(\d{1,2}):?(\d{2})$/); if (!m) return null; const a = (+m[1]) * 60 + (+m[2]), b = (+m[3]) * 60 + (+m[4]); return [a, b <= a ? b + 1440 : b]; };
      const zones = [["asie", "Asie", p.cAsie, 0], ["londres", "Londres", p.cLondres, 0], ["newyork", "New York", p.cNewyork, 0],
        ["asieKz", "Asie KZ", p.cAsie, 1], ["lokz", "LOKZ", p.cLondres, 1], ["nykz", "NYKZ", p.cNewyork, 1], ["lckz", "LCKZ", p.cLckz, 1], ["cbdr", "CBDR", p.cCbdr, 1]]
        .map(([k, nom, col, kz]) => ({ nom, col, kz, h: hm(p[k]) })).filter(z => z.h);
      const d0 = Math.floor(t0 / 86400) * 86400 - 86400; c.font = "10px sans-serif";
      for (let d = d0; d <= t1; d += 86400) for (const z of zones) {
        const ta = d + z.h[0] * 60 - dec, tb = d + z.h[1] * 60 - dec; if (ta > tFin || tb < t0 - 86400) continue;
        const ia = Math.max(0, Math.ceil(idxDe(ta) - 1e-9)), ib = Math.min(n - 1, Math.ceil(idxDe(Math.min(tb, tFin)) - 1e-9) - 1); if (ib < ia) continue;
        let hi = -Infinity, lo = Infinity; for (let i = ia; i <= ib; i++) { hi = Math.max(hi, G.bars[i][2]); lo = Math.min(lo, G.bars[i][3]); }
        const xa = g.x(ia - 0.5), xb = g.x(ib + 0.5), ya = g.y(hi), yb = g.y(lo); if (ya == null || yb == null) continue;
        if (z.kz && p.hautsBas && tb <= tFin) {                  // haut et bas de la killzone terminée, prolongés jusqu'au premier contact
          for (const [niv, haut] of [[hi, true], [lo, false]]) {
            let j = ib + 1; while (j < n && (haut ? G.bars[j][2] < niv : G.bars[j][3] > niv)) j++;
            const y = g.y(niv), xf = j < n ? g.x(j) : g.W; if (y == null || xf < 0 || xb > g.W) continue;
            c.strokeStyle = z.col; c.globalAlpha = j < n ? 0.35 : 0.8; c.lineWidth = 1; c.setLineDash(j < n ? [2, 3] : []); c.beginPath(); c.moveTo(xb, y); c.lineTo(xf, y); c.stroke(); c.setLineDash([]); c.globalAlpha = 1;
            if (j >= n && p.noms) { c.fillStyle = z.col; c.fillText(z.nom + (haut ? ".H" : ".L"), Math.min(g.W - 50, xf - 48), y - 3); }
          }
        }
        if (xb < 0 || xa > g.W) continue;
        c.globalAlpha = z.kz ? op * 1.4 : op; c.fillStyle = z.col; c.fillRect(xa, ya, xb - xa, yb - ya); c.globalAlpha = 1;
        c.strokeStyle = z.col; c.lineWidth = 1; c.setLineDash(z.kz ? [] : [4, 3]); c.globalAlpha = 0.6; c.strokeRect(xa + 0.5, ya + 0.5, xb - xa - 1, yb - ya); c.globalAlpha = 1; c.setLineDash([]);
        if (p.noms && xb - xa > 24) { c.fillStyle = z.col; c.fillText(z.nom, xa + 2, z.kz ? yb + 11 : ya - 4); }
      }
    }
    // boîtes des séances
    if (indActif("seances") && intraday) {
      c.font = "11px sans-serif";
      for (const [a, b, k] of G.seances) {
        if (k === "nyo" || b < t0 || a > t1) continue;
        const ia = Math.ceil(idxDe(a) - 1e-9), ib = Math.min(n - 1, Math.ceil(idxDe(b) - 1e-9) - 1);
        if (ib < ia || ia > n - 1) continue;
        let hi = -Infinity, lo = Infinity;
        for (let i = Math.max(0, ia); i <= ib; i++) { hi = Math.max(hi, G.bars[i][2]); lo = Math.min(lo, G.bars[i][3]); }
        const xa = g.x(ia - 0.5), xb = g.x(ib + 0.5), ya = g.y(hi), yb = g.y(lo);
        if (ya == null || yb == null) continue;
        const [nom, col] = SEANCE[k];
        c.fillStyle = col + "14"; c.fillRect(xa, ya, xb - xa, yb - ya);
        c.strokeStyle = col + "66"; c.strokeRect(xa + 0.5, ya + 0.5, xb - xa - 1, yb - ya);
        if (xb - xa > 28) { c.fillStyle = col; c.fillText(nom, xa + 2, ya - 4); }
      }
    }
    // NYO 8h30
    if (indActif("nyo") && intraday) {
      c.setLineDash([2, 3]); c.strokeStyle = clair ? "#787b86" : "#9598a1"; c.font = "10px sans-serif";
      for (const [a, , k] of G.seances) {
        if (k !== "nyo" || a < t0 - 86400 || a > tFin) continue;
        const xx = X(a); if (xx < 0 || xx > g.W) continue;
        c.beginPath(); c.moveTo(xx, 30); c.lineTo(xx, g.H); c.stroke(); c.fillStyle = c.strokeStyle; c.fillText("NYO 8:30", xx + 3, 38);
      }
      c.setLineDash([]);
    }
    // niveaux journaliers / hebdomadaires (calculés sur les bougies déjà visibles)
    const piv = indActif("pivots"), pd = indActif("pdhl"), pw = indActif("pwhl");
    if ((piv || pd || pw) && G.sec < 86400) {
      const groupe = (cle) => { const m = new Map(); for (let i = 0; i < n; i++) { const b = G.bars[i], k = cle(b[0]); const x = m.get(k); if (!x) m.set(k, { k, i0: i, i1: i, h: b[2], l: b[3], c: b[4] }); else { x.i1 = i; x.h = Math.max(x.h, b[2]); x.l = Math.min(x.l, b[3]); x.c = b[4]; } } return [...m.values()]; };
      const seg = (y, xa, xb, col, lib, dash) => { if (y == null) return; c.setLineDash(dash || []); c.strokeStyle = col; c.beginPath(); c.moveTo(xa, y); c.lineTo(xb, y); c.stroke(); c.setLineDash([]); c.fillStyle = col; c.font = "10px sans-serif"; c.fillText(lib, xa + 3, y - 3); };
      if (piv || pd) {
        const jours = groupe(t => Math.floor(t / 86400));
        for (let k = 1; k < jours.length; k++) {
          const j = jours[k], v = jours[k - 1], xa = g.x(j.i0 - 0.5), xb = g.x(j.i1 + 0.5); if (xb < 0 || xa > g.W) continue;
          if (piv) { const col = Object.assign({}, INDS.pivots.p, piv.p).couleur, P = (v.h + v.l + v.c) / 3;
            const niv = { P, R1: 2 * P - v.l, S1: 2 * P - v.h, R2: P + (v.h - v.l), S2: P - (v.h - v.l), R3: v.h + 2 * (P - v.l), S3: v.l - 2 * (v.h - P) };
            for (const [nom, val] of Object.entries(niv)) seg(g.y(val), xa, xb, nom === "P" ? col : nom[0] === "R" ? ROUGE : VERT, nom); }
          if (pd) { const col = Object.assign({}, INDS.pdhl.p, pd.p).couleur; seg(g.y(v.h), xa, xb, col, "PDH", [4, 3]); seg(g.y(v.l), xa, xb, col, "PDL", [4, 3]); }
        }
      }
      if (pw) {
        const sem = groupe(t => Math.floor((t / 86400 + 3) / 7)), col = Object.assign({}, INDS.pwhl.p, pw.p).couleur;
        for (let k = 1; k < sem.length; k++) { const j = sem[k], v = sem[k - 1], xa = g.x(j.i0 - 0.5), xb = g.x(j.i1 + 0.5); if (xb < 0 || xa > g.W) continue; seg(g.y(v.h), xa, xb, col, "PWH", [6, 3]); seg(g.y(v.l), xa, xb, col, "PWL", [6, 3]); }
      }
    }
    // Premium / Discount : plus haut et plus bas des N dernières bougies, moitié haute = premium, moitié basse = discount
    const zpd = indActif("premium");
    if (zpd && n > 2) {
      const p = Object.assign({}, INDS.premium.p, zpd.p), N = Math.max(5, Math.round(p.periode) || 100), fin = n - 1, deb = Math.max(0, n - N);
      let h = -Infinity, l = Infinity;
      for (let i = deb; i <= fin; i++) { if (G.bars[i][2] > h) h = G.bars[i][2]; if (G.bars[i][3] < l) l = G.bars[i][3]; }
      if (h > l && isFinite(h) && isFinite(l)) {
        const R = h - l, lar = Math.min(50, Math.max(1, +p.largeur || 50)) / 100, eq = Math.min(50, Math.max(0, +p.bandeEq || 0)) / 100;
        const xa = g.x(deb - 0.5), xb = p.prolonger ? g.W : g.x(fin + 0.5), op = Math.min(100, Math.max(0, +p.opacite || 0)) / 100, ch = chiffres() ?? 5;
        const zone = (pa, pb, col, nom, enBas) => {
          const ya = g.y(pa), yb = g.y(pb); if (ya == null || yb == null) return;
          const y = Math.min(ya, yb), hz = Math.abs(yb - ya);
          c.globalAlpha = op; c.fillStyle = col; c.fillRect(xa, y, xb - xa, hz); c.globalAlpha = 1;
          if (p.noms && hz > 12) { c.fillStyle = col; c.font = "bold 11px sans-serif"; c.fillText(nom, xa + 6, enBas ? y + hz - 5 : y + 13); }
        };
        zone(h, h - R * lar, p.premium, "Premium", false);
        zone(l + R * lar, l, p.discount, "Discount", true);
        if (eq > 0) zone(l + R * (0.5 + eq / 2), l + R * (0.5 - eq / 2), p.equilibre, "Équilibre", false);
        const ligne = (prix, col, dash, lib) => {
          const y = g.y(prix); if (y == null) return;
          c.strokeStyle = col; c.setLineDash(dash); c.lineWidth = 1; c.beginPath(); c.moveTo(xa, y); c.lineTo(xb, y); c.stroke(); c.setLineDash([]);
          if (p.prix) { c.fillStyle = col; c.font = "10px sans-serif"; const t = `${lib} ${Number(prix).toFixed(ch)}`; c.fillText(t, Math.max(xa + 6, xb - c.measureText(t).width - 6), y - 3); }
        };
        ligne(h, p.premium, [], "Haut"); ligne(l, p.discount, [], "Bas"); ligne(l + R / 2, p.equilibre, [5, 4], "50 %");
      }
    }
    // séparateurs de jours
    if (S.reg.evSeparateurs && intraday) {
      c.strokeStyle = S.reg.bordC; c.setLineDash([4, 4]);
      for (let i = Math.max(1, i0); i <= i1; i++) if (Math.floor(lt(G.bars[i][0]) / 86400) !== Math.floor(lt(G.bars[i - 1][0]) / 86400)) { const x = g.x(i - 0.5); c.beginPath(); c.moveTo(x, 0); c.lineTo(x, g.H); c.stroke(); }
      c.setLineDash([]);
    }
    // événements économiques (calendrier de MaBoussole) : pastilles en bas de la zone des prix
    G.evVus = [];
    if (S.reg.evEco && G.evenements && G.evenements.length) {
      const ok = { fort: S.reg.evFort, moyen: S.reg.evMoyen, faible: S.reg.evFaible }, rang = { fort: 3, moyen: 2, faible: 1 }, cols = { fort: ROUGE, moyen: ORANGE, faible: "#787b86" };
      const paquets = new Map(), yE = basPrix - (smv && Object.assign({}, INDS.smv.p, smv.p).libelles ? 32 : 14);   // au-dessus du libellé SMV
      for (const e of G.evenements) {
        if (!ok[e.impact] || e.t < t0 - G.sec || e.t > t1 + G.sec || (G.mode === "replay" && e.t > tFin)) continue;
        const x = X(e.t); if (x < 0 || x > g.W) continue;
        const k = Math.round(x / 16), p = paquets.get(k) || { x, evs: [] }; p.evs.push(e); paquets.set(k, p);
      }
      c.font = "bold 9px sans-serif"; c.textAlign = "center";
      for (const p of paquets.values()) {
        const fort = p.evs.reduce((a, e) => rang[e.impact] > rang[a] ? e.impact : a, "faible"), devs = [...new Set(p.evs.map(e => e.devise))];
        c.fillStyle = cols[fort]; c.beginPath(); c.arc(p.x, yE, 8, 0, 7); c.fill();
        c.fillStyle = "#fff"; c.fillText(devs.length > 1 ? p.evs.length : devs[0].slice(0, 2), p.x, yE + 3);
        G.evVus.push({ x: p.x, y: yE, evs: p.evs });
      }
      c.textAlign = "left";
    }
    c.restore(); c.save(); c.beginPath(); c.rect(0, 0, g.W, g.H); c.clip();
    // séparateurs des oscillateurs
    for (const z of G.oscZones || []) {
      const y = z.haut * g.H; c.strokeStyle = clair ? "#e0e3eb" : "#2a2e39"; c.beginPath(); c.moveTo(0, y); c.lineTo(g.W, y); c.stroke();
      const ind = S.inds.find(x => x.uid === z.uid); if (ind) { c.fillStyle = clair ? "#787b86" : "#9598a1"; c.font = "11px sans-serif"; c.fillText(INDS[ind.id].court, 8, y + 14); }
    }
    // dessins (dans la zone des prix)
    c.restore(); c.save(); c.beginPath(); c.rect(0, 0, g.W, basPrix); c.clip();
    if (!S.masquer) G.dessins.forEach((d, k) => { if (visible(d) && (d.type !== "alerte" || S.reg.aLignes)) dessin(c, g, d, k === G.sel || G.multi.has(d)); });
    if (G.crea) dessin(c, g, G.crea, true);
    if (G.apercu) dessin(c, g, G.apercu, true);
    if (G.mesure) dessin(c, g, G.mesure, false);
    // positions simulées
    for (const p of S.reg.tPositions ? G.positions : []) {
      const xa = p.t_entree ? X(p.t_entree) : g.x(n - 1), ye = g.y(p.entree), ys = g.y(p.sl), yt = p.tp ? g.y(p.tp) : null;
      if (ye == null || ys == null) continue;
      const xb = Math.min(g.W, Math.max(xa + 40 * g.sp, g.x(n - 1) + 6 * g.sp)), lg = Math.max(0, xb - xa);     // zone limitée, comme sur TradingView
      c.fillStyle = "rgba(242,54,69,.16)"; c.fillRect(xa, Math.min(ye, ys), lg, Math.abs(ys - ye));
      if (yt != null) { c.fillStyle = "rgba(8,153,129,.16)"; c.fillRect(xa, Math.min(ye, yt), lg, Math.abs(yt - ye)); }
    }
    // curseur « démonstration » (traînée qui s'efface) et curseur « point »
    if (G.outil === "curseur" && S.curseur === "demo" && G.trace.length) {
      const maint = Date.now(); G.trace = G.trace.filter(q => maint - q.t < 900);
      for (let k = 1; k < G.trace.length; k++) { const a = G.trace[k - 1], b = G.trace[k]; c.strokeStyle = `rgba(242,54,69,${(1 - (maint - b.t) / 900).toFixed(2)})`; c.lineWidth = 4; c.lineCap = "round"; c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(b.x, b.y); c.stroke(); }
      c.lineWidth = 1; if (G.trace.length) requestAnimationFrame(() => { sale = true; });
    }
    if (G.outil === "curseur" && S.curseur === "point" && G.hover && G.hover.x < g.W) { c.fillStyle = clair ? "#131722" : "#d1d4dc"; c.beginPath(); c.arc(G.hover.x, G.hover.y, 3, 0, 7); c.fill(); }
    // choix du départ du replay
    if (G.outil === "coupe" && G.hover && G.hover.x < g.W) {
      c.fillStyle = clair ? "rgba(255,255,255,.7)" : "rgba(19,23,34,.7)"; c.fillRect(G.hover.x, 0, g.W - G.hover.x, g.H);
      c.strokeStyle = BLEU; c.lineWidth = 2; c.beginPath(); c.moveTo(G.hover.x, 0); c.lineTo(G.hover.x, g.H); c.stroke(); c.lineWidth = 1;
      c.fillStyle = BLEU; c.font = "bold 12px sans-serif"; c.fillText("✂  Départ du replay", G.hover.x + 8, 72);
    }
    c.restore();
    // étiquettes sur les axes
    if (!S.masquer && S.reg.etiqDessins) for (const d of G.dessins) {
      if ((d.type === "alerte" && !S.reg.aLignes) || !visible(d)) continue;
      const col = d.c || (d.type === "alerte" ? S.reg.aCouleur : BLEU);
      if (["hline", "hray", "croix", "etiquette", "alerte"].includes(d.type)) etiquetteY(c, g, d.pts[0].p, col);
      if (["vline", "croix"].includes(d.type)) etiquetteX(c, g, d.pts[0].t, col);
    }
    if (G.sel >= 0 && G.dessins[G.sel]) for (const pt of G.dessins[G.sel].pts) { etiquetteY(c, g, pt.p, BLEU); }
    // compte à rebours de la bougie
    const last = G.bars[n - 1];
    if (S.rebours && G.mode === "direct" && last) {
      const reste = Math.max(0, Math.round(last[0] + G.sec - Date.now() / 1000)), y = g.y(last[4]);
      if (y != null && reste > 0 && reste <= G.sec) {
        const h = Math.floor(reste / 3600), m = Math.floor(reste % 3600 / 60), s = reste % 60;
        const txt = (h ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(s).padStart(2, "0");
        c.fillStyle = last[4] >= last[1] ? VERT : ROUGE; c.globalAlpha = 0.85; c.fillRect(g.W, y + 10, zone.clientWidth - g.W, 16); c.globalAlpha = 1;
        c.fillStyle = "#fff"; c.font = "11px sans-serif"; c.fillText(txt, g.W + 6, y + 22);
      }
    }
    if (G.mode === "replay" && G.rt != null && last) { c.fillStyle = BLEU; c.font = "bold 12px sans-serif"; c.fillText("REPLAY · " + fdate(last[0] + G.sec), 12, g.H - 26); }
    // bulle des événements survolés
    const ev = G.hover && G.evVus && G.evVus.find(q => Math.abs(q.x - G.hover.x) < 10 && Math.abs(q.y - G.hover.y) < 10);
    if (ev) {
      const lignes = ev.evs.slice(0, 8).map(e => [`${fdate(e.t).split(" ").slice(-1)[0]}  ${e.devise}  ${e.titre}`, [e.reel && "Réel " + e.reel, e.prevu && "Prévu " + e.prevu, e.prec && "Préc. " + e.prec].filter(Boolean).join(" · "), e.impact]);
      c.font = "12px sans-serif";
      const w = Math.min(420, Math.max(...lignes.map(l => Math.max(c.measureText(l[0]).width, c.measureText(l[1]).width))) + 24), h = lignes.length * 36 + 26;
      const x = Math.max(4, Math.min(ev.x - w / 2, g.W - w - 4)), y = Math.max(4, ev.y - h - 14);
      c.fillStyle = S.theme === "clair" ? "#ffffff" : "#1e222d"; c.strokeStyle = S.reg.bordC; c.shadowColor = "rgba(0,0,0,.18)"; c.shadowBlur = 10;
      c.fillRect(x, y, w, h); c.shadowBlur = 0; c.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
      c.fillStyle = S.reg.texteC; c.font = "bold 11px sans-serif"; c.fillText(fdate(ev.evs[0].t), x + 12, y + 16);
      lignes.forEach((l, k) => {
        c.fillStyle = { fort: ROUGE, moyen: ORANGE, faible: "#787b86" }[l[2]]; c.fillRect(x + 12, y + 28 + k * 36, 3, 28);
        c.fillStyle = S.reg.texteC; c.font = "12px sans-serif"; c.fillText(l[0].slice(0, 60), x + 20, y + 40 + k * 36);
        c.fillStyle = "#787b86"; c.font = "11px sans-serif"; c.fillText(l[1] || "à venir", x + 20, y + 54 + k * 36);
      });
    }
  }
  function etiquetteY(c, g, p, col) {
    const y = g.y(p); if (y == null) return;
    c.fillStyle = col; c.fillRect(g.W, y - 9, zone.clientWidth - g.W, 18); c.fillStyle = "#fff"; c.font = "12px sans-serif"; c.fillText(fp(p), g.W + 6, y + 4);
  }
  function etiquetteX(c, g, t, col) {
    const x = g.x(idxDe(t)), txt = fdate(t); c.font = "11px sans-serif"; const w = c.measureText(txt).width + 12;
    c.fillStyle = col; c.fillRect(x - w / 2, g.H + 2, w, 20); c.fillStyle = "#fff"; c.fillText(txt, x - w / 2 + 6, g.H + 16);
  }

  // ================================================================== dessin de chaque outil
  const FIBO_RET = [[0, "#787b86"], [0.236, "#f23645"], [0.382, "#ff9800"], [0.5, "#4caf50"], [0.618, "#089981"], [0.705, "#00bcd4"], [0.786, "#2962ff"], [1, "#787b86"]];
  const FIBO_EXT = [[0, "#787b86"], [0.618, "#ff9800"], [1, "#4caf50"], [1.272, "#089981"], [1.618, "#2962ff"], [2, "#9c27b0"], [2.618, "#f23645"]];
  const FIBO_RET_PLUS = [[1.272, "#ff9800"], [1.414, "#f23645"], [1.618, "#2962ff"], [2, "#089981"], [2.272, "#ff9800"], [2.414, "#4caf50"], [2.618, "#f23645"],
    [3, "#00bcd4"], [3.272, "#787b86"], [3.414, "#2962ff"], [3.618, "#9c27b0"], [4, "#f23645"], [4.236, "#e91e63"], [4.272, "#9c27b0"], [4.414, "#e91e63"],
    [4.618, "#ff9800"], [4.764, "#089981"], [-0.272, "#ff9800"], [-0.618, "#00bcd4"]];
  const FIBO_EXT_PLUS = [[0.382, "#ff9800"], [0.5, "#4caf50"], [0.786, "#2962ff"], [3.618, "#9c27b0"], [4.236, "#e91e63"]];
  const NIV_AUTRES = {                                // niveaux par défaut des autres outils Fibonacci (modifiables dans l'onglet « Niveaux »)
    fibocanal: [[0, "#787b86"], [0.618, "#ff9800"], [1, "#4caf50"], [1.618, "#2962ff"], [2.618, "#f23645"]],
    fibotemps: [0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89], fibotempstend: [0, 0.382, 0.5, 0.618, 1, 1.382, 1.618, 2, 2.618, 4.236],
    fiboeventail: [0.25, 0.382, 0.5, 0.618, 0.75, 1], fibocercles: [0.236, 0.382, 0.5, 0.618, 0.786, 1, 1.618],
    fiboarcs: [0.382, 0.5, 0.618, 1], fibocoin: [0.382, 0.5, 0.618, 0.786, 1], pitchfan: [0, 0.382, 0.5, 0.618, 1]
  };
  const FIBO_REGLABLES = new Set(["fibo", "fiboext", ...Object.keys(NIV_AUTRES)]);
  function nivFiboDefaut(type) {                       // niveaux comme TradingView : les principaux affichés, les autres prêts à cocher
    if (NIV_AUTRES[type]) return NIV_AUTRES[type].map(x => Array.isArray(x) ? { v: x[0], c: x[1], on: true } : { v: x, c: "", on: true });
    const ext = type === "fiboext";
    return [...(ext ? FIBO_EXT : FIBO_RET).map(([v, c]) => ({ v, c, on: true })), ...(ext ? FIBO_EXT_PLUS : FIBO_RET_PLUS).map(([v, c]) => ({ v, c, on: false }))];
  }
  const nivActifs = d => nivFibo(d).filter(x => x.on !== false && x.v !== "" && isFinite(+x.v)).map(x => ({ v: +x.v, c: x.c || "" })).sort((a, b) => a.v - b.v);
  function couleurNiv(c, d, x, base) {                 // couleur d'un niveau (ou couleur unique de l'outil)
    const col = (d.uneCouleur ?? !!d.c) ? (d.c || base) : (x.c || base);
    c.strokeStyle = col; c.fillStyle = col; return col;
  }
  const nivFibo = d => Array.isArray(d.niv) && d.niv.length ? d.niv : nivFiboDefaut(d.type);
  const NOMS_MOTIFS = { abcd: ["A", "B", "C", "D"], xabcd: ["X", "A", "B", "C", "D"], cypher: ["X", "A", "B", "C", "D"], trianglemotif: ["A", "B", "C", "D"],
    threedrives: ["", "1", "A", "2", "B", "3", ""], elliott: ["(0)", "(1)", "(2)", "(3)", "(4)", "(5)"], ellcor: ["(0)", "(A)", "(B)", "(C)"],
    elltri: ["(0)", "(A)", "(B)", "(C)", "(D)", "(E)"], ellwxy: ["(0)", "(W)", "(X)", "(Y)"], ellwxyxz: ["(0)", "(W)", "(X)", "(Y)", "(X)", "(Z)"],
    tete: ["", "Épaule G", "", "Tête", "", "Épaule D", ""] };
  const IMAGES = {};
  function ligneInfinie(c, g, a, b, deux) {
    const dx = b.x - a.x, dy = b.y - a.y, L = Math.hypot(dx, dy) || 1, k = 4000 / L;
    c.beginPath(); c.moveTo(deux ? a.x - dx * k : a.x, deux ? a.y - dy * k : a.y); c.lineTo(b.x + dx * k, b.y + dy * k); c.stroke();
  }
  function bulle(c, x, y, txt, fond, coul = "#fff") {
    c.font = "bold 12px sans-serif"; const lignes = String(txt).split("\n"), w = Math.max(...lignes.map(l => c.measureText(l).width)) + 14, h = lignes.length * 16 + 8;
    c.fillStyle = fond; c.fillRect(x - w / 2, y, w, h); c.fillStyle = coul; lignes.forEach((l, i) => c.fillText(l, x - w / 2 + 7, y + 17 + i * 16));
  }
  function texteMulti(c, x, y, txt, taille = 13) { c.font = taille + "px sans-serif"; String(txt).split("\n").forEach((l, i) => c.fillText(l, x, y + i * (taille + 4))); }
  function largeurTexte(c, txt, taille = 13) { c.font = taille + "px sans-serif"; return Math.max(...String(txt).split("\n").map(l => c.measureText(l).width)); }
  function fourcheDessin(c, g, O, B, C2) {
    const M = { x: (B.x + C2.x) / 2, y: (B.y + C2.y) / 2 }, dx = M.x - O.x, dy = M.y - O.y;
    ligneInfinie(c, g, O, M, false); ligneInfinie(c, g, B, { x: B.x + dx, y: B.y + dy }, false); ligneInfinie(c, g, C2, { x: C2.x + dx, y: C2.y + dy }, false);
    c.save(); c.setLineDash([3, 3]); c.beginPath(); c.moveTo(B.x, B.y); c.lineTo(C2.x, C2.y); c.stroke(); c.restore();
  }
  function profilVolume(c, g, i1, i2, xa, largeur, col) {
    i1 = Math.max(0, i1); i2 = Math.min(nVis() - 1, i2); if (i2 - i1 < 1) return;
    let lo = Infinity, hi = -Infinity; for (let i = i1; i <= i2; i++) { lo = Math.min(lo, G.bars[i][3]); hi = Math.max(hi, G.bars[i][2]); }
    const N = 30, pas = (hi - lo) / N || 1, vol = Array(N).fill(0);
    for (let i = i1; i <= i2; i++) { const b = G.bars[i], v = b[5] || 1, a = Math.max(0, Math.floor((b[3] - lo) / pas)), z = Math.min(N - 1, Math.floor((b[2] - lo) / pas)); for (let k = a; k <= z; k++) vol[k] += v / (z - a + 1); }
    const max = Math.max(...vol), poc = vol.indexOf(max), total = vol.reduce((s, x) => s + x, 0);
    const va = new Set([poc]); let s = max, bas = poc, haut = poc;
    while (s < total * 0.7 && (bas > 0 || haut < N - 1)) { const vb = bas > 0 ? vol[bas - 1] : -1, vh = haut < N - 1 ? vol[haut + 1] : -1; if (vh >= vb) { haut++; s += vh; va.add(haut); } else { bas--; s += vb; va.add(bas); } }
    for (let k = 0; k < N; k++) {
      const ya = g.y(lo + (k + 1) * pas), yb = g.y(lo + k * pas); if (ya == null || yb == null) continue;
      c.fillStyle = k === poc ? "rgba(242,54,69,.55)" : va.has(k) ? col + "88" : col + "40"; c.fillRect(xa, ya + 0.5, largeur * vol[k] / max, Math.max(1, yb - ya - 1));
    }
    const yp = g.y(lo + (poc + 0.5) * pas); if (yp != null) { c.strokeStyle = ROUGE; c.lineWidth = 1; c.beginPath(); c.moveTo(xa, yp); c.lineTo(xa + largeur, yp); c.stroke(); }
  }
  // Ligne de tendance façon TradingView : prolonger, extrémités (flèche), point médian, étiquettes de prix, statistiques, texte le long de la ligne
  const LIGNES_TV = new Set(["trend", "rayon", "etendue", "fleche", "info"]);
  const prolLigne = d => ({ g: d.prolG ?? d.type === "etendue", d: d.prolD ?? (d.type === "rayon" || d.type === "etendue") });
  const statsDe = d => d.stats || (d.type === "info" ? "complet" : "masque");
  function bornesLigne(A, B, pr) {                  // les deux bouts de la ligne une fois prolongée
    const L = Math.hypot(B.x - A.x, B.y - A.y) || 1, k = 6000 / L, vx = B.x - A.x, vy = B.y - A.y;
    return [pr.g ? { x: A.x - vx * k, y: A.y - vy * k } : A, pr.d ? { x: B.x + vx * k, y: B.y + vy * k } : B];
  }
  function dureeLisible(sec) {
    const j = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.round(sec % 3600 / 60);
    return j ? `${j} j${h ? " " + h + " h" : ""}` : h ? `${h} h${m ? " " + m + " min" : ""}` : `${m} min`;
  }
  function ligneTV(c, g, d, A, B, col, sel) {
    if (!B) return;
    const pr = prolLigne(d), [P1, P2] = bornesLigne(A, B, pr), an = Math.atan2(B.y - A.y, B.x - A.x);
    c.beginPath(); c.moveTo(P1.x, P1.y); c.lineTo(P2.x, P2.y); c.stroke();
    const fleche = (P, sens) => {                     // pointe de flèche à une extrémité
      const a = an + (sens < 0 ? Math.PI : 0), t = 7 + (d.w || 1.6) * 2;
      c.save(); c.setLineDash([]); c.beginPath(); c.moveTo(P.x, P.y);
      c.lineTo(P.x - t * Math.cos(a - 0.45), P.y - t * Math.sin(a - 0.45)); c.lineTo(P.x - t * Math.cos(a + 0.45), P.y - t * Math.sin(a + 0.45));
      c.closePath(); c.fillStyle = col; c.fill(); c.restore();
    };
    if ((d.boutG || "") === "fleche" && !pr.g) fleche(A, -1);
    if ((d.boutD || (d.type === "fleche" ? "fleche" : "")) === "fleche" && !pr.d) fleche(B, 1);
    const M = { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2 };
    if (d.milieu) { c.save(); c.setLineDash([]); c.beginPath(); c.arc(M.x, M.y, 4, 0, 7); c.fillStyle = S.theme === "clair" ? "#fff" : "#131722"; c.fill(); c.lineWidth = 1.5; c.strokeStyle = col; c.stroke(); c.restore(); }
    if (d.etiqPrix) {                                 // étiquettes de prix aux deux points
      c.save(); c.setLineDash([]); c.font = "bold 11px sans-serif";
      [[A, d.pts[0].p], [B, d.pts[1].p]].forEach(([P, prix]) => {
        const t = fp(prix), w = c.measureText(t).width + 10;
        c.fillStyle = col; c.beginPath(); c.roundRect ? c.roundRect(P.x - w / 2, P.y - 26, w, 18, 3) : c.rect(P.x - w / 2, P.y - 26, w, 18); c.fill();
        c.fillStyle = "#fff"; c.fillText(t, P.x - w / 2 + 5, P.y - 13);
      });
      c.restore();
    }
    const st = statsDe(d);
    if (st !== "masque" && (sel || d.statsToujours || d.type === "info")) {
      const p1 = d.pts[0], p2 = d.pts[1], dp = p2.p - p1.p, nb = Math.round(idxDe(p2.t) - idxDe(p1.t)), deg = Math.atan2(A.y - B.y, B.x - A.x) * 180 / Math.PI;
      const pct = p1.p ? (dp / p1.p * 100).toFixed(2) : "0.00";
      const txt = st === "compact" ? `${dp >= 0 ? "+" : ""}${fp(dp)} (${pct} %)`
        : `${dp >= 0 ? "+" : ""}${fp(dp)} (${pct} %)\n${nb} bougies, ${dureeLisible(Math.abs(nb) * (G.sec || 60))}\n${deg.toFixed(1)}°`;
      const pos = d.statsPos || "droite", X = pos === "gauche" ? A : pos === "centre" ? M : B;
      bulle(c, X.x, Math.max(A.y, B.y) + 10, txt, col);
    }
    if (d.txt) {                                      // texte le long de la ligne
      const h = d.alTxH || "centre", v = d.alTxV || "haut", taille = +d.tTx || 14;
      const P = h === "gauche" ? A : h === "droite" ? B : M;
      let a = an; if (a > Math.PI / 2 || a < -Math.PI / 2) a += Math.PI;   // le texte reste toujours à l'endroit
      c.save(); c.setLineDash([]); c.translate(P.x, P.y); c.rotate(a);
      c.font = `${d.ital ? "italic " : ""}${d.gras ? "bold " : ""}${taille}px sans-serif`; c.fillStyle = d.cTx || col;
      const lignes = String(d.txt).split("\n"), haut = lignes.length * (taille + 3);
      const x0 = h === "gauche" ? 4 : h === "droite" ? -4 : 0;
      c.textAlign = h === "gauche" ? "left" : h === "droite" ? "right" : "center";
      const y0 = v === "bas" ? taille + 4 : v === "milieu" ? taille / 2 - haut / 2 + 2 : -6 - (lignes.length - 1) * (taille + 3);
      lignes.forEach((l, i) => c.fillText(l, x0, y0 + i * (taille + 3)));
      c.restore();
    }
  }
  function rectTV(c, g, d, A, B, col) {               // rectangle comme TradingView : prolonger, bordure, ligne médiane, arrière-plan, texte
    const xa = d.prolG ? 0 : Math.min(A.x, B.x), xb = d.prolD ? g.W : Math.max(A.x, B.x), ya = Math.min(A.y, B.y), yb = Math.max(A.y, B.y), h = yb - ya;
    if (d.fond !== false) { c.fillStyle = d.cFond || col; c.globalAlpha = (d.fondOp ?? 15) / 100; c.fillRect(xa, ya, xb - xa, h); c.globalAlpha = 1; }
    c.strokeStyle = col; c.lineWidth = d.w && d.w !== 1.6 ? d.w : 1; c.setLineDash(tirets(d.s));
    if (d.prolG || d.prolD) { c.beginPath(); c.moveTo(xa, ya); c.lineTo(xb, ya); c.moveTo(xa, yb); c.lineTo(xb, yb);
      if (!d.prolG) { c.moveTo(xa, ya); c.lineTo(xa, yb); } if (!d.prolD) { c.moveTo(xb, ya); c.lineTo(xb, yb); } c.stroke(); }
    else c.strokeRect(xa, ya, xb - xa, h);
    if (d.mediane) { c.strokeStyle = d.cMed || col; c.lineWidth = 1; c.setLineDash(tirets(d.sMed ?? 1)); c.beginPath(); c.moveTo(xa, ya + h / 2); c.lineTo(xb, ya + h / 2); c.stroke(); }
    c.setLineDash([]);
    if (d.txt) {                                       // texte dans le rectangle
      const taille = d.tTx || 14, lignes = String(d.txt).split("\n"), hl = taille + 3, haut = lignes.length * hl, m = 6;
      c.font = `${d.ital ? "italic " : ""}${d.gras ? "bold " : ""}${taille}px sans-serif`; c.fillStyle = d.cTx || col; c.textBaseline = "top";
      const al = d.alTxH || "centre", av = d.alTxV || "haut", gx = Math.min(A.x, B.x), dx = Math.max(A.x, B.x);
      let y0 = av === "haut" ? ya + m : av === "bas" ? yb - haut - m : ya + (h - haut) / 2;
      lignes.forEach((t, i) => { const lw = c.measureText(t).width, x = al === "gauche" ? gx + m : al === "droite" ? dx - lw - m : (gx + dx - lw) / 2; c.fillText(t, x, y0 + i * hl); });
      c.textBaseline = "alphabetic";
    }
  }
  function dessin(c, g, d, sel) {
    const P = d.pts.map(pt => ({ x: g.x(idxDe(pt.t)), y: g.y(pt.p) }));
    if (P.some(p => p.y == null && !["vline", "fdate", "fibotemps", "cycliques"].includes(d.type))) return;
    const col = d.c || (d.type === "zone" ? "#787b86" : d.type === "alerte" ? S.reg.aCouleur : BLEU), w = d.w || (d.type === "surligneur" ? 14 : 1.6);
    c.strokeStyle = col; c.fillStyle = col; c.lineWidth = w; c.setLineDash(tirets(d.s)); c.lineJoin = "round"; c.lineCap = "round";
    const [A, B, C2, D] = P, poly = (pts, ferme) => { c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p.x, p.y) : c.moveTo(p.x, p.y)); if (ferme) c.closePath(); };
    const lib = (p, t, dy = -8) => { c.setLineDash([]); c.font = "bold 12px sans-serif"; c.fillStyle = col; c.fillText(t, p.x - c.measureText(t).width / 2, p.y + dy); };
    const remplir = (a = 0.12) => { c.globalAlpha = a; c.fill(); c.globalAlpha = 1; };
    const fin = () => { poly(P); c.stroke(); };
    switch (d.type) {
      case "trend": case "rayon": case "etendue": case "fleche": if (B) ligneTV(c, g, d, A, B, col, sel); else fin(); break;
      case "marqueurfleche": { if (!B) break; const an = Math.atan2(B.y - A.y, B.x - A.x), L = Math.hypot(B.x - A.x, B.y - A.y), t = Math.max(0, L - 22);
        c.save(); c.translate(A.x, A.y); c.rotate(an); c.beginPath(); c.moveTo(0, -5); c.lineTo(t, -5); c.lineTo(t, -13); c.lineTo(L, 0); c.lineTo(t, 13); c.lineTo(t, 5); c.lineTo(0, 5); c.closePath();
        c.globalAlpha = 0.85; c.fill(); c.globalAlpha = 1; c.restore(); break; }
      case "info": if (B) ligneTV(c, g, d, A, B, col, sel); else fin(); break;
      case "angle": {
        poly([A, B]); c.stroke(); if (!B) break;
        const p1 = d.pts[0], p2 = d.pts[1], dp = p2.p - p1.p, nb = Math.round(idxDe(p2.t) - idxDe(p1.t)), deg = Math.atan2(A.y - B.y, B.x - A.x) * 180 / Math.PI;
        if (d.type === "angle") { c.setLineDash([3, 3]); c.lineWidth = 1; c.beginPath(); c.moveTo(A.x, A.y); c.lineTo(A.x + 60, A.y); c.stroke(); c.beginPath(); c.arc(A.x, A.y, 30, Math.min(0, -deg * Math.PI / 180), Math.max(0, -deg * Math.PI / 180)); c.stroke(); lib({ x: A.x + 45, y: A.y }, deg.toFixed(1) + "°", deg > 0 ? -6 : 16); }
        else bulle(c, (A.x + B.x) / 2, Math.max(A.y, B.y) + 8, `${dp >= 0 ? "+" : ""}${fp(dp)} (${(dp / p1.p * 100).toFixed(2)} %)\n${nb} bougies · ${deg.toFixed(1)}°`, col);
        break;
      }
      case "hline": c.beginPath(); c.moveTo(0, A.y); c.lineTo(g.W, A.y); c.stroke(); break;
      case "alerte": c.setLineDash([6, 4]); c.beginPath(); c.moveTo(0, A.y); c.lineTo(g.W, A.y); c.stroke(); lib({ x: 70, y: A.y }, (d.fait ? "✔ alerte déclenchée " : "⏰ alerte ") + fp(d.pts[0].p), -5); break;
      case "hray": c.beginPath(); c.moveTo(A.x, A.y); c.lineTo(g.W, A.y); c.stroke(); break;
      case "vline": c.beginPath(); c.moveTo(A.x, 0); c.lineTo(A.x, g.H); c.stroke(); break;
      case "croix": c.beginPath(); c.moveTo(0, A.y); c.lineTo(g.W, A.y); c.moveTo(A.x, 0); c.lineTo(A.x, g.H); c.stroke(); break;
      case "canal": {
        poly([A, B]); c.stroke(); if (!C2) break;
        const dy = C2.y - (A.y + (B.y - A.y) * ((C2.x - A.x) / ((B.x - A.x) || 1))), A2 = { x: A.x, y: A.y + dy }, B2 = { x: B.x, y: B.y + dy };
        poly([A2, B2]); c.stroke(); poly([A, B, B2, A2], true); remplir(0.1);
        c.setLineDash([4, 4]); c.lineWidth = 1; poly([{ x: A.x, y: A.y + dy / 2 }, { x: B.x, y: B.y + dy / 2 }]); c.stroke(); break;
      }
      case "regression": {
        if (!B) break;
        let i1 = Math.round(idxDe(d.pts[0].t)), i2 = Math.round(idxDe(d.pts[1].t)); if (i1 > i2) [i1, i2] = [i2, i1]; i1 = Math.max(0, i1); i2 = Math.min(nVis() - 1, i2);
        if (i2 - i1 < 2) { fin(); break; }
        let n = 0, sx = 0, sy = 0, sxx = 0, sxy = 0; for (let i = i1; i <= i2; i++) { const y = G.bars[i][4]; n++; sx += i; sy += y; sxx += i * i; sxy += i * y; }
        const pente = (n * sxy - sx * sy) / (n * sxx - sx * sx || 1), oo = (sy - pente * sx) / n;
        let e = 0; for (let i = i1; i <= i2; i++) e += (G.bars[i][4] - (oo + pente * i)) ** 2; const sd = Math.sqrt(e / n);
        const pt = (i, k) => ({ x: g.x(i), y: g.y(oo + pente * i + k * sd) }), ha = pt(i1, 2), hb = pt(i2, 2), ba = pt(i1, -2), bb = pt(i2, -2);
        if ([ha, hb, ba, bb].some(q => q.y == null)) break;
        poly([ha, hb, bb, ba], true); remplir(0.08); poly([ha, hb]); c.stroke(); poly([ba, bb]); c.stroke(); c.setLineDash([4, 4]); poly([pt(i1, 0), pt(i2, 0)]); c.stroke(); break;
      }
      case "hautbas": { if (!C2) { fin(); break; } poly([A, B]); c.stroke(); c.beginPath(); c.moveTo(A.x, C2.y); c.lineTo(B.x, C2.y); c.stroke(); poly([A, B, { x: B.x, y: C2.y }, { x: A.x, y: C2.y }], true); remplir(0.1); break; }
      case "disjoint": { if (!C2) { fin(); break; } const A2 = { x: A.x, y: C2.y }, B2 = { x: B.x, y: C2.y - (B.y - A.y) }; poly([A, B]); c.stroke(); poly([A2, B2]); c.stroke(); poly([A, B, B2, A2], true); remplir(0.1); break; }
      case "fourche": if (!C2) { fin(); break; } fourcheDessin(c, g, A, B, C2); break;
      case "schiff": if (!C2) { fin(); break; } fourcheDessin(c, g, { x: A.x, y: (A.y + B.y) / 2 }, B, C2); break;
      case "schiffmod": if (!C2) { fin(); break; } fourcheDessin(c, g, { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2 }, B, C2); break;
      case "fourcheint": if (!C2) { fin(); break; } fourcheDessin(c, g, { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2 }, { x: (B.x + C2.x) / 2 - (C2.x - B.x) / 4, y: (B.y + C2.y) / 2 - (C2.y - B.y) / 4 }, { x: (B.x + C2.x) / 2 + (C2.x - B.x) / 4, y: (B.y + C2.y) / 2 + (C2.y - B.y) / 4 }); break;
      case "fibo": case "fiboext": {
        if (!B) break;
        const ext = d.type === "fiboext", p0 = d.pts[0].p, p1 = d.pts[1].p, base = ext ? (d.pts[2] || d.pts[1]).p : p1, inv = !!d.inverser;
        const niv = nivFibo(d).filter(x => x.on !== false && isFinite(+x.v)).map(x => ({ v: +x.v, c: x.c || "#787b86" })).sort((a, b) => a.v - b.v);
        const une = d.uneCouleur ?? !!d.c, col1 = d.c || "#787b86", op = Math.min(100, Math.max(0, d.fondOp ?? 7)) / 100;
        const debut = ext ? (C2 || B).x : Math.min(A.x, B.x), finX = ext ? debut + Math.max(60, Math.abs(B.x - A.x)) : Math.max(A.x, B.x);
        const xa = d.prolG ? 0 : debut, xb = d.prolD === false ? Math.max(finX, xa + 40) : g.W;
        const tiretsT = (d.sT ?? 1) == 1 ? [4, 4] : d.sT == 2 ? [2, 3] : [], coulT = d.cT || "#787b86";
        if (ext && d.tendance !== false) { c.setLineDash(tiretsT); c.lineWidth = 1; poly(P); c.strokeStyle = coulT; c.stroke(); }
        c.setLineDash(d.s == 1 ? [6, 4] : d.s == 2 ? [2, 3] : []); c.lineWidth = d.w && d.w !== 1.6 ? d.w : 1; const tp = d.tp || 11; c.font = tp + "px sans-serif"; let yPrec = null;
        for (const { v: f, c: cc } of niv) {
          const p = ext ? base + (inv ? p0 - p1 : p1 - p0) * f : (inv ? p0 + (p1 - p0) * f : p1 + (p0 - p1) * f), y = g.y(p); if (y == null) continue;
          const coul = une ? col1 : cc;
          if (yPrec != null && d.fond !== false && op > 0) { c.globalAlpha = op; c.fillStyle = coul; c.fillRect(xa, Math.min(y, yPrec), xb - xa, Math.abs(y - yPrec)); c.globalAlpha = 1; }
          c.strokeStyle = coul; c.beginPath(); c.moveTo(xa, y); c.lineTo(xb, y); c.stroke();
          const nom = d.nivAff === false ? "" : d.pct ? `${+(f * 100).toFixed(1)} %` : `${f === 0.5 && !ext ? "0.5 équilibre" : f}`;
          const txt = d.prixAff === false ? nom : nom ? `${nom} (${fp(p)})` : fp(p);
          if (txt) {
            const lw = c.measureText(txt).width, xt = d.etiqPos === "droite" ? xb - lw - 4 : d.etiqPos === "centre" ? (xa + xb - lw) / 2 : xa + 4;
            c.fillStyle = coul; c.fillText(txt, xt, d.etiqV === "bas" ? y + tp + 2 : d.etiqV === "milieu" ? y + tp / 2 - 1 : y - 3);
          }
          yPrec = y;
        }
        c.setLineDash([]); c.lineWidth = 1;
        if (!ext && d.tendance !== false) { poly([A, B]); c.setLineDash(tiretsT); c.strokeStyle = coulT; c.stroke(); c.setLineDash([]); }
        break;
      }
      case "fibocanal": {
        if (!C2) { fin(); break; }
        const dy = C2.y - (A.y + (B.y - A.y) * ((C2.x - A.x) / ((B.x - A.x) || 1))); c.lineWidth = 1; c.font = "11px sans-serif";
        const base = c.strokeStyle;
        for (const x of nivActifs(d)) {
          const f = x.v; couleurNiv(c, d, x, base); const a = { x: A.x, y: A.y + dy * f }, b = { x: B.x, y: B.y + dy * f }; ligneInfinie(c, g, a, b, false); c.fillText(String(f), a.x - 26, a.y + 4);
        }
        break;
      }
      case "fibotemps": { if (!B) break; const di = idxDe(d.pts[1].t) - idxDe(d.pts[0].t); c.lineWidth = 1; c.font = "10px sans-serif";
        const base = c.strokeStyle;
        for (const n of nivActifs(d)) { const f = n.v; couleurNiv(c, d, n, base); const x = g.x(idxDe(d.pts[0].t) + di * f); if (x > g.W) break; if (x < -2000) continue; c.beginPath(); c.moveTo(x, 0); c.lineTo(x, g.H); c.stroke(); c.fillText(String(f), x + 3, 12); } break; }
      case "fibotempstend": { if (!C2) { fin(); break; } const di = idxDe(d.pts[1].t) - idxDe(d.pts[0].t), i0 = idxDe(d.pts[2].t); c.lineWidth = 1; c.font = "10px sans-serif";
        c.setLineDash([4, 4]); poly(P); c.stroke(); c.setLineDash([]);
        const base = c.strokeStyle;
        for (const n of nivActifs(d)) { const f = n.v; couleurNiv(c, d, n, base); const x = g.x(i0 + di * f); if (x > g.W) break; c.beginPath(); c.moveTo(x, 0); c.lineTo(x, g.H); c.stroke(); c.fillText(String(f), x + 3, 24); } break; }
      case "fiboeventail": { if (!B) break; c.lineWidth = 1; c.font = "10px sans-serif";
        const base = c.strokeStyle;
        for (const n of nivActifs(d)) { const f = n.v; couleurNiv(c, d, n, base); const t = { x: B.x, y: A.y + (B.y - A.y) * f }; ligneInfinie(c, g, A, t, false); c.fillText(String(f), t.x + 4, t.y - 2);
          c.globalAlpha = 0.45; ligneInfinie(c, g, A, { x: A.x + (B.x - A.x) * f, y: B.y }, false); c.globalAlpha = 1; }
        c.strokeStyle = base; c.setLineDash([3, 3]); c.strokeRect(Math.min(A.x, B.x), Math.min(A.y, B.y), Math.abs(B.x - A.x), Math.abs(B.y - A.y)); break; }
      case "fibocercles": { if (!B) break; const r = Math.hypot(B.x - A.x, B.y - A.y); c.lineWidth = 1; c.font = "10px sans-serif";
        const base = c.strokeStyle;
        for (const n of nivActifs(d)) { const f = n.v; if (f < 0) continue; couleurNiv(c, d, n, base); c.beginPath(); c.arc(A.x, A.y, r * f, 0, 7); c.stroke(); c.fillText(String(f), A.x + r * f + 3, A.y); } break; }
      case "fibospirale": { if (!B) break; const r0 = Math.hypot(B.x - A.x, B.y - A.y), a0 = Math.atan2(B.y - A.y, B.x - A.x), k = Math.log(1.618) / (Math.PI / 2);
        c.beginPath(); for (let th = -6 * Math.PI; th <= 3 * Math.PI; th += 0.05) { const r = r0 * Math.exp(k * th); if (r > 6000) break; const x = A.x + r * Math.cos(a0 + th), y = A.y + r * Math.sin(a0 + th); th === -6 * Math.PI ? c.moveTo(x, y) : c.lineTo(x, y); } c.stroke();
        c.setLineDash([3, 3]); poly([A, B]); c.stroke(); break; }
      case "fiboarcs": { if (!B) break; const r = Math.hypot(B.x - A.x, B.y - A.y), a = Math.atan2(A.y - B.y, A.x - B.x); c.lineWidth = 1; c.font = "10px sans-serif";
        const base = c.strokeStyle;
        for (const n of nivActifs(d)) { const f = n.v; if (f < 0) continue; couleurNiv(c, d, n, base); c.beginPath(); c.arc(B.x, B.y, r * f, a + Math.PI / 2, a + 3 * Math.PI / 2); c.stroke();
          const am = a + Math.PI; c.fillText(String(f), B.x + r * f * Math.cos(am) + 3, B.y + r * f * Math.sin(am)); }
        c.strokeStyle = base; c.setLineDash([3, 3]); poly([A, B]); c.stroke(); break; }
      case "fibocoin": { if (!C2) { fin(); break; } const r = Math.hypot(B.x - A.x, B.y - A.y), a1 = Math.atan2(B.y - A.y, B.x - A.x), a2 = Math.atan2(C2.y - A.y, C2.x - A.x);
        poly([A, B]); c.stroke(); c.beginPath(); c.moveTo(A.x, A.y); c.lineTo(A.x + r * Math.cos(a2), A.y + r * Math.sin(a2)); c.stroke(); c.lineWidth = 1; c.font = "10px sans-serif";
        const base = c.strokeStyle;
        for (const n of nivActifs(d)) { const f = n.v; if (f < 0) continue; couleurNiv(c, d, n, base); c.beginPath(); c.arc(A.x, A.y, r * f, Math.min(a1, a2), Math.max(a1, a2)); c.stroke(); c.fillText(String(f), A.x + r * f * Math.cos(a1) + 4, A.y + r * f * Math.sin(a1)); } break; }
      case "pitchfan": { if (!C2) { fin(); break; } c.lineWidth = 1; c.font = "10px sans-serif"; const base = c.strokeStyle;
        for (const n of nivActifs(d)) { const f = n.v; couleurNiv(c, d, n, base); const t = { x: B.x + (C2.x - B.x) * f, y: B.y + (C2.y - B.y) * f }; ligneInfinie(c, g, A, t, false); c.fillText(String(f), t.x + 4, t.y - 2); }
        c.strokeStyle = base; c.setLineDash([3, 3]); poly([B, C2]); c.stroke(); break; }
      case "gannboite": case "ganncarre": {
        if (!B) break; const xa = Math.min(A.x, B.x), ya = Math.min(A.y, B.y), W = Math.abs(B.x - A.x), H = Math.abs(B.y - A.y);
        const fr = d.type === "gannboite" ? [0, 0.25, 0.382, 0.5, 0.618, 0.75, 1] : [0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1];
        c.globalAlpha = 0.06; c.fillRect(xa, ya, W, H); c.globalAlpha = 1; c.lineWidth = 1;
        for (const f of fr) { c.globalAlpha = f === 0.5 ? 0.9 : 0.45; c.beginPath(); c.moveTo(xa + W * f, ya); c.lineTo(xa + W * f, ya + H); c.moveTo(xa, ya + H * f); c.lineTo(xa + W, ya + H * f); c.stroke(); }
        c.globalAlpha = 0.7; c.beginPath(); c.moveTo(xa, ya); c.lineTo(xa + W, ya + H); c.moveTo(xa, ya + H); c.lineTo(xa + W, ya); c.stroke(); c.globalAlpha = 1;
        if (d.type === "ganncarre") { c.beginPath(); c.arc(xa, ya + H, Math.min(W, H), -Math.PI / 2, 0); c.stroke(); }
        break;
      }
      case "ganneventail": { if (!B) break; const dx = B.x - A.x, dy = B.y - A.y; c.lineWidth = 1; c.font = "10px sans-serif";
        for (const [nom, kx, ky] of [["8x1", 1, 8], ["4x1", 1, 4], ["3x1", 1, 3], ["2x1", 1, 2], ["1x1", 1, 1], ["1x2", 2, 1], ["1x3", 3, 1], ["1x4", 4, 1], ["1x8", 8, 1]]) {
          const t = { x: A.x + dx * kx, y: A.y + dy * ky }; c.globalAlpha = nom === "1x1" ? 1 : 0.6; ligneInfinie(c, g, A, t, false); c.globalAlpha = 1; c.fillText(nom, A.x + dx * kx / Math.max(kx, ky) + 3, A.y + dy * ky / Math.max(kx, ky)); } break; }
      case "cycliques": { if (!B) break; const dx = Math.abs(B.x - A.x); if (dx < 3) break; c.lineWidth = 1; for (let x = A.x; x <= g.W; x += dx) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, g.H); c.stroke(); } break; }
      case "cyclestemps": { if (!B) break; const dx = Math.abs(B.x - A.x); if (dx < 3) break; for (let x = Math.min(A.x, B.x); x < g.W; x += dx) { c.beginPath(); c.arc(x + dx / 2, A.y, dx / 2, Math.PI, 2 * Math.PI); c.stroke(); } break; }
      case "sinus": { if (!B) break; const dx = B.x - A.x || 1, amp = B.y - A.y; c.beginPath(); for (let x = 0; x <= g.W; x += 2) { const t = (x - A.x) / dx, y = A.y + amp * (1 - Math.cos(Math.PI * t)) / 2; x ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); break; }
      case "prevision": { if (!B) break; c.setLineDash([5, 4]); poly([A, B]); c.stroke(); c.setLineDash([]); c.beginPath(); c.arc(B.x, B.y, 4, 0, 7); c.fill();
        const dp = d.pts[1].p - d.pts[0].p, nb = Math.round(idxDe(d.pts[1].t) - idxDe(d.pts[0].t)); bulle(c, B.x, B.y + 8, `Cible ${fp(d.pts[1].p)}\n${dp >= 0 ? "+" : ""}${fp(dp)} (${(dp / d.pts[0].p * 100).toFixed(2)} %) · ${nb} bougies`, dp >= 0 ? VERT : ROUGE); break; }
      case "motifbarres": { if (!B) break; let i1 = Math.round(idxDe(d.pts[0].t)), i2 = Math.round(idxDe(d.pts[1].t)); if (i1 > i2) [i1, i2] = [i2, i1]; i1 = Math.max(0, i1); i2 = Math.min(nVis() - 1, i2); if (i2 <= i1) break;
        const dec = G.bars[i2][4] - G.bars[i1][1]; c.setLineDash([3, 3]); c.lineWidth = 1; c.strokeRect(g.x(i1 - 0.5), Math.min(A.y, B.y) - 6, g.x(i2 + 0.5) - g.x(i1 - 0.5), Math.abs(B.y - A.y) + 12); c.setLineDash([]);
        c.globalAlpha = 0.45; for (let i = i1; i <= i2; i++) { const b = G.bars[i], x = g.x(i2 + 1 + i - i1), ya = g.y(Math.max(b[1], b[4]) + dec), yb = g.y(Math.min(b[1], b[4]) + dec), yh = g.y(b[2] + dec), yl = g.y(b[3] + dec);
          if ([ya, yb, yh, yl].some(v => v == null)) continue; c.fillStyle = c.strokeStyle = b[4] >= b[1] ? VERT : ROUGE; c.beginPath(); c.moveTo(x, yh); c.lineTo(x, yl); c.stroke(); c.fillRect(x - g.sp * 0.35, ya, g.sp * 0.7, Math.max(1, yb - ya)); } c.globalAlpha = 1; break; }
      case "ghost": { c.globalAlpha = 0.5; c.lineWidth = 1; for (let k = 1; k < d.pts.length; k++) { const i1 = idxDe(d.pts[k - 1].t), i2 = idxDe(d.pts[k].t), n = Math.max(1, Math.round(Math.abs(i2 - i1)));
          for (let j = 0; j < n; j++) { const pa = d.pts[k - 1].p + (d.pts[k].p - d.pts[k - 1].p) * j / n, pb = d.pts[k - 1].p + (d.pts[k].p - d.pts[k - 1].p) * (j + 1) / n, x = g.x(i1 + (i2 - i1) * (j + 0.5) / n);
            const ya = g.y(Math.max(pa, pb)), yb = g.y(Math.min(pa, pb)); if (ya == null || yb == null) continue; c.fillStyle = c.strokeStyle = pb >= pa ? "#787b86" : "#434651"; c.beginPath(); c.moveTo(x, ya - 4); c.lineTo(x, yb + 4); c.stroke(); c.fillRect(x - g.sp * 0.35, ya, g.sp * 0.7, Math.max(1, yb - ya)); } }
        c.globalAlpha = 1; break; }
      case "secteur": { if (!C2) { fin(); break; } const r = Math.hypot(B.x - A.x, B.y - A.y), a1 = Math.atan2(B.y - A.y, B.x - A.x), a2 = Math.atan2(C2.y - A.y, C2.x - A.x);
        c.beginPath(); c.moveTo(A.x, A.y); c.arc(A.x, A.y, r, a1, a2, a2 < a1); c.closePath(); remplir(0.12); c.stroke(); break; }
      case "vwapancre": { const i0 = Math.max(0, Math.round(idxDe(d.pts[0].t))), n = nVis(); let pv = 0, vv = 0; c.beginPath(); let dep = false;
        for (let i = i0; i < n; i++) { const b = G.bars[i], tp = (b[2] + b[3] + b[4]) / 3, v = b[5] || 1; pv += tp * v; vv += v; const x = g.x(i), y = g.y(pv / vv); if (y == null) continue; dep ? c.lineTo(x, y) : c.moveTo(x, y); dep = true; }
        c.stroke(); lib({ x: A.x + 40, y: A.y }, "VWAP ancré", -10); break; }
      case "profilfixe": { if (!B) break; let i1 = Math.round(idxDe(d.pts[0].t)), i2 = Math.round(idxDe(d.pts[1].t)); if (i1 > i2) [i1, i2] = [i2, i1];
        const xa = g.x(i1 - 0.5), xb = g.x(i2 + 0.5); c.lineWidth = 1; c.setLineDash([3, 3]); c.strokeRect(xa, 0, xb - xa, g.H); c.setLineDash([]); profilVolume(c, g, i1, i2, xa, (xb - xa) * 0.7, col); break; }
      case "profilancre": { const i1 = Math.round(idxDe(d.pts[0].t)), i2 = nVis() - 1, xa = g.x(i1 - 0.5), xb = g.x(i2 + 0.5); c.lineWidth = 1; c.beginPath(); c.moveTo(xa, 0); c.lineTo(xa, g.H); c.stroke(); profilVolume(c, g, i1, i2, xa, (xb - xa) * 0.7, col); break; }
      case "rect": case "zone": case "fprixdate": case "mesure": {
        if (!B) break;
        const xa = Math.min(A.x, B.x), xb = d.type === "zone" ? g.W : Math.max(A.x, B.x), ya = Math.min(A.y, B.y), h = Math.abs(B.y - A.y);
        if (d.type === "fprixdate" || d.type === "mesure") {
          const up = d.pts[1].p >= d.pts[0].p, cc = d.c || (up ? BLEU : ROUGE); c.fillStyle = cc; c.globalAlpha = 0.15; c.fillRect(xa, ya, xb - xa, h); c.globalAlpha = 1;
          const dp = d.pts[1].p - d.pts[0].p, nb = Math.round(idxDe(d.pts[1].t) - idxDe(d.pts[0].t)), dur = Math.abs(d.pts[1].t - d.pts[0].t);
          bulle(c, (A.x + B.x) / 2, Math.max(A.y, B.y) + 6, `${dp >= 0 ? "+" : ""}${fp(dp)} (${(dp / d.pts[0].p * 100).toFixed(2)} %)\n${nb} bougies · ${dur >= 86400 ? Math.round(dur / 86400) + " j" : Math.round(dur / 3600) + " h"}`, cc);
        } else if (d.type === "rect") rectTV(c, g, d, A, B, col);
        else { c.globalAlpha = 0.4; c.fillRect(xa, ya, xb - xa, h); c.globalAlpha = 1; }
        break;
      }
      case "rectpivote": { if (!C2) { fin(); break; } const L = Math.hypot(B.x - A.x, B.y - A.y) || 1, nx = -(B.y - A.y) / L, ny = (B.x - A.x) / L, h = (C2.x - A.x) * nx + (C2.y - A.y) * ny;
        poly([A, B, { x: B.x + nx * h, y: B.y + ny * h }, { x: A.x + nx * h, y: A.y + ny * h }], true); remplir(0.15); c.stroke(); break; }
      case "fprix": { if (!B) break; c.lineWidth = 1; c.beginPath(); c.moveTo(A.x - 40, A.y); c.lineTo(A.x + 40, A.y); c.moveTo(A.x - 40, B.y); c.lineTo(A.x + 40, B.y); c.moveTo(A.x, A.y); c.lineTo(A.x, B.y); c.stroke();
        const dp = d.pts[1].p - d.pts[0].p; c.globalAlpha = 0.12; c.fillRect(A.x - 40, Math.min(A.y, B.y), 80, Math.abs(B.y - A.y)); c.globalAlpha = 1;
        bulle(c, A.x, Math.max(A.y, B.y) + 6, `${dp >= 0 ? "+" : ""}${fp(dp)} (${(dp / d.pts[0].p * 100).toFixed(2)} %)`, col); break; }
      case "fdate": { if (!B) break; c.lineWidth = 1; c.beginPath(); c.moveTo(A.x, A.y - 40); c.lineTo(A.x, A.y + 40); c.moveTo(B.x, A.y - 40); c.lineTo(B.x, A.y + 40); c.moveTo(A.x, A.y); c.lineTo(B.x, A.y); c.stroke();
        const nb = Math.round(idxDe(d.pts[1].t) - idxDe(d.pts[0].t)), dur = Math.abs(d.pts[1].t - d.pts[0].t);
        c.globalAlpha = 0.12; c.fillRect(Math.min(A.x, B.x), A.y - 40, Math.abs(B.x - A.x), 80); c.globalAlpha = 1;
        bulle(c, (A.x + B.x) / 2, A.y + 44, `${nb} bougies · ${dur >= 86400 ? (dur / 86400).toFixed(1) + " j" : (dur / 3600).toFixed(1) + " h"}`, col); break; }
      case "cercle": if (B) { c.beginPath(); c.arc(A.x, A.y, Math.hypot(B.x - A.x, B.y - A.y), 0, 7); remplir(0.12); c.stroke(); } break;
      case "ellipse": if (B) { c.beginPath(); c.ellipse((A.x + B.x) / 2, (A.y + B.y) / 2, Math.abs(B.x - A.x) / 2, Math.abs(B.y - A.y) / 2, 0, 0, 7); remplir(0.12); c.stroke(); } break;
      case "triangle": poly(P, P.length === 3); c.stroke(); if (P.length === 3) remplir(0.12); break;
      case "polyligne": poly(P, P.length > 2); if (P.length > 2) remplir(0.12); c.stroke(); break;
      case "arc": { if (!C2) { fin(); break; } const k = { x: 2 * C2.x - (A.x + B.x) / 2, y: 2 * C2.y - (A.y + B.y) / 2 }; c.beginPath(); c.moveTo(A.x, A.y); c.quadraticCurveTo(k.x, k.y, B.x, B.y); remplir(0.12); c.stroke(); break; }
      case "courbe": { if (!C2) { fin(); break; } c.beginPath(); c.moveTo(A.x, A.y); c.quadraticCurveTo(C2.x, C2.y, B.x, B.y); c.stroke(); break; }
      case "doublecourbe": { if (!D) { fin(); break; } c.beginPath(); c.moveTo(A.x, A.y); c.bezierCurveTo(C2.x, C2.y, D.x, D.y, B.x, B.y); c.stroke(); break; }
      case "chemin": case "pinceau": poly(P); c.stroke(); if (d.type === "chemin" && P.length > 1) { const a = P[P.length - 2], b = P[P.length - 1], an = Math.atan2(b.y - a.y, b.x - a.x); c.setLineDash([]); c.beginPath(); c.moveTo(b.x, b.y); c.lineTo(b.x - 10 * Math.cos(an - 0.5), b.y - 10 * Math.sin(an - 0.5)); c.moveTo(b.x, b.y); c.lineTo(b.x - 10 * Math.cos(an + 0.5), b.y - 10 * Math.sin(an + 0.5)); c.stroke(); } break;
      case "surligneur": c.globalAlpha = 0.3; poly(P); c.stroke(); c.globalAlpha = 1; break;
      case "abcd": case "xabcd": case "cypher": case "elliott": case "ellcor": case "elltri": case "ellwxy": case "ellwxyxz": case "tete": case "trianglemotif": case "threedrives": {
        const noms = NOMS_MOTIFS[d.type];
        if ((d.type === "xabcd" || d.type === "cypher") && P.length >= 3) { poly(P.slice(0, 3), true); remplir(0.1); if (P.length === 5) { poly(P.slice(2, 5), true); remplir(0.1); } }
        poly(P); c.stroke();
        if (d.type === "trianglemotif" && P.length === 4) { c.setLineDash([5, 4]); ligneInfinie(c, g, P[0], P[2], false); ligneInfinie(c, g, P[1], P[3], false); c.setLineDash(tirets(d.s)); }
        P.forEach((p, i) => { const haut = i === 0 ? p.y < (P[1] || p).y : p.y < P[i - 1].y; if (noms[i]) lib(p, noms[i], haut ? -8 : 18); });
        const pr = d.pts.map(x => x.p), ratio = (a, b) => Math.abs(b) ? Math.abs(a / b).toFixed(3) : "";
        c.font = "11px sans-serif"; c.fillStyle = col;
        const r = (i, j, k) => { if (P[k]) { const t = ratio(pr[k] - pr[j], pr[j] - pr[i]); c.fillText(t, (P[j].x + P[k].x) / 2 + 6, (P[j].y + P[k].y) / 2); } };
        if (d.type === "abcd") { r(0, 1, 2); r(1, 2, 3); }
        if (d.type === "xabcd" || d.type === "cypher") { r(0, 1, 2); r(1, 2, 3); r(2, 3, 4); if (P[4]) c.fillText((d.type === "cypher" ? "XC " : "AD/XA ") + ratio(pr[4] - (d.type === "cypher" ? pr[3] : pr[1]), d.type === "cypher" ? pr[3] - pr[0] : pr[1] - pr[0]), P[4].x + 8, P[4].y + 4); }
        if (d.type === "tete" && P.length >= 5) { c.setLineDash([5, 4]); ligneInfinie(c, g, P[2], P[4], true); }
        break;
      }
      case "texte": c.setLineDash([]); texteMulti(c, A.x, A.y, d.txt || "Texte", 12 + (d.w || 2) * 2); break;
      case "note": { c.setLineDash([]); const t = d.txt || "Note", wt = largeurTexte(c, t) + 16, h = String(t).split("\n").length * 17 + 10;
        c.beginPath(); c.arc(A.x, A.y, 3, 0, 7); c.fill(); c.beginPath(); c.moveTo(A.x, A.y); c.lineTo(A.x, A.y - 14); c.stroke();
        c.fillRect(A.x - 10, A.y - 14 - h, wt, h); c.fillStyle = "#fff"; texteMulti(c, A.x - 2, A.y - 14 - h + 17, t); break; }
      case "noteprix": { if (!B) { c.beginPath(); c.arc(A.x, A.y, 3, 0, 7); c.fill(); break; } c.setLineDash([]); c.beginPath(); c.arc(A.x, A.y, 3, 0, 7); c.fill(); poly([A, B]); c.stroke();
        const t = (d.txt ? d.txt + "\n" : "") + fp(d.pts[0].p); bulle(c, B.x, B.y - 10, t, col); break; }
      case "epingle": { c.setLineDash([]); c.beginPath(); c.moveTo(A.x, A.y); c.bezierCurveTo(A.x - 10, A.y - 14, A.x - 10, A.y - 26, A.x, A.y - 26); c.bezierCurveTo(A.x + 10, A.y - 26, A.x + 10, A.y - 14, A.x, A.y); c.fill();
        c.fillStyle = "#fff"; c.beginPath(); c.arc(A.x, A.y - 18, 3.5, 0, 7); c.fill(); if (d.txt) { c.fillStyle = col; texteMulti(c, A.x + 12, A.y - 16, d.txt); } break; }
      case "tableau": { c.setLineDash([]); const lignes = String(d.txt || "Colonne 1|Colonne 2\nValeur|Valeur").split("\n").map(l => l.split("|")), nc = Math.max(...lignes.map(l => l.length));
        c.font = "12px sans-serif"; const lc = Array(nc).fill(0).map((_, j) => Math.max(...lignes.map(l => c.measureText(l[j] || "").width)) + 16), lh = 22;
        const W = lc.reduce((s, x) => s + x, 0), H = lh * lignes.length; c.fillStyle = S.theme === "clair" ? "#ffffff" : "#1e222d"; c.fillRect(A.x, A.y, W, H);
        c.fillStyle = col; c.globalAlpha = 0.15; c.fillRect(A.x, A.y, W, lh); c.globalAlpha = 1; c.lineWidth = 1; c.strokeRect(A.x, A.y, W, H);
        lignes.forEach((l, i) => { let x = A.x; if (i) { c.beginPath(); c.moveTo(A.x, A.y + i * lh); c.lineTo(A.x + W, A.y + i * lh); c.stroke(); }
          l.forEach((txt, j) => { c.fillStyle = S.theme === "clair" ? "#131722" : "#d1d4dc"; c.font = (i ? "" : "bold ") + "12px sans-serif"; c.fillText(txt, x + 8, A.y + i * lh + 15); x += lc[j]; }); });
        let x = A.x; for (let j = 0; j < nc - 1; j++) { x += lc[j]; c.beginPath(); c.moveTo(x, A.y); c.lineTo(x, A.y + H); c.stroke(); } break; }
      case "callout": { if (!B) break; c.setLineDash([]); const t = d.txt || "Callout", wt = largeurTexte(c, t) + 18, h = String(t).split("\n").length * 17 + 12;
        c.beginPath(); c.moveTo(A.x, A.y); c.lineTo(B.x - 8, B.y); c.lineTo(B.x + 8, B.y); c.closePath(); c.fill(); c.fillRect(B.x - wt / 2, B.y - h / 2, wt, h); c.fillStyle = "#fff"; texteMulti(c, B.x - wt / 2 + 9, B.y - h / 2 + 18, t); break; }
      case "commentaire": { c.setLineDash([]); const t = d.txt || "Commentaire", wt = largeurTexte(c, t) + 24, h = String(t).split("\n").length * 17 + 14, x = A.x, y = A.y - h - 8, r = Math.min(12, h / 2);
        c.beginPath(); c.moveTo(x + r, y); c.lineTo(x + wt - r, y); c.arcTo(x + wt, y, x + wt, y + r, r); c.lineTo(x + wt, y + h - r); c.arcTo(x + wt, y + h, x + wt - r, y + h, r); c.lineTo(x + 18, y + h); c.lineTo(x, A.y); c.lineTo(x + 8, y + h);
        c.lineTo(x + r, y + h); c.arcTo(x, y + h, x, y + h - r, r); c.lineTo(x, y + r); c.arcTo(x, y, x + r, y, r); c.closePath(); c.fill(); c.fillStyle = "#fff"; texteMulti(c, x + 12, y + 19, t); break; }
      case "etiquette": { c.setLineDash([]); const t = (d.txt ? d.txt + " · " : "") + fp(d.pts[0].p); c.font = "bold 12px sans-serif"; const wt = c.measureText(t).width + 14;
        c.beginPath(); c.moveTo(A.x, A.y); c.lineTo(A.x + 8, A.y - 10); c.lineTo(A.x + 8 + wt, A.y - 10); c.lineTo(A.x + 8 + wt, A.y + 10); c.lineTo(A.x + 8, A.y + 10); c.closePath(); c.fill();
        c.fillStyle = "#fff"; c.fillText(t, A.x + 14, A.y + 4); break; }
      case "panneau": { c.setLineDash([]); c.lineWidth = 2; c.beginPath(); c.moveTo(A.x, A.y); c.lineTo(A.x, A.y - 30); c.stroke(); c.beginPath(); c.arc(A.x, A.y - 44, 15, 0, 7); c.fill();
        c.fillStyle = "#fff"; c.font = "16px sans-serif"; const t = d.txt || "★"; c.fillText(t, A.x - c.measureText(t).width / 2, A.y - 38); break; }
      case "flechehaut": case "flechebas": { c.setLineDash([]); const s = d.type === "flechehaut" ? 1 : -1, cc = d.c || (s > 0 ? VERT : ROUGE); c.fillStyle = cc;
        c.beginPath(); c.moveTo(A.x, A.y); c.lineTo(A.x + 10, A.y + s * 12); c.lineTo(A.x + 4, A.y + s * 12); c.lineTo(A.x + 4, A.y + s * 26); c.lineTo(A.x - 4, A.y + s * 26); c.lineTo(A.x - 4, A.y + s * 12); c.lineTo(A.x - 10, A.y + s * 12); c.closePath(); c.fill();
        if (d.txt) { c.font = "12px sans-serif"; c.fillText(d.txt, A.x - c.measureText(d.txt).width / 2, A.y + s * 40); } break; }
      case "drapeau": c.setLineDash([]); c.lineWidth = 2; c.beginPath(); c.moveTo(A.x, A.y); c.lineTo(A.x, A.y - 30); c.stroke(); c.beginPath(); c.moveTo(A.x, A.y - 30); c.lineTo(A.x + 18, A.y - 30); c.lineTo(A.x + 13, A.y - 24); c.lineTo(A.x + 18, A.y - 18); c.lineTo(A.x, A.y - 18); c.closePath(); c.fill(); break;
      case "image": { if (!B) break; const xa = Math.min(A.x, B.x), ya = Math.min(A.y, B.y), W = Math.abs(B.x - A.x), H = Math.abs(B.y - A.y);
        if (d.img) { let im = IMAGES[d.id]; if (!im) { im = new Image(); im.onload = () => { sale = true; }; im.src = d.img; IMAGES[d.id] = im; } if (im.complete) c.drawImage(im, xa, ya, W, H); }
        else { c.setLineDash([4, 4]); c.strokeRect(xa, ya, W, H); } break; }
      case "icone": { c.setLineDash([]); const taille = 18 + (d.w || 2) * 5; c.font = `${taille}px "Segoe UI Emoji", "Segoe UI Symbol", sans-serif`; const t = d.txt || "★"; c.fillText(t, A.x - c.measureText(t).width / 2, A.y + taille / 3); break; }
      case "long": case "short": dessinPosition(c, g, d, P, w); break;
      case "zoomsel": if (B) { c.fillStyle = "rgba(41,98,255,.12)"; c.fillRect(Math.min(A.x, B.x), 0, Math.abs(B.x - A.x), g.H); } break;
    }
    c.setLineDash([]); c.lineWidth = 1;
    if (sel) for (const p of P) { if (p.y == null) continue; c.fillStyle = S.theme === "clair" ? "#fff" : "#131722"; c.strokeStyle = BLEU; c.lineWidth = 1.5; c.beginPath(); c.arc(p.x, p.y, 5, 0, 7); c.fill(); c.stroke(); c.lineWidth = 1; }
  }

  // ================================================================== sélection et toucher des dessins
  function distSeg(p, a, b) { const dx = b.x - a.x, dy = b.y - a.y, L = dx * dx + dy * dy || 1, u = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / L)); return Math.hypot(p.x - a.x - u * dx, p.y - a.y - u * dy); }
  const AIRES = ["rect", "fprixdate", "ellipse", "fprix", "fdate", "rectpivote", "polyligne", "triangle", "gannboite", "ganncarre", "image", "arc", "secteur", "motifbarres", "regression", "hautbas", "disjoint", "fiboeventail", "callout"];
  const PONCTUELS = ["texte", "note", "etiquette", "drapeau", "epingle", "tableau", "commentaire", "panneau", "icone", "noteprix"];
  function toucheDessin(d, p, g) {
    const P = d.pts.map(pt => ({ x: g.x(idxDe(pt.t)), y: g.y(pt.p) }));
    if (P.some(q => q.y == null)) return false;
    const [A, B] = P, xs = P.map(q => q.x), ys = P.map(q => q.y);
    const dans = (xa, ya, xb, yb) => p.x >= Math.min(xa, xb) - 5 && p.x <= Math.max(xa, xb) + 5 && p.y >= Math.min(ya, yb) - 5 && p.y <= Math.max(ya, yb) + 5;
    switch (d.type) {
      case "hline": case "alerte": return Math.abs(p.y - A.y) < 6;
      case "long": case "short": return P.length >= 4 && dans(A.x, Math.min(P[1].y, P[2].y), Math.max(P[3].x, A.x + 8), Math.max(P[1].y, P[2].y));
      case "hray": return p.x >= A.x - 4 && Math.abs(p.y - A.y) < 6;
      case "vline": case "vwapancre": case "profilancre": return Math.abs(p.x - A.x) < 6 || (d.type !== "vline" && p.x > A.x && dans(A.x, A.y - 20, A.x + 200, A.y + 20));
      case "croix": return Math.abs(p.y - A.y) < 6 || Math.abs(p.x - A.x) < 6;
      case "trend": case "rayon": case "etendue": case "fleche": case "info": { if (!B) return false; const [P1, P2] = bornesLigne(A, B, prolLigne(d)); return distSeg(p, P1, P2) < 6; }
      case "zone": return B && dans(Math.min(A.x, B.x), A.y, g.W, B.y);
      case "profilfixe": return B && dans(A.x, 0, B.x, g.H) && Math.min(Math.abs(p.x - A.x), Math.abs(p.x - B.x)) < 8 || (B && dans(A.x, A.y, B.x, B.y));
      case "fibo": case "fiboext": {                       // comme TradingView : on n'attrape le Fibonacci que sur ses lignes (glisser ailleurs fait défiler le graphique)
        if (!B) return false;
        const ext = d.type === "fiboext", C2 = P[2], p0 = d.pts[0].p, p1 = d.pts[1].p, base = ext ? (d.pts[2] || d.pts[1]).p : p1, inv = !!d.inverser;
        const debut = ext ? (C2 || B).x : Math.min(A.x, B.x), finX = ext ? debut + Math.max(60, Math.abs(B.x - A.x)) : Math.max(A.x, B.x);
        const xa = d.prolG ? 0 : debut, xb = d.prolD === false ? Math.max(finX, xa + 40) : g.W;
        if (p.x >= xa - 4 && p.x <= xb + 4) for (const { v: f } of nivActifs(d)) {
          const y = g.y(ext ? base + (inv ? p0 - p1 : p1 - p0) * f : (inv ? p0 + (p1 - p0) * f : p1 + (p0 - p1) * f));
          if (y != null && Math.abs(p.y - y) <= 5) return true;
        }
        if (d.tendance !== false) for (let i = 1; i < P.length; i++) if (distSeg(p, P[i - 1], P[i]) < 6) return true;
        return P.some(q => Math.hypot(p.x - q.x, p.y - q.y) < 8);
      }
      case "fibocanal": {
        if (!P[2]) return false; const C2 = P[2];
        const dy = C2.y - (A.y + (B.y - A.y) * ((C2.x - A.x) / ((B.x - A.x) || 1))), k = 4000 / (Math.hypot(B.x - A.x, B.y - A.y) || 1);
        for (const { v: f } of nivActifs(d)) {
          const a = { x: A.x, y: A.y + dy * f }, b = { x: B.x, y: B.y + dy * f };
          if (distSeg(p, { x: a.x - (b.x - a.x) * k, y: a.y - (b.y - a.y) * k }, { x: b.x + (b.x - a.x) * k, y: b.y + (b.y - a.y) * k }) < 6) return true;
        }
        return P.some(q => Math.hypot(p.x - q.x, p.y - q.y) < 8);
      }
      case "cercle": case "fibocercles": return B && Math.hypot(p.x - A.x, p.y - A.y) <= Math.hypot(B.x - A.x, B.y - A.y) + 5;
      case "fibotemps": case "cycliques": case "fibotempstend": return P.some(q => Math.abs(p.x - q.x) < 6);
      case "flechehaut": case "flechebas": return dans(A.x - 12, A.y - 28, A.x + 12, A.y + 28);
    }
    if (PONCTUELS.includes(d.type)) return dans(A.x - 12, A.y - 60, A.x + 180, A.y + 14) || (d.type === "tableau" && dans(A.x, A.y, A.x + 260, A.y + 120)) || (B && dans(B.x - 80, B.y - 30, B.x + 80, B.y + 30));
    if (AIRES.includes(d.type)) return dans(Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys));
    for (let i = 1; i < P.length; i++) if (distSeg(p, P[i - 1], P[i]) < 6) return true;
    return Math.hypot(p.x - A.x, p.y - A.y) < 8;
  }
  function poigneeProche(p, g) {
    const d = G.dessins[G.sel]; if (!d) return -1;
    return d.pts.findIndex(pt => { const y = g.y(pt.p); return y != null && Math.hypot(g.x(idxDe(pt.t)) - p.x, y - p.y) < 8; });
  }
  // Barre flottante du dessin sélectionné, comme TradingView : poignée, modèle, couleur du trait, couleur du texte, épaisseur, style,
  // réglages, alerte, verrou, suppression, et « plus ». Déplaçable avec sa poignée ; sa place est retenue.
  const IC_BD = {
    poignee: '<svg viewBox="0 0 10 18" width="8" height="16" fill="currentColor"><circle cx="2.5" cy="3" r="1.3"/><circle cx="7.5" cy="3" r="1.3"/><circle cx="2.5" cy="9" r="1.3"/><circle cx="7.5" cy="9" r="1.3"/><circle cx="2.5" cy="15" r="1.3"/><circle cx="7.5" cy="15" r="1.3"/></svg>',
    modele: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="4" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.5"/><path d="M16.75 13.5v6.5M13.5 16.75H20"/></svg>',
    crayon: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M5 17l1-4L15.5 3.5l3 3L9 16z"/><path d="M13.5 5.5l3 3"/></svg>',
    texte: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M6 5h12M12 5v13"/></svg>',
    reglages: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M12 3l7.8 4.5v9L12 21l-7.8-4.5v-9z"/><circle cx="12" cy="12" r="3"/></svg>',
    alerte: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="11" cy="13" r="6.5"/><path d="M11 9.5V13l2.5 2M5 5l2.5-2M17 5l-2.5-2M19 15v5M16.5 17.5h5"/></svg>',
    verrou: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 7.5-2"/><circle cx="12" cy="15.5" r="1"/></svg>',
    verrouF: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15.5" r="1"/></svg>',
    corbeille: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4.5 6.5h15M9.5 6.5V4.5h5v2M6.5 6.5l1 13h9l1-13M10.5 10v6.5M13.5 10v6.5"/></svg>',
    plus: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="6" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="18" cy="12" r="1.6"/></svg>'
  };
  const AVEC_TEXTE_BD = d => LIGNES_TV.has(d.type) || d.type === "rect" || TYPES_TEXTE.includes(d.type);
  function fermerPopBD() { const p = $("#popBD"); if (p) p.remove(); }
  function popBD(bouton, html, surClic) {           // petit menu sous un bouton de la barre
    fermerPopBD();
    const p = document.createElement("div"); p.id = "popBD"; p.className = "pop-bd"; p.innerHTML = html;
    document.body.appendChild(p);
    const r = bouton.getBoundingClientRect(), w = p.offsetWidth;
    p.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.left + r.width / 2 - w / 2)) + "px"; p.style.top = (r.bottom + 6) + "px";
    p.addEventListener("mousedown", e => e.stopPropagation());
    p.onclick = e => { const b = e.target.closest("[data-v]"); if (b) { surClic(b.dataset.v); fermerPopBD(); } };
    p.oninput = e => { if (e.target.matches("input[type=color]")) surClic(e.target.value, true); };
  }
  function paletteBD(actuelle) {
    return `<div class="bd-palette">${["#131722", "#787b86", "#b2b5be", "#ffffff", "#f23645", "#ff9800", "#ffeb3b", "#089981", "#4caf50", "#00bcd4", "#2962ff", "#673ab7", "#9c27b0", "#e91e63", "#795548", "#d8b46a"]
      .map(c => `<button data-v="${c}" class="${String(actuelle).toLowerCase() === c ? "actif" : ""}" style="background:${c}" title="${c}"></button>`).join("")}</div>
      <label class="bd-perso">Couleur personnalisée <input type="color" value="${esc(/^#[0-9a-f]{6}$/i.test(actuelle || "") ? actuelle : "#2962ff")}"></label>`;
  }
  function placerBarreDessin(el) {
    if (S.barreDessinPos) {
      const z = zone.getBoundingClientRect();
      const x = Math.max(0, Math.min(S.barreDessinPos.x, z.width - el.offsetWidth - 4)), y = Math.max(0, Math.min(S.barreDessinPos.y, z.height - el.offsetHeight - 4));
      el.style.left = x + "px"; el.style.top = y + "px"; el.style.transform = "none";
    }
  }
  function barreDessin() {
    if (S.vueDroite === "objets" && typeof majObjets === "function") majObjets();
    const d = G.dessins[G.sel], el = $("#barreDessin");
    fermerPopBD();
    if (!d) { el.classList.remove("ouvert"); return; }
    el.classList.add("ouvert");
    const col = d.c || BLEU, colT = d.cTx || col, w = d.w && d.w !== 1.6 ? d.w : 1;
    const trait = s0 => `<svg viewBox="0 0 28 10" width="26" height="10"><path d="M2 5h24" stroke="currentColor" stroke-width="1.6" stroke-dasharray="${s0 == 1 ? "5 3" : s0 == 2 ? "1.5 3" : "none"}" stroke-linecap="round"/></svg>`;
    el.innerHTML = `<span class="bd-poignee" title="Déplacer">${IC_BD.poignee}</span>
      <button data-act="modele" title="Modèles : enregistrer ce style, ou appliquer un style enregistré">${IC_BD.modele}</button>
      <button data-act="couleur" class="bd-coul" title="Couleur du trait">${IC_BD.crayon}<i style="background:${esc(col)}"></i></button>
      ${AVEC_TEXTE_BD(d) ? `<button data-act="couleurTexte" class="bd-coul" title="Couleur du texte">${IC_BD.texte}<i style="background:${esc(colT)}"></i></button>` : ""}
      <button data-act="epaisseur" class="bd-txt" title="Épaisseur">${trait(0)}<span>${w}px</span></button>
      <button data-act="styleTrait" title="Style du trait">${trait(d.s || 0)}</button>
      <span class="sep"></span>
      <button data-act="style" title="Paramètres (ou double-clic sur le dessin)">${IC_BD.reglages}</button>
      <button data-act="alerte" title="Ajouter une alerte au prix de ce dessin">${IC_BD.alerte}</button>
      <button data-act="lock" class="${d.lock ? "actif" : ""}" title="${d.lock ? "Déverrouiller" : "Verrouiller"}">${d.lock ? IC_BD.verrouF : IC_BD.verrou}</button>
      ${estPosition(d) ? '<button data-act="ordre" class="ordre-pos" title="Passer cet ordre (simulé) : entrée, stop et objectif de l\'outil">▶ Ordre</button>' : ""}
      <button data-act="suppr" class="suppr" title="Supprimer (touche Suppr)">${IC_BD.corbeille}</button>
      <button data-act="plus" title="Plus">${IC_BD.plus}</button>`;
    placerBarreDessin(el);
    el.querySelector(".bd-poignee").onmousedown = e => {
      e.preventDefault(); e.stopPropagation();
      const r0 = el.getBoundingClientRect(), z = zone.getBoundingClientRect(), dx = e.clientX - r0.left, dy = e.clientY - r0.top;
      const mv = ev => { S.barreDessinPos = { x: ev.clientX - z.left - dx, y: ev.clientY - z.top - dy }; placerBarreDessin(el); };
      const up = () => { window.removeEventListener("mousemove", mv); window.removeEventListener("mouseup", up); sauverPrefs(); };
      window.addEventListener("mousemove", mv); window.addEventListener("mouseup", up);
    };
  }
  // ---------------------------------------------------------------- modèles de style des outils de dessin (comme TradingView)
  const CLES_STYLE = ["c", "c2", "c3", "w", "s", "op", "etiq", "compte", "risque",
    "niv", "uneCouleur", "fond", "fondOp", "inverser", "prolG", "prolD", "nivAff", "prixAff", "pct", "etiqPos", "etiqV", "tp", "tendance", "cT", "sT",
    "boutG", "boutD", "milieu", "etiqPrix", "stats", "statsPos", "statsToujours", "cTx", "tTx", "gras", "ital", "alTxH", "alTxV", "cFond", "mediane", "cMed", "sMed"];   // + ligne de tendance   // + réglages du Fibonacci
  const styleDe = d => Object.fromEntries(CLES_STYLE.filter(k => d[k] !== undefined).map(k => [k, d[k]]));
  function appliquerModeleDefaut(d) {                       // nouveau dessin : dernier style choisi pour cet outil (comme TradingView), sinon modèle par défaut
    const nom = (S.modeleDefaut || {})[d.type], m = nom && ((S.modelesDessin || {})[d.type] || {})[nom];
    const dernier = (S.dernierStyle || {})[d.type];
    if (dernier) Object.assign(d, JSON.parse(JSON.stringify(dernier)));
    else if (m) Object.assign(d, JSON.parse(JSON.stringify(m)));
    return d;
  }
  function retenirStyle(d) {                                // la couleur/épaisseur/style choisis restent pour les prochains dessins de cet outil
    if (!d || !d.type) return;
    const st = styleDe(d); if (!Object.keys(st).length) return;
    S.dernierStyle = S.dernierStyle || {};
    if (JSON.stringify(S.dernierStyle[d.type]) === JSON.stringify(st)) return;
    S.dernierStyle[d.type] = st; sauverPrefs();
  }
  let popModele = null;
  function fermerMenuModele() { if (popModele) { popModele.remove(); popModele = null; } }
  function menuModeleDessin(bouton, apres) {
    const d = G.dessins[G.sel]; if (!d) return;
    if (popModele) { fermerMenuModele(); return; }
    S.modelesDessin = S.modelesDessin || {}; S.modeleDefaut = S.modeleDefaut || {};
    const liste = S.modelesDessin[d.type] || {}, defaut = S.modeleDefaut[d.type];
    const nomOutil = OUTILS[d.type] ? OUTILS[d.type][0] : d.type;
    popModele = document.createElement("div"); popModele.className = "pop-modele";
    popModele.innerHTML = `<div class="pm-titre">Modèles · ${esc(nomOutil)}</div>
      <div class="pm-saisie"><input id="pmNom" maxlength="40" placeholder="Nom du modèle (ex. Support bleu)"><button id="pmSauver" class="gros noir" type="button">Enregistrer</button></div>
      ${Object.keys(liste).length ? Object.keys(liste).sort().map(n => `<div class="pm-ligne" data-pm="${esc(n)}"><button class="pm-nom" data-pm-appli="${esc(n)}" title="Appliquer ce style au dessin">${esc(n)}</button>
        <button class="pm-def ${defaut === n ? "actif" : ""}" data-pm-def="${esc(n)}" title="${defaut === n ? "Modèle par défaut : utilisé pour chaque nouveau dessin (cliquer pour retirer)" : "Utiliser par défaut pour les nouveaux dessins"}">${defaut === n ? "★" : "☆"}</button>
        <button class="pm-suppr" data-pm-suppr="${esc(n)}" title="Supprimer ce modèle">✕</button></div>`).join("") : `<p class="pm-vide">Aucun modèle pour cet outil. Réglez le style, donnez-lui un nom, puis « Enregistrer ».</p>`}
      ${defaut ? `<button class="pm-reset" data-pm-def="">Revenir au style d'origine pour les nouveaux dessins</button>` : ""}`;
    document.body.appendChild(popModele);
    const r = bouton.getBoundingClientRect();
    popModele.style.left = Math.max(8, Math.min(r.left, innerWidth - popModele.offsetWidth - 8)) + "px";
    popModele.style.top = (r.bottom + 6 + popModele.offsetHeight > innerHeight ? Math.max(8, r.top - popModele.offsetHeight - 6) : r.bottom + 6) + "px";
    const champ = popModele.querySelector("#pmNom"); setTimeout(() => champ.focus(), 20);
    const sauver = () => {
      const n = champ.value.trim().slice(0, 40); if (!n) { champ.focus(); return; }
      S.modelesDessin[d.type] = Object.assign({}, S.modelesDessin[d.type], { [n]: styleDe(d) }); sauverPrefs();
      toast(`Modèle « ${n} » enregistré pour l'outil ${nomOutil}.`); fermerMenuModele();
    };
    champ.onkeydown = ev => { ev.stopPropagation(); if (ev.key === "Enter") sauver(); if (ev.key === "Escape") fermerMenuModele(); };
    popModele.onclick = async ev => {
      ev.stopPropagation();
      const b = ev.target.closest("button"); if (!b) return;
      if (b.id === "pmSauver") return sauver();
      if (b.dataset.pmAppli != null) {
        const m = (S.modelesDessin[d.type] || {})[b.dataset.pmAppli]; if (!m) return;
        modifierSel(x => { for (const k of CLES_STYLE) delete x[k]; Object.assign(x, JSON.parse(JSON.stringify(m))); });
        toast(`Style « ${b.dataset.pmAppli} » appliqué.`); fermerMenuModele(); if (apres) apres(); return;
      }
      if (b.dataset.pmDef != null) {
        const n = b.dataset.pmDef;
        if (!n || S.modeleDefaut[d.type] === n) delete S.modeleDefaut[d.type]; else S.modeleDefaut[d.type] = n;
        if (S.dernierStyle) delete S.dernierStyle[d.type];      // choisir un modèle par défaut : les prochains dessins prennent ce modèle
        sauverPrefs(); fermerMenuModele(); menuModeleDessin(bouton, apres); return;
      }
      if (b.dataset.pmSuppr != null) {
        const n = b.dataset.pmSuppr; if (!await demander(`Supprimer le modèle « ${n} » ?`)) return;
        delete S.modelesDessin[d.type][n]; if (S.modeleDefaut[d.type] === n) delete S.modeleDefaut[d.type];
        sauverPrefs(); fermerMenuModele(); menuModeleDessin(bouton, apres);
      }
    };
  }
  document.addEventListener("click", e => { if (popModele && !popModele.contains(e.target)) fermerMenuModele(); });
  function supprimerSel() {   // supprime le ou les dessins sélectionnés, et seulement eux
    const sel = selection(); if (!sel.length) return false;
    memoriser(); G.dessins = G.dessins.filter(x => !sel.includes(x)); G.sel = -1; G.multi.clear(); barreDessin(); sauverDessins(true); sale = true;
    toast(sel.length > 1 ? sel.length + " dessins supprimés · Ctrl+Z pour les récupérer" : "Dessin supprimé · Ctrl+Z pour le récupérer"); return true;
  }
  // ---- clavier, comme TradingView : copier / coller, déplacer avec les flèches, masquer, échelles
  let pressePapier = null, tClavier = 0;
  function copierSel() {
    const sel = selection(); if (!sel.length) return false;
    pressePapier = JSON.stringify(sel);
    toast(sel.length > 1 ? sel.length + " dessins copiés · Ctrl+V pour les coller" : "Dessin copié · Ctrl+V pour le coller"); return true;
  }
  function collerDessins() {
    if (!pressePapier) return false;
    const r = chart.timeScale().getVisibleLogicalRange(), dec = r ? Math.max(1, Math.round((r.to - r.from) / 40)) : 3;
    const copies = JSON.parse(pressePapier).map(d => { delete d.fait; return Object.assign(d, { id: Math.random().toString(36).slice(2, 10), pts: d.pts.map(q => ({ t: tDe(idxDe(q.t) + dec), p: q.p })) }); });
    memoriser(); G.dessins.push(...copies); G.multi = new Set(copies.length > 1 ? copies : []); G.sel = G.dessins.length - 1; barreDessin(); sauverDessins(); sale = true;
    toast(copies.length > 1 ? copies.length + " dessins collés" : "Dessin collé"); return true;
  }
  function deplacerAuClavier(sel, touche, fort) {      // flèches : 1 bougie / 2 pixels (Maj : 10 fois plus)
    const g = geo(), n = fort ? 10 : 1; let di = 0, dp = 0;
    if (touche === "ArrowLeft") di = -n; else if (touche === "ArrowRight") di = n;
    else { const a = g.py(g.H / 2), b = g.py(g.H / 2 - 2 * n); if (a == null || b == null) return; dp = (b - a) * (touche === "ArrowUp" ? 1 : -1); }
    if (Date.now() - tClavier > 800) memoriser(); tClavier = Date.now();     // une série d'appuis = une seule annulation
    for (const d of sel) { if (d.lock || S.verrou) continue; d.pts = d.pts.map(q => ({ t: di ? tDe(idxDe(q.t) + di) : q.t, p: dp ? +(q.p + dp).toFixed(G.chiffres + 1) : q.p })); }
    sauverDessins(); barreDessin(); sale = true;
  }
  function naviguerClavier(touche, fort) {              // sans dessin sélectionné : faire défiler (←/→) ou zoomer (Ctrl + ↑/↓)
    const ts = chart.timeScale(), r = ts.getVisibleLogicalRange(); if (!r) return false;
    const larg = r.to - r.from;
    if (touche === "ArrowLeft" || touche === "ArrowRight") {
      const pas = (fort ? Math.max(10, Math.round(larg / 4)) : 1) * (touche === "ArrowLeft" ? -1 : 1);
      ts.setVisibleLogicalRange({ from: r.from + pas, to: r.to + pas }); return true;
    }
    if (!fort) return false;
    const n = Math.max(10, larg * (touche === "ArrowUp" ? 0.8 : 1.25)); ts.setVisibleLogicalRange({ from: r.to - n, to: r.to }); return true;
  }
  function basculerMasquer() {
    S.masquer = !S.masquer; G.sel = -1; G.multi.clear(); barreDessin(); sauverPrefs(); construireOutils(); sale = true;
    toast(S.masquer ? "Dessins masqués · Ctrl+Alt+H pour les réafficher" : "Dessins affichés");
  }
  function modeEchelle(v) {
    if (S.comparer.length && v !== 2) { toast("Retirez les actifs comparés pour changer d'échelle.", false); return; }
    S.echelle = v; sauverPrefs(); chart.applyOptions(optionsTheme()); chart.priceScale("right").applyOptions({ autoScale: true }); majCoin(); sale = true;
    toast(["Échelle normale", "Échelle logarithmique", "Échelle en pourcentage", "Échelle indexée à 100"][v] || "Échelle");
  }
  function afficherRaccourcis() {
    boiteDialogue([
      "Dessins", "Alt+T ligne de tendance · Alt+H horizontale · Alt+J rayon horizontal · Alt+V verticale · Alt+C croix · Alt+F Fibonacci · Alt+Maj+R rectangle · Alt+A alerte",
      "Maj en traçant : ligne droite (horizontale, verticale ou 45°), carré, cercle",
      "Maj + glisser un dessin : déplacement horizontal ou vertical seulement",
      "Ctrl en traçant ou en déplaçant un point : aimant temporaire",
      "Ctrl + glisser un dessin : le dupliquer · Ctrl + clic : sélectionner plusieurs dessins",
      "Flèches : déplacer le dessin sélectionné (Maj : plus vite) · Suppr : supprimer",
      "Ctrl+C / Ctrl+V : copier / coller un dessin · Ctrl+Alt+H : masquer / afficher les dessins",
      "Maj + clic : règle de mesure · Échap : annuler le dessin en cours",
      "", "Graphique", "Ctrl+Z / Ctrl+Y : annuler / refaire · Ctrl+K ou une lettre : chercher un actif · chiffre : changer d'unité · / : indicateurs",
      "← / → : faire défiler · Ctrl+← / → : défiler plus vite · Ctrl+↑ / ↓ : zoomer / dézoomer",
      "Alt+G : aller à une date · Alt+R : réinitialiser la vue · Alt+S : capture · Alt+I : inverser · Alt+L : logarithmique · Alt+P : pourcentage · Alt+W : ajouter à la liste",
      "Ctrl+T : nouvel onglet · Maj+R : replay (→ / ← / Espace pendant le replay)"].join("\n"),
      { titre: "Raccourcis clavier", ok: "Fermer", annuler: null, danger: false });
  }
  function modifierSel(f) { const d = G.dessins[G.sel]; if (!d) return; memoriser(); const avant = JSON.stringify(styleDe(d)); f(d); if (JSON.stringify(styleDe(d)) !== avant) retenirStyle(d); sauverDessins(); barreDessin(); sale = true; }

  // ================================================================== création des dessins
  const pos = e => { const r = zone.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
  function ptDonnee(p, g) {
    let i = g.ix(p.x), prix = g.py(p.y);
    if (prix == null) return null;
    if (S.aimant || G.aimantTemp) {                    // aimant : accroche au prix d'ouverture, haut, bas ou clôture le plus proche
      const k = Math.round(i), b = G.bars[k];
      if (b && k < nVis()) { let best = null, dmin = S.aimant === "fort" ? 1e9 : 18; for (const v of b.slice(1, 5)) { const dy = Math.abs(g.y(v) - p.y); if (dy < dmin) { dmin = dy; best = v; } } if (best != null) { prix = best; i = k; } }
    }
    return { t: tDe(i), p: +(+prix).toFixed(G.chiffres + 1) };
  }

  // ================================================================== outils « Position longue / courte » (comme TradingView)
  // Un dessin : pts[0] = entrée (début), pts[1] = stop, pts[2] = objectif (au début), pts[3] = fin de la zone (au niveau de l'entrée).
  const estPosition = d => d && (d.type === "long" || d.type === "short");
  function initPosition(d) {
    const e = d.pts[0], n = nVis(), sens = d.type === "long" ? 1 : -1;
    const v = G.bars.slice(Math.max(0, n - 15), n), moy = v.length ? v.reduce((s, b) => s + (b[2] - b[3]), 0) / v.length : e.p * 0.002;
    const r = Math.max(moy * 1.5, e.p * 0.0002), ch = chiffres() + 1, arr = x => +x.toFixed(ch);
    d.pts = [{ t: e.t, p: e.p }, { t: e.t, p: arr(e.p - sens * r) }, { t: e.t, p: arr(e.p + sens * 2 * r) }, { t: tDe(idxDe(e.t) + 25), p: e.p }];
  }
  function bougerPosition(d, k, pt) {                // poignées : entrée, stop, objectif, largeur ; le stop et l'objectif restent du bon côté
    const s = d.type === "long" ? 1 : -1, P = d.pts, pas = Math.pow(10, -(chiffres()));
    if (k === 0) {
      const bas = Math.min(P[1].p, P[2].p) + pas, haut = Math.max(P[1].p, P[2].p) - pas;
      P[0] = { t: pt.t, p: Math.min(haut, Math.max(bas, pt.p)) }; P[1].t = P[2].t = pt.t; P[3].p = P[0].p;
      if (idxDe(P[3].t) <= idxDe(pt.t) + 1) P[3].t = tDe(idxDe(pt.t) + 5);
    } else if (k === 1) P[1].p = s > 0 ? Math.min(pt.p, P[0].p - pas) : Math.max(pt.p, P[0].p + pas);
    else if (k === 2) P[2].p = s > 0 ? Math.max(pt.p, P[0].p + pas) : Math.min(pt.p, P[0].p - pas);
    else if (k === 3) P[3] = { t: idxDe(pt.t) > idxDe(P[0].t) + 1 ? pt.t : tDe(idxDe(P[0].t) + 2), p: P[0].p };
    const ch = chiffres() + 1; for (const q of P) q.p = +(+q.p).toFixed(ch);     // pas de décimales parasites (1.1112060000000001)
  }
  function infosPosition(d) {
    const e = d.pts[0].p, sl = d.pts[1].p, tp = d.pts[2].p, risque = Math.abs(e - sl), gain = Math.abs(tp - e);
    const fx = catActif(S.actif) === "Forex", pip = fx ? (S.actif.endsWith("JPY") ? 0.01 : 0.0001) : null;
    const compte = d.compte ?? 10000, rp = d.risque ?? 1, aRisquer = compte * rp / 100, qte = risque ? aRisquer / risque : 0;
    const dist = v => fx ? (v / pip).toFixed(1) + " pips" : fp(v) + " pts";
    return { e, sl, tp, risque, gain, rr: risque ? gain / risque : 0, aRisquer, qte, dist, fx };
  }
  function dessinPosition(c, g, d, P, w) {
    if (P.length < 4 || P.slice(0, 3).some(q => q.y == null)) return;
    const x0 = P[0].x, x1 = Math.max(P[3].x, x0 + 8), ye = P[0].y, ys = P[1].y, yt = P[2].y;
    const cp = d.c2 || VERT, cl = d.c3 || ROUGE, op = d.op ?? 0.2;
    c.setLineDash([]);
    c.globalAlpha = op; c.fillStyle = cp; c.fillRect(x0, Math.min(ye, yt), x1 - x0, Math.abs(yt - ye));
    c.fillStyle = cl; c.fillRect(x0, Math.min(ye, ys), x1 - x0, Math.abs(ys - ye)); c.globalAlpha = 1;
    c.strokeStyle = d.c || (S.theme === "clair" ? "#787b86" : "#b2b5be"); c.lineWidth = w; c.beginPath(); c.moveTo(x0, ye); c.lineTo(x1, ye); c.stroke(); c.lineWidth = 1;
    if (d.etiq === false) return;
    const i = infosPosition(d), xm = (x0 + x1) / 2;
    const pastille = (txt, y, fond) => {
      c.font = "11px sans-serif"; const lignes = txt.split("\n"), lw = Math.max(...lignes.map(l => c.measureText(l).width)) + 14, h = lignes.length * 14 + 6;
      const x = Math.max(2, Math.min(xm - lw / 2, g.W - lw - 2)), yy = y - h / 2;
      c.fillStyle = fond; c.beginPath(); if (c.roundRect) c.roundRect(x, yy, lw, h, 3); else c.rect(x, yy, lw, h); c.fill();
      c.fillStyle = "#fff"; lignes.forEach((l, k) => c.fillText(l, x + 7, yy + 14 + k * 14));
    };
    const pc = v => (v / i.e * 100).toFixed(2) + " %";
    pastille(`Objectif : ${fp(i.tp)} (${i.dist(i.gain)}, ${pc(i.gain)})  +${(i.aRisquer * i.rr).toFixed(2)}`, yt + (yt < ye ? -13 : 13), cp);
    pastille(`Stop : ${fp(i.sl)} (${i.dist(i.risque)}, ${pc(i.risque)})  −${i.aRisquer.toFixed(2)}`, ys + (ys < ye ? -13 : 13), cl);
    if (Math.abs(ys - yt) > 40) pastille(`Ratio R/R : ${i.rr.toFixed(2)}\nQuantité : ${i.qte >= 100 ? Math.round(i.qte).toLocaleString(LOC) : i.qte.toFixed(2)}${i.fx ? " (" + (i.qte / 100000).toFixed(2) + " lot)" : ""}`, ye, "#787b86");
  }
  function placerDepuisDessin(d) {
    if (!estPosition(d)) return;
    $("#oTP").value = d.pts[2].p;
    placer(d.type === "long" ? 1 : -1, d.pts[0].p, d.pts[1].p);
    toast(`Ordre simulé ${d.type === "long" ? "d'achat" : "de vente"} passé depuis l'outil : entrée ${fp(d.pts[0].p)}, stop ${fp(d.pts[1].p)}, objectif ${fp(d.pts[2].p)}.`);
  }
  function nbPoints(type) { return OUTILS[type] ? OUTILS[type][1] : 0; }
  function terminerCrea() {
    const d = G.crea; G.crea = null;
    if (!d) return;
    if (estPosition(d) && d.pts.length < 4) initPosition(d);         // un clic : entrée ; stop et objectif proposés (R:R 2), modifiables avec les poignées
    if (d.type === "mesure") { delete d.fixes; G.mesure = d; suite(); return; }
    if (d.type === "zoomsel") {
      const a = idxDe(d.pts[0].t), b = idxDe(d.pts[1].t); if (Math.abs(b - a) >= 3) { G.zooms.push(chart.timeScale().getVisibleLogicalRange()); chart.timeScale().setVisibleLogicalRange({ from: Math.min(a, b), to: Math.max(a, b) }); }
      suite(); return;
    }
    if (TEXTES[d.type] && d.pts.length > 1 && !d._saisi) {
      d._saisi = true; G.apercu = d; sale = true;
      editerTexte(d, { aide: TEXTES[d.type][0], valeur: TEXTES[d.type][1] }, t => { G.apercu = null; if (t != null) d.txt = t.slice(0, 1000); G.crea = d; terminerCrea(); });
      return;
    }
    delete d._saisi;
    if (d.type === "image") { if (!G.imageEnAttente) { suite(); return; } d.img = G.imageEnAttente; G.imageEnAttente = null; }
    memoriser(); delete d.fixes; G.dessins.push(d); G.sel = G.dessins.length - 1; barreDessin(); sauverDessins(); suite();
  }
  // textes demandés à la création : [question, valeur proposée, obligatoire]
  const TEXTES = { texte: ["Texte :", "", true], note: ["Texte de la note :", "", true], commentaire: ["Commentaire :", "", true], callout: ["Texte du callout :", "", true],
    epingle: ["Texte de l'épingle (facultatif) :", ""], noteprix: ["Texte de la note de prix (facultatif) :", ""], panneau: ["Émoji ou texte du panneau :", "★"],
    tableau: ["Tableau : colonnes séparées par | et lignes par « ; » (ex. Entrée|1.1020 ; Stop|1.0990)", "Niveau|Prix ; Entrée|  ; Stop|  ; Objectif|  "] };
  function suite() { if (S.continuer && G.outil !== "zoom" && G.outil !== "regle") { G.crea = null; sale = true; } else finOutil(); }
  function nouveauDessin(type, pt) { return appliquerModeleDefaut({ id: Math.random().toString(36).slice(2, 10), type, pts: [pt], fixes: 1 }); }
  function surDown(e) {
    if (e.button !== 0) return;
    if (e.target.closest("#barreDessin, #ordreRapide, #legende, #barreFav, #bAllerDate, #logoGraph, button, input, select, textarea")) return;
    const p = pos(e), g = geo();
    if (p.x > g.W || p.y > g.H) return;
    const bloque = () => { e.stopPropagation(); e.preventDefault(); };
    if (G.mesure && !G.crea) { G.mesure = null; sale = true; }
    if (G.outil === "coupe") { bloque(); const i = Math.round(g.ix(p.x)); if (i > 0 && i < G.bars.length) demarrerReplay(G.bars[i][0]); return; }
    if (G.outil === "gomme") {
      bloque(); for (let k = G.dessins.length - 1; k >= 0; k--) if (visible(G.dessins[k]) && toucheDessin(G.dessins[k], p, g)) { memoriser(); G.dessins.splice(k, 1); G.sel = -1; barreDessin(); sauverDessins(true); sale = true; toast("Dessin effacé avec la gomme · Ctrl+Z pour le récupérer"); break; }
      return;
    }
    if (G.outil !== "curseur") {
      bloque();
      const pt = ptDonnee(p, g); if (!pt) return;
      const n = nbPoints(G.outil);
      if (n === 1) {
        const d = nouveauDessin(G.outil, pt);
        if (G.outil === "icone") d.txt = G.iconeChoisie || "★";
        if (TEXTES[G.outil]) {
          const [aide, valeur, obligatoire] = TEXTES[G.outil];
          editerTexte(d, { aide, valeur }, t => { if (t == null || (!t && obligatoire)) { finOutil(); return; } d.txt = t.slice(0, 1000); G.crea = d; terminerCrea(); });
          return;
        }
        G.crea = d; terminerCrea(); return;
      }
      if (n === "libre") { G.crea = nouveauDessin(G.outil, pt); G.drag = { type: "libre" }; return; }
      if (n === "multi") {
        if (!G.crea) { G.crea = nouveauDessin(G.outil, pt); G.crea.pts.push({ ...pt }); }
        else G.crea.pts.push({ ...pt });
        return;
      }
      if (G.outil === "image" && !G.imageEnAttente) { choisirImage(); return; }
      if (!G.crea) { G.crea = nouveauDessin(G.outil === "regle" ? "mesure" : G.outil === "zoom" ? "zoomsel" : G.outil, pt); G.crea.pts.push({ ...pt }); G.creaDown = p; G.drag = { type: "crea" }; }
      else {
        G.crea.fixes++;
        if (G.crea.fixes >= n) terminerCrea(); else G.crea.pts.push({ ...pt });
      }
      return;
    }
    // curseur : lignes de position, poignées et dessins
    const lp = lignePosProche(p, g);
    if (lp) { bloque(); G.drag = { type: "position", ...lp }; chart.applyOptions({ handleScroll: false, handleScale: false }); return; }
    if (G.sel >= 0) {
      const h = poigneeProche(p, g);
      if (h >= 0 && !(G.dessins[G.sel].lock || S.verrou)) { bloque(); memoriser(); G.drag = { type: "poignee", k: h }; chart.applyOptions({ handleScroll: false, handleScale: false }); return; }
    }
    if (!S.masquer) for (let k = G.dessins.length - 1; k >= 0; k--) {
      if (visible(G.dessins[k]) && toucheDessin(G.dessins[k], p, g)) {
        bloque();
        if (e.ctrlKey || e.metaKey) {                          // Ctrl : clic = sélection multiple, glisser = dupliquer
          G.drag = { type: "ctrl", p0: p, k, pts0: JSON.parse(JSON.stringify(G.dessins[k].pts)) }; chart.applyOptions({ handleScroll: false, handleScale: false }); return;
        }
        const groupe = G.multi.size && (G.multi.has(G.dessins[k]) || G.sel === k) ? selection() : null;   // clic sur un dessin d'une sélection multiple : on les déplace tous
        if (!groupe) G.multi.clear();
        G.sel = k; barreDessin(); sale = true;
        if (!(G.dessins[k].lock || S.verrou)) { memoriser(); G.drag = { type: "deplacer", p0: p, items: (groupe || [G.dessins[k]]).filter(d => !d.lock).map(d => ({ d, pts0: JSON.parse(JSON.stringify(d.pts)) })) }; chart.applyOptions({ handleScroll: false, handleScale: false }); }
        return;
      }
    }
    if (e.shiftKey) { G.sel = -1; G.multi.clear(); barreDessin(); choisirOutil("regle"); surDown(e); return; }   // Maj + clic : règle de mesure
    if (G.sel >= 0 || G.multi.size) { G.sel = -1; G.multi.clear(); barreDessin(); sale = true; }
  }
  // Touche Maj : ligne droite (horizontale, ou verticale si le mouvement est surtout vertical), comme TradingView
  const LIGNES_DROITES = new Set(["trend", "rayon", "info", "etendue", "angle", "fleche", "regression", "fibo", "fibotemps", "fiboeventail",
    "canal", "hautbas", "disjoint", "fourche", "schiff", "schiffmod", "fourcheint", "fiboext", "fibocanal", "mesure", "date", "prix", "dateprix"]);
  const CARRES = new Set(["rect", "ellipse"]);
  function redresser(d, k, pt, g) {
    if (!d || !pt || k > 1) return pt;
    const a = d.pts[k === 0 ? 1 : 0]; if (!a || k === 0 && d.pts.length < 2) return pt;
    const ax = g.x(idxDe(a.t)), ay = g.y(a.p), bx = g.x(idxDe(pt.t)), by = g.y(pt.p);
    if (ax == null || ay == null || bx == null || by == null) return pt;
    const dx = bx - ax, dy = by - ay, adx = Math.abs(dx), ady = Math.abs(dy);
    if (CARRES.has(d.type)) {                                  // rectangle -> carré, ellipse -> cercle
      const c = Math.max(adx, ady), nx = ax + (dx < 0 ? -c : c), ny = ay + (dy < 0 ? -c : c), np = g.py(ny);
      return np == null ? pt : { t: tDe(g.ix(nx)), p: +(+np).toFixed(G.chiffres + 1) };
    }
    if (!LIGNES_DROITES.has(d.type)) return pt;
    if (ady <= adx * 0.4142) return { t: pt.t, p: a.p };         // horizontale
    if (ady >= adx * 2.4142) return { t: a.t, p: pt.p };         // verticale
    const np = g.py(ay + (dy < 0 ? -adx : adx));                 // 45°
    return np == null ? pt : { t: pt.t, p: +(+np).toFixed(G.chiffres + 1) };
  }
  function surMove(e) {
    G.dernierMove = { clientX: e.clientX, clientY: e.clientY, buttons: e.buttons };
    const p = pos(e), g = geo();
    G.hover = p;
    // bouton de la souris déjà relâché (relâchement perdu : fenêtre, double-clic, autre programme) : le dessin ne suit plus la souris
    if (G.drag && ["deplacer", "poignee", "ctrl", "position"].includes(G.drag.type) && e.buttons !== undefined && !(e.buttons & 1)) { surUp(e); return; }
    if (S.curseur === "demo" && G.outil === "curseur" && (e.buttons & 1)) G.trace.push({ x: p.x, y: p.y, t: Date.now() });
    if (G.crea && (G.drag?.type === "crea" || nbPoints(G.crea.type) === "multi" || (G.crea.fixes || 0) >= 1)) {
      const pt = ptDonnee(p, g);
      if (pt) { if (G.drag?.type === "libre") { const der = G.crea.pts[G.crea.pts.length - 1]; if (Math.abs(g.x(idxDe(der.t)) - p.x) + Math.abs(g.y(der.p) - p.y) > 3) G.crea.pts.push(pt); }
        else { const k = G.crea.pts.length - 1; G.crea.pts[k] = e.shiftKey ? redresser(G.crea, k, pt, g) : pt; } }
    }
    if (G.drag) {
      if (G.drag.type === "position") { const v = g.py(p.y); if (v != null) { G.drag.ps[G.drag.k] = +(+v).toFixed(G.chiffres); lignesPosition(G.drag.ps); tablePositions(); } }
      else if (G.drag.type === "poignee") { const pt = ptDonnee(p, g), d = G.dessins[G.sel]; if (pt && d) { if (estPosition(d)) bougerPosition(d, G.drag.k, pt); else d.pts[G.drag.k] = e.shiftKey ? redresser(d, G.drag.k, pt, g) : pt; if (d.type === "alerte") d.fait = false; } }
      else if (G.drag.type === "ctrl" && Math.hypot(p.x - G.drag.p0.x, p.y - G.drag.p0.y) > 4) {   // Ctrl + glisser : copie du dessin
        const orig = G.dessins[G.drag.k];
        if (orig) {
          memoriser(); const copie = JSON.parse(JSON.stringify(orig)); copie.id = Math.random().toString(36).slice(2, 10); delete copie.fait;
          G.dessins.push(copie); G.multi.clear(); G.sel = G.dessins.length - 1; barreDessin();
          G.drag = { type: "deplacer", p0: G.drag.p0, items: [{ d: copie, pts0: G.drag.pts0 }] };
        }
      }
      if (G.drag && G.drag.type === "deplacer") {
        let di = g.ix(p.x) - g.ix(G.drag.p0.x), p1 = g.py(p.y); const p0 = g.py(G.drag.p0.y);
        if (e.shiftKey) { if (Math.abs(p.x - G.drag.p0.x) >= Math.abs(p.y - G.drag.p0.y)) p1 = p0; else di = 0; }   // Maj : horizontal ou vertical seulement
        if (p0 != null && p1 != null) for (const it of G.drag.items) it.d.pts = it.pts0.map(q => ({ t: tDe(idxDe(q.t) + di), p: +(q.p + p1 - p0).toFixed(G.chiffres + 1) }));
      }
    } else if (G.outil === "curseur") {
      let cur = "";
      if (lignePosProche(p, g)) cur = "ns-resize";
      else if (G.sel >= 0 && poigneeProche(p, g) >= 0) cur = "move";
      else if (!S.masquer && G.dessins.some(d => visible(d) && toucheDessin(d, p, g))) cur = "pointer";
      zone.style.cursor = cur;
    } else zone.style.cursor = G.outil === "gomme" ? "not-allowed" : "crosshair";
    sale = true;
  }
  function surUp(e) {
    if (G.drag?.type === "crea" && G.crea) {
      const p = pos(e), moved = Math.hypot(p.x - G.creaDown.x, p.y - G.creaDown.y) > 6;
      if (moved && nbPoints(G.crea.type) === 2) { G.drag = null; G.crea.fixes = 2; terminerCrea(); }
      else G.drag = null;
      sale = true; return;
    }
    if (G.drag?.type === "libre") { G.drag = null; terminerCrea(); return; }
    if (!G.drag) return;
    if (G.drag.type === "position") {
      const ps = G.drag.ps;
      if ((ps.sens > 0 && ps.sl >= ps.entree) || (ps.sens < 0 && ps.sl <= ps.entree)) { toast("Stop du mauvais côté : remis à sa place.", false); ps.sl = +(ps.entree - ps.sens * ps.entree * 0.002).toFixed(G.chiffres); lignesPosition(ps); }
    }
    if (G.drag.type === "ctrl") {                             // Ctrl + clic sans glisser : ajoute / retire le dessin de la sélection
      const d = G.dessins[G.drag.k];
      if (d) {
        if (G.multi.has(d) || G.dessins[G.sel] === d) { G.multi.delete(d); if (G.dessins[G.sel] === d) G.sel = -1; }
        else { if (G.dessins[G.sel]) G.multi.add(G.dessins[G.sel]); G.multi.add(d); G.sel = G.drag.k; }
        barreDessin();
      }
    }
    if (G.drag.type === "poignee" || G.drag.type === "deplacer") sauverDessins();
    chart.applyOptions({ handleScroll: true, handleScale: true });
    G.drag = null; sale = true;
  }
  function surDblClick(e) {
    if (G.crea && nbPoints(G.crea.type) === "multi") { e.stopPropagation(); G.crea.pts.pop(); if (G.crea.pts.length >= 2) terminerCrea(); else { G.crea = null; finOutil(); } return; }
    const d = G.dessins[G.sel];
    if (d && TYPES_TEXTE.includes(d.type)) { e.stopPropagation(); e.preventDefault(); editerSel(); }
    else if (d) { e.stopPropagation(); e.preventDefault(); G.drag = null; chart.applyOptions({ handleScroll: true, handleScale: true }); ouvrirStyleDessin(); }
  }
  // ================================================================== saisie du texte directement sur le graphique (comme TradingView)
  const TYPES_TEXTE = ["texte", "note", "noteprix", "epingle", "tableau", "callout", "commentaire", "etiquette", "panneau", "flechehaut", "flechebas", "drapeau"];
  let editeur = null;
  function fermerEditeur(valider) { if (editeur) editeur.terminer(valider); }
  function editerTexte(d, opts, fini) {
    fermerEditeur(true);
    const g = geo(), pt = d.pts[d.type === "callout" && d.pts[1] ? 1 : 0];
    const x = pt ? g.x(idxDe(pt.t)) : g.W / 2, y = (pt && g.y(pt.p)) ?? g.H / 2;
    const taille = d.type === "texte" ? 12 + (d.w || 2) * 2 : 13;
    const ta = document.createElement("textarea");
    ta.className = "editeur-texte"; ta.spellcheck = false;
    ta.value = d.txt != null && d.txt !== "" ? d.txt : String(opts.valeur || "").replace(/ ; /g, "\n");
    ta.placeholder = String(opts.aide || "Texte").replace(/\s*:\s*$/, "") + "…";
    ta.style.fontSize = taille + "px"; ta.style.color = d.c || (S.reg ? S.reg.texteC : "");
    ta.style.left = Math.max(4, Math.min(x - 4, g.W - 240)) + "px"; ta.style.top = Math.max(4, Math.min(y - taille - 8, g.H - 60)) + "px";
    const ajuster = () => {
      const lignes = ta.value.split("\n"), c = calque.getContext("2d"); c.font = taille + "px sans-serif";
      ta.style.width = Math.min(520, Math.max(170, ...lignes.map(l => c.measureText(l || ta.placeholder).width + 26))) + "px";
      ta.style.height = "auto"; ta.style.height = ta.scrollHeight + 2 + "px";
    };
    let fait = false;
    const terminer = valider => {
      if (fait) return; fait = true; editeur = null; ta.remove(); sale = true;
      fini(valider ? ta.value.replace(/\s+$/, "") : null);
    };
    ta.addEventListener("input", ajuster);
    ta.addEventListener("keydown", e => {
      e.stopPropagation();                                    // les raccourcis du graphique (Suppr, Alt+T…) ne s'appliquent pas pendant la saisie
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); terminer(true); }
      else if (e.key === "Escape") { e.preventDefault(); terminer(false); }
    });
    ta.addEventListener("blur", () => setTimeout(() => terminer(true), 0));
    ta.addEventListener("mousedown", e => e.stopPropagation());
    zone.appendChild(ta); editeur = { terminer };
    ajuster(); ta.focus(); ta.select();
  }
  function editerSel() {
    const d = G.dessins[G.sel]; if (!d) return;
    editerTexte(d, { aide: (TEXTES[d.type] || ["Texte"])[0] }, t => { if (t == null || t === (d.txt || "")) return; memoriser(); d.txt = t.slice(0, 1000); sauverDessins(); barreDessin(); sale = true; });
  }
  function finOutil() { G.outil = "curseur"; G.crea = null; G.hover = null; majOutils(); sale = true; }
  function choisirOutil(o) {
    if (G.crea) G.crea = null;
    // Dessins masqués (œil de la barre d'outils ou clic droit, facile à activer par erreur au pavé tactile) :
    // sinon le nouveau dessin serait visible pendant le tracé puis « disparaîtrait » au relâchement du clic.
    if (o !== "curseur" && S.masquer) {
      S.masquer = false; sauverPrefs(); sale = true;
      toast("Vos dessins étaient masqués : ils sont de nouveau affichés.");
    }
    G.outil = o; G.mesure = null; majOutils();
    if (o === "image" && !G.imageEnAttente) choisirImage();
    if (o !== "curseur" && o !== "gomme") { G.sel = -1; barreDessin(); }
  }

  // ================================================================== positions simulées
  function lignesPosition(p, recreer) {
    if (recreer || !p.lignes) {
      p.lignes = {
        e: serie.createPriceLine({ price: p.entree, color: p.active ? BLEU : "#787b86", lineWidth: 1, lineStyle: 0, axisLabelVisible: true, title: "" }),
        s: serie.createPriceLine({ price: p.sl, color: ROUGE, lineWidth: 1, lineStyle: 0, axisLabelVisible: true, title: "SL" }),
        t: p.tp ? serie.createPriceLine({ price: p.tp, color: VERT, lineWidth: 1, lineStyle: 0, axisLabelVisible: true, title: "TP" }) : null,
      };
    }
    const last = G.bars[nVis() - 1], r = p.active && last ? (last[4] - p.entree) * p.sens / Math.abs(p.entree - p.sl) : 0;
    const vis = { lineVisible: S.reg.tPositions, axisLabelVisible: S.reg.tPositions };
    p.lignes.s.applyOptions(vis); if (p.lignes.t) p.lignes.t.applyOptions(vis);
    p.lignes.e.applyOptions({ ...vis, price: p.entree, color: p.active ? BLEU : "#787b86", title: `${p.sens > 0 ? "Achat" : "Vente"}${p.active ? " " + (r >= 0 ? "+" : "") + r.toFixed(2) + " R" : " (en attente)"}` });
    p.lignes.s.applyOptions({ price: p.sl });
    if (p.lignes.t) p.lignes.t.applyOptions({ price: p.tp });
  }
  function retirerLignes(p) { if (p.lignes) for (const k of ["e", "s", "t"]) if (p.lignes[k]) { try { serie.removePriceLine(p.lignes[k]); } catch (e) { /* série recréée */ } } p.lignes = null; }
  function lignePosProche(p, g) {
    if (p.x > g.W) return null;
    for (const ps of G.positions) for (const k of ["sl", "tp", "entree"]) {
      if (ps[k] == null || (k === "entree" && ps.active)) continue;
      const y = g.y(ps[k]); if (y != null && Math.abs(y - p.y) < 6) return { ps, k };
    }
    return null;
  }
  function placer(sens, entreeForcee, slForce) {
    const n = nVis(); if (!n) return;
    const last = G.bars[n - 1], prix = last[4];
    let entree = entreeForcee ?? ($("#oType").value === "limite" && +$("#oLimite").value > 0 ? +$("#oLimite").value : prix);
    if (entreeForcee != null && Math.abs(entreeForcee - prix) / prix < 0.0004) entree = prix;
    let sl = slForce ?? +$("#oSL").value;
    if (!(sl > 0)) {
      const seg = G.bars.slice(Math.max(0, n - 10), n);
      sl = sens > 0 ? Math.min(...seg.map(b => b[3])) : Math.max(...seg.map(b => b[2]));
      const marge = Math.abs(entree - sl) * 0.05 || entree * 0.0005; sl = sens > 0 ? sl - marge : sl + marge;
    }
    if ((sens > 0 && sl >= entree) || (sens < 0 && sl <= entree)) { toast(sens > 0 ? "Pour un achat, le stop doit être sous l'entrée." : "Pour une vente, le stop doit être au-dessus de l'entrée.", false); return; }
    let tp = +$("#oTP").value; const rr = +$("#oRR").value;
    if (!(tp > 0) && rr > 0) tp = entree + sens * rr * Math.abs(entree - sl);
    if (tp > 0 && ((sens > 0 && tp <= entree) || (sens < 0 && tp >= entree))) { toast("L'objectif doit être du côté du gain.", false); return; }
    const arr = v => +(+v).toFixed(G.chiffres), active = entree === prix;
    const p = { id: Math.random().toString(36).slice(2), sens, entree: arr(entree), sl: arr(sl), tp: tp > 0 ? arr(tp) : null, active,
      t_entree: active ? last[0] + G.sec : null, strategie: $("#oStrat").value.trim(), unite: S.unite, mode: G.mode, actif: S.actif,
      ordre: active ? null : (sens > 0) === (entree < prix) ? "limite" : "stop" };
    G.positions.push(p); lignesPosition(p, true);
    $("#oSL").value = ""; $("#oTP").value = ""; $("#oLimite").value = "";
    tablePositions(); sale = true;
  }
  function evaluerBougie(b) {
    for (const p of [...G.positions]) {
      if (!p.active) { if (b[3] <= p.entree && p.entree <= b[2]) { p.active = true; p.t_entree = b[0]; } else continue; }
      const sl = p.sens > 0 ? b[3] <= p.sl : b[2] >= p.sl, tp = p.tp != null && (p.sens > 0 ? b[2] >= p.tp : b[3] <= p.tp);
      if (sl) fermer(p, p.sl, b[0] + G.sec, tp ? "SL (SL et TP dans la même bougie : compté perdant)" : "SL");
      else if (tp) fermer(p, p.tp, b[0] + G.sec, "TP");
      else lignesPosition(p);
    }
    verifierAlertes(b[3], b[2], b[0] + G.sec);
  }
  function evaluerPrix(prix, t) {
    for (const p of [...G.positions]) {
      if (!p.active) { if ((p.ordre === "limite") === (p.sens > 0) ? prix <= p.entree : prix >= p.entree) { p.active = true; p.t_entree = t; } else continue; }
      if (p.sens > 0 ? prix <= p.sl : prix >= p.sl) fermer(p, p.sl, t, "SL");
      else if (p.tp != null && (p.sens > 0 ? prix >= p.tp : prix <= p.tp)) fermer(p, p.tp, t, "TP");
      else lignesPosition(p);
    }
    if (G.dernierPrix != null) verifierAlertes(Math.min(G.dernierPrix, prix), Math.max(G.dernierPrix, prix), t);
    G.dernierPrix = prix;
  }
  async function fermer(p, prix, t, raison) {
    G.positions = G.positions.filter(x => x !== p); retirerLignes(p); tablePositions(); sale = true;
    if (!p.active) return;
    if (S.reg.tSon) bip();
    const corps = { actif: p.actif, unite: p.unite, sens: p.sens, entree: p.entree, sl: p.sl, tp: p.tp, sortie: prix, t_entree: p.t_entree, t_sortie: t,
      raison, strategie: p.strategie, mode: p.mode, session: S.session || null, capital: +$("#oCapital").value || 0, risque_pct: +$("#oRisque").value || 1 };
    try {
      const r = await api("/api/trade", corps);
      if (r.ok) { toast(`${p.sens > 0 ? "Achat" : "Vente"} ${p.actif} clôturé (${raison.split(" ")[0]}) : ${r.trade.r >= 0 ? "+" : ""}${r.trade.r} R${r.trade.montant != null ? " · " + (r.trade.montant >= 0 ? "+" : "") + r.trade.montant + " $" : ""}`, r.trade.r >= 0); chargerStats(); chargerSessions(); }
      else toast("⚠ " + (r.message || "trade non enregistré"), false);
    } catch (e) { toast("⚠ trade non enregistré (serveur injoignable)", false); }
  }
  function tablePositions() {
    const last = G.bars[nVis() - 1], risque = (+$("#oCapital").value || 0) * (+$("#oRisque").value || 0) / 100;
    $("#tPositions").innerHTML = G.positions.length ? `<tr><th>Actif</th><th>Sens</th><th>Entrée</th><th>Stop</th><th>Objectif</th><th>Résultat</th><th>Stratégie</th><th></th></tr>` +
      G.positions.map(p => {
        const r = p.active && last ? (last[4] - p.entree) * p.sens / Math.abs(p.entree - p.sl) : 0;
        return `<tr><td><b>${p.actif}</b> ${p.unite}</td><td style="color:${p.sens > 0 ? BLEU : ROUGE}">${p.sens > 0 ? "Achat" : "Vente"}${p.active ? "" : " (" + p.ordre + ")"}</td>
          <td>${fp(p.entree)}</td><td>${fp(p.sl)}</td><td>${fp(p.tp)}</td>
          <td style="color:${r >= 0 ? VERT : ROUGE}"><b>${p.active ? (r >= 0 ? "+" : "") + r.toFixed(2) + " R" + (risque ? " (" + (r * risque).toFixed(0) + " $)" : "") : "—"}</b></td>
          <td>${esc(p.strategie)}</td><td><button data-ferme="${p.id}">${p.active ? "Fermer" : "Annuler"}</button></td></tr>`;
      }).join("") : `<tr><td class="discret">Aucune position. Utilisez Acheter / Vendre, les boutons du graphique, ou les outils « position acheteuse / vendeuse ».</td></tr>`;
    $$("#tPositions [data-ferme]").forEach(b => b.onclick = async () => {
      const p = G.positions.find(x => x.id === b.dataset.ferme);
      if (p && S.reg.tConfirmer && !await demander(`${p.active ? "Fermer" : "Annuler"} cette position ${p.sens > 0 ? "acheteuse" : "vendeuse"} sur ${p.actif} ?`, { ok: p.active ? "Fermer" : "Annuler la position", annuler: "Retour" })) return;
      const lb = G.bars[nVis() - 1];
      if (p && lb) fermer(p, lb[4], G.mode === "replay" ? lb[0] + G.sec : Math.floor(Date.now() / 1000), "manuel");
    });
  }

  // ================================================================== alertes
  function bip() {
    try { const a = new (window.AudioContext || window.webkitAudioContext)(), o = a.createOscillator(), g = a.createGain(); o.frequency.value = 880; o.connect(g); g.connect(a.destination);
      g.gain.setValueAtTime(0.2, a.currentTime); g.gain.exponentialRampToValueAtTime(0.001, a.currentTime + 0.6); o.start(); o.stop(a.currentTime + 0.6); } catch (e) { /* son indisponible */ }
  }
  function verifierAlertes(bas, haut, t) {
    let change = false;
    for (const d of G.dessins) {
      if (d.type !== "alerte" || d.fait) continue;
      const p = d.pts[0].p;
      if (bas <= p && p <= haut) {
        d.fait = true; change = true; if (S.reg.aSon) bip(); if (S.reg.aSupprAuto) d.retirer = true;
        const msg = `⏰ Alerte ${S.actif} : le prix a touché ${fp(p)}${G.mode === "replay" ? " (replay, " + fdate(t) + ")" : ""}`;
        toast(msg);
        try { if (S.reg.aNotif && window.Notification && Notification.permission === "granted") new Notification("MaBoussole Graphiques", { body: msg }); } catch (e) { /* rien */ }
      }
    }
    if (change) { G.dessins = G.dessins.filter(d => !d.retirer); G.sel = -1; barreDessin(); sauverDessins(); sale = true; }
  }
  function tableAlertes() {
    const al = G.dessins.map((d, k) => [d, k]).filter(([d]) => d.type === "alerte");
    $("#tAlertes").innerHTML = al.length ? `<tr><th>Actif</th><th>Niveau</th><th>État</th><th></th></tr>` + al.map(([d, k]) => `<tr><td><b>${S.actif}</b></td><td>${fp(d.pts[0].p)}</td>
      <td>${d.fait ? "✔ déclenchée" : "⏰ active"}</td><td>${d.fait ? `<button data-rearmer="${k}">Réactiver</button>` : ""} <button data-suppr-al="${k}">Supprimer</button></td></tr>`).join("")
      : `<tr><td class="discret">Aucune alerte sur ${S.actif}. Bouton « Alerte » en haut, puis touchez le niveau sur le graphique. Les alertes sonnent tant que l'application est ouverte sur cet actif (en direct ou en replay).</td></tr>`;
    $$("#tAlertes [data-rearmer]").forEach(b => b.onclick = () => { memoriser(); G.dessins[+b.dataset.rearmer].fait = false; sauverDessins(); sale = true; });
    $$("#tAlertes [data-suppr-al]").forEach(b => b.onclick = () => { memoriser(); G.dessins.splice(+b.dataset.supprAl, 1); G.sel = -1; barreDessin(); sauverDessins(); sale = true; });
  }

  // ================================================================== replay
  function entrerReplay() {
    pause(); arreterDirect();
    if (G.mode !== "replay") { viderPositions(); G.mode = "replay"; G.rt = null; }
    G.outil = "coupe"; majOutils(); majMode();
    $("#rInfo").textContent = "Cliquez sur la bougie de départ";
  }
  async function demarrerReplay(t) {
    pause(); arreterDirect();
    if (!G.bars.length || t < G.bars[0][0] + 300 * G.sec || t > G.bars[G.bars.length - 1][0]) { const u = await chargerPourReplay(t); if (u == null) return; t = u; }
    viderPositions(); G.mode = "replay";
    const i = Math.max(1, Math.min(G.bars.length - 1, Math.round(idxDe(t))));
    G.rt = G.bars[i][0];
    G.outil = "curseur"; majOutils(); majMode();
    donnees(); chart.timeScale().scrollToRealTime(); majReplay();
  }
  // Replay dans le passé : quand il arrive au bout des bougies chargées, la suite est chargée toute seule
  async function chargerSuiteReplay() {
    if (G.suiteReplay) return; G.suiteReplay = true;
    const cle = S.actif + "|" + S.unite, der = G.bars[G.bars.length - 1][0];
    const fin = Math.min(Math.floor(Date.now() / 1000), der + 2500 * G.sec);
    toast("Chargement de la suite de l'historique…");
    let r = {};
    try { r = await api(`/api/bougies?actif=${S.actif}&unite=${S.unite}&n=3000&fin=${fin}`); } catch (e) { r = {}; }
    G.suiteReplay = false;
    if (cle !== S.actif + "|" + S.unite || G.mode !== "replay") return;
    const nouv = (r.bougies || []).filter(b => b[0] > der);
    if (!nouv.length) { pause(); toast("Pas de données plus récentes disponibles pour cette période.", false); return; }
    G.bars.push(...nouv); majReplay();
  }
  function avancer(k = 1) {
    if (G.charge || G.rt == null || G.suiteReplay) return;
    for (let j = 0; j < k; j++) {
      const i = nVis();
      if (i >= G.bars.length) {
        const der = G.bars.length ? G.bars[G.bars.length - 1][0] : 0;
        if (der && der < Date.now() / 1000 - 2 * G.sec) { chargerSuiteReplay(); break; }
        pause(); toast("Le replay est arrivé au présent."); break;
      }
      G.rt = G.bars[i][0] + G.sec; ajouterBougie(G.bars[i]); evaluerBougie(G.bars[i]);
    }
    majReplay(); tablePositions();
  }
  function reculer() {
    if (G.positions.some(p => p.active)) { toast("Fermez d'abord vos positions pour revenir en arrière.", false); return; }
    const n = nVis(); if (n > 1) { G.rt = G.bars[n - 2][0] + G.sec; donnees(); majReplay(); }
  }
  function lecture() {
    if (G.play) { pause(); return; }
    if (G.outil === "coupe" || G.rt == null) return;
    G.play = setInterval(() => avancer(1), 1000 / S.vitesse); $("#rPlay").textContent = "⏸";
  }
  function pause() { if (G.play) clearInterval(G.play); G.play = null; $("#rPlay").textContent = "▶"; }
  function majReplay() {
    const lb = G.bars[nVis() - 1]; $("#rInfo").textContent = lb && G.rt != null ? fdate(lb[0] + G.sec) : "";
    afficherPrixReplay();
  }
  // Pendant le replay, aucun prix en direct : le titre et la fiche montrent le prix du replay (temps réel seulement hors replay)
  function afficherPrixReplay() {
    if (G.mode !== "replay" || G.rt == null) return;
    const lb = G.bars[nVis() - 1]; if (!lb) return;
    document.title = `${S.actif} ${fp(lb[4])} · Replay · MaBoussole Graphiques`;
    const f = $("#fiche"); if (!f) return;
    f.innerHTML = `<div class="nom">${S.actif}</div><div class="desc">${esc(nomActif(S.actif))} · ${esc(catActif(S.actif))}</div>
      <div class="px">${fp(lb[4])}</div><div class="var ${lb[4] >= lb[1] ? "haut-v" : "bas-v"}">Replay · ${fdate(lb[0] + G.sec)}</div>
      <div class="discret" style="margin-top:6px">⏸ Cotations en direct en pause pendant le replay</div>`;
    $("#etatMarche").textContent = "Replay";
  }
  async function quitterReplay() {
    pause(); viderPositions(); G.mode = "direct"; G.rt = null; G.outil = "curseur";
    majOutils(); majMode(); await charger(); demarrerDirect(); majListe();
  }
  function viderPositions() { for (const p of G.positions) retirerLignes(p); G.positions = []; tablePositions(); }
  function majMode() { $("#bReplay").classList.toggle("actif", G.mode === "replay"); $("#replayCtl").style.display = G.mode === "replay" ? "" : "none"; }

  // ================================================================== direct et liste de suivi
  function demarrerDirect() {
    arreterDirect();
    const cle = S.actif + "|" + S.unite;
    const appliquer = r => {                               // nouvelles bougies (flux continu ou demande de secours)
      if (!r || !r.bougies || G.mode !== "direct" || G.charge || cle !== S.actif + "|" + S.unite || !G.bars.length) return;
      for (const b of r.bougies) {
        const n = G.bars.length;
        if (b[0] === G.bars[n - 1][0]) { G.bars[n - 1] = b; ajouterBougie(b); }
        else if (b[0] > G.bars[n - 1][0]) { G.bars.push(b); ajouterBougie(b); }
      }
      const lb = G.bars[G.bars.length - 1]; evaluerPrix(lb[4], Math.floor(Date.now() / 1000)); tablePositions();
      document.title = `${S.actif} ${fp(lb[4])} · MaBoussole Graphiques`;
    };
    // 1) flux continu : le serveur pousse chaque nouveau prix dès qu'il arrive du marché (comme TradingView)
    if (window.EventSource) {
      try {
        const es = new EventSource(`/api/direct?actif=${encodeURIComponent(S.actif)}&unite=${encodeURIComponent(S.unite)}`);
        es.onmessage = ev => { G.fluxVu = Date.now(); let r; try { r = JSON.parse(ev.data); } catch (e) { return; } if (!r.erreur) appliquer(r); };
        es.onerror = () => { G.fluxVu = 0; };                 // le navigateur se reconnecte tout seul ; en attendant, la demande de secours prend le relais
        G.flux = es;
      } catch (e) { G.flux = null; }
    }
    // 2) secours : une demande par seconde (20 s pour une source lente) seulement si le flux ne donne rien
    const periode = G.sec < 60 || /^(MetaTrader 5 \(|Temps réel|OANDA|Binance)/.test(G.source || "") ? 1000 : 20000;
    G.live = setInterval(async () => {
      if (G.mode !== "direct" || document.hidden || !G.bars.length || G.directEnCours) return;
      if (G.flux && G.flux.readyState === 1) return;          // le flux continu est ouvert : rien à demander (même si le marché est calme)
      let r; G.directEnCours = true;
      try { r = await Promise.race([api(`/api/recent?actif=${S.actif}&unite=${S.unite}`), new Promise((_, non) => setTimeout(() => non(new Error("lent")), 15000))]); }
      catch (e) { return; } finally { G.directEnCours = false; }
      appliquer(r);
    }, periode);
  }
  // fenêtre ou onglet caché : on rend sa connexion au navigateur (6 connexions au plus vers le logiciel, toutes fenêtres comprises)
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) { if (G.flux) { try { G.flux.close(); } catch (e) { /* rien */ } G.flux = null; } }
    else if (G.mode === "direct" && G.live && !G.flux && G.bars && G.bars.length) demarrerDirect();
  });
  function arreterDirect() { if (G.live) clearInterval(G.live); G.live = null; if (G.flux) { try { G.flux.close(); } catch (e) { /* rien */ } G.flux = null; } G.fluxVu = 0; }
  async function majListe() {
    if (document.hidden || G.listeEnCours) return;          // une seule demande à la fois : jamais d'embouteillage
    if (G.mode === "replay") { afficherPrixReplay(); return; }   // replay : pas de temps réel
    const noms = [...new Set([...S.liste, S.actif])];
    G.listeEnCours = true;
    try { G.prix = await Promise.race([api("/api/liste?actifs=" + noms.join(",")), new Promise((_, non) => setTimeout(() => non(new Error("lent")), 15000))]); }
    catch (e) { return; } finally { G.listeEnCours = false; }
    rendreListe();
  }
  function rendreListe() {
    const cats = ["Forex", "Matières premières", "Indices", "Crypto"];
    const parCat = {}; for (const a of S.liste) (parCat[catActif(a) || "Autres"] ||= []).push(a);
    $("#liste").innerHTML = [...cats, "Autres"].filter(c => parCat[c]).map(c => `<div class="cat">${c}</div>` + parCat[c].map(a => {
      const x = G.prix[a] || {}, pct = x.variation_pct, cl = pct > 0 ? "haut-v" : pct < 0 ? "bas-v" : "";
      const absv = x.prix != null && pct != null ? x.prix - x.prix / (1 + pct / 100) : null;
      return `<div class="ligne ${a === S.actif ? "actif" : ""}" data-a="${a}"><span class="sym"><span class="pt ${x.ouvert ? "ouvert" : ""}" title="${x.ouvert ? "Marché ouvert" : "Marché fermé"}"></span>${a}</span>
        <span>${x.prix != null ? fp(x.prix, x.chiffres) : "—"}</span><span class="${cl}">${absv != null ? (absv > 0 ? "+" : "") + fp(absv, x.chiffres) : "—"}</span>
        <span class="${cl}">${pct != null ? (pct > 0 ? "+" : "") + pct.toFixed(2) + " %" : "—"}</span><button class="x" data-retire="${a}" title="Retirer">✕</button></div>`;
    }).join("")).join("");
    const x = G.prix[S.actif];
    $("#fiche").innerHTML = `<div class="nom">${S.actif}</div><div class="desc">${esc(nomActif(S.actif))} · ${esc(catActif(S.actif))}</div>` + (x ? `
      <div class="px">${fp(x.prix, x.chiffres)}</div><div class="var ${x.variation_pct >= 0 ? "haut-v" : "bas-v"}">${x.variation_pct > 0 ? "+" : ""}${(x.variation_pct ?? 0).toFixed(2)} % aujourd'hui</div>
      <div class="discret" style="margin-top:6px">${x.ouvert ? "● Marché ouvert" : "— Marché fermé"} · ${esc(x.source || "")}</div>` : "");
    $("#etatMarche").textContent = x ? (x.ouvert ? "● Marché ouvert" : "Marché fermé") : "";
  }
  // Replay : en changeant d'unité de temps ou d'actif, on garde la même date de replay (rien ne s'efface, rien ne revient au début)
  // Charge l'historique autour d'une date de replay ; rend la date réellement utilisable (ou null si l'actif n'a rien)
  async function chargerPourReplay(t) {
    const sec = secondesU(S.unite) || G.sec || 60;                // la NOUVELLE unité (G.sec peut être encore l'ancienne ici)
    const maint = Date.now() / 1000;
    if (!await charger(Math.min(maint, t + 200 * sec))) return null; // l'historique avant la date, et un peu après pour la suite
    // actif plus jeune que la date (ex. NASDAQ avant 2011, Bitcoin avant 2017) : on repart du début de son historique
    if (!G.bars.length && G.debutHisto && G.debutHisto > t && !await charger(Math.min(maint, G.debutHisto + 250 * sec))) return null;
    if (!G.bars.length) { toast(`Pas d'historique de ${S.actif} en ${LIB_UNITE[S.unite]} à cette date.`, false); return null; }
    if (G.bars[0][0] + G.sec > t) {
      const depart = G.bars[Math.min(50, G.bars.length - 1)][0] + G.sec;
      toast(`${S.actif} n'a pas d'historique au ${fdate(t)} : le replay commence au ${fdate(depart)}`);
      return depart;
    }
    return t;
  }
  async function rechargerReplay(garde) {
    const t = await chargerPourReplay(garde);
    G.mode = "replay"; G.rt = t == null ? garde : t;
    donnees(); majReplay();
    try { chart.timeScale().scrollToRealTime(); } catch (e) { /* rien */ }
  }
  async function changerActif(a) {
    if (!a || a === S.actif) return;
    const garde = G.mode === "replay" ? G.rt : null;
    if (G.mode === "replay" && G.positions.some(p => p.active)) { if (!await demander("Changer d'actif ferme les positions simulées du replay. Continuer ?", { ok: "Continuer", danger: false })) return; viderPositions(); }
    S.actif = a; sauverPrefs(); await chargerDessins();
    if (garde) await rechargerReplay(garde);
    else { await charger(); demarrerDirect(); }
    rendreListe(); majListe();
  }
  async function changerUnite(u) {
    if (u === S.unite) return;
    const garde = G.mode === "replay" ? G.rt : null;
    S.unite = u; sauverPrefs(); majUnites();
    if (garde) await rechargerReplay(garde);
    else { await charger(); demarrerDirect(); }
  }
  async function allerDate(t) {
    if (G.mode === "replay" && G.rt != null && t > G.rt) { toast("En replay, on ne peut pas regarder le futur : utilisez ▶ ou ⏭.", false); return; }
    if (!G.bars.length || t < G.bars[0][0]) await charger(Math.min(Date.now() / 1000, t + 2000 * G.sec));
    const i = idxDe(t); chart.timeScale().setVisibleLogicalRange({ from: i - 80, to: i + 40 });
  }

  // ================================================================== boîtes de dialogue
  let dlgMode = "ouvrir", dlgCat = "Tous", dlgSel = 0;
  function ouvrirDlg(mode, texte = "") {
    dlgMode = mode; $("#dlgTitre").textContent = mode === "ajouter" ? "Ajouter à la liste de suivi" : mode === "comparer" ? "Comparer un actif (affiché en %)" : mode === "onglet" ? "Ouvrir un actif dans un nouvel onglet" : mode.startsWith("cellule:") ? "Actif de ce graphique" : "Rechercher un symbole";
    $("#dlgSymbole").classList.add("ouvert"); $("#dlgTexte").value = texte; dlgSel = 0; rendreDlg(); setTimeout(() => $("#dlgTexte").focus(), 10);
  }
  const fermerDlgs = () => { if ($("#dlgReg").classList.contains("ouvert")) annulerReglages(); $$(".dlg-fond").forEach(x => x.classList.remove("ouvert")); };
  function resultatsDlg() {
    const q = $("#dlgTexte").value.trim().toLowerCase();
    const alias = { or: "GOLD", gold: "GOLD", argent: "SILVER", petrole: "USOIL", pétrole: "USOIL", sp: "SPX500", us500: "SPX500", us30: "DOW", nas: "NASDAQ", us100: "NASDAQ", btc: "BITCOIN", eth: "ETHEREUM", xau: "GOLD", xag: "SILVER", ger: "DAX", v75: "VOL75", v100: "VOL100", v10: "VOL10", brent: "UKOIL", cac: "FRA40", cac40: "FRA40", us10y: "US10Y", sol: "SOLUSDT", xrp: "XRPUSDT", hsi: "HK50", stoxx: "EU50", xpd: "PALLADIUM" };
    return G.catalogue.filter(x => (dlgCat === "Tous" || x.categorie === dlgCat) && (!q || x.code.toLowerCase().includes(q) || x.nom.toLowerCase().includes(q) || alias[q] === x.code));
  }
  function rendreDlg() {
    $("#dlgCats").innerHTML = ["Tous", ...new Set(G.catalogue.map(x => x.categorie))].map(c => `<button class="${c === dlgCat ? "actif" : ""}" data-cat="${c}">${c}</button>`).join("");
    const res = resultatsDlg(); dlgSel = Math.min(dlgSel, Math.max(0, res.length - 1));
    $("#dlgListe").innerHTML = res.map((x, i) => `<div class="dlg-ligne ${i === dlgSel ? "sel" : ""}" data-code="${x.code}"><b>${x.code}</b><span>${esc(x.nom)}</span><span class="c">${esc(x.categorie)}</span></div>`).join("")
      || `<p class="discret" style="padding:0 18px">Aucun actif trouvé.</p>`;
  }
  function choisirDlg(code) {
    fermerDlgs();
    if (dlgMode === "ajouter") { if (!S.liste.includes(code)) { S.liste.push(code); sauverPrefs(); majListe(); } }
    else if (dlgMode === "comparer") ajouterComparaison(code);
    else if (dlgMode === "onglet") nouvelOnglet(code);
    else if (dlgMode.startsWith("cellule:")) { const i = +dlgMode.split(":")[1], cell = G.cells[i]; if (cell) { S.cellules[i].actif = code; sauverPrefs(); chargerCellule(cell); } }
    else changerActif(code);
  }
  let indCat = "Tous";
  function ouvrirInd() { $("#dlgInd").classList.add("ouvert"); $("#dlgIndTexte").value = ""; rendreInd(); setTimeout(() => $("#dlgIndTexte").focus(), 10); }
  function rendreInd() {
    $("#dlgIndCats").innerHTML = ["Tous", ...CATS_IND].map(c => `<button class="${c === indCat ? "actif" : ""}" data-cat="${c}">${c}</button>`).join("");
    const q = $("#dlgIndTexte").value.trim().toLowerCase();
    const res = Object.entries(INDS).filter(([id, d]) => (indCat === "Tous" || d.cat === indCat) && (!q || d.nom.toLowerCase().includes(q) || d.court.toLowerCase().includes(q) || id.includes(q)));
    $("#dlgIndListe").innerHTML = res.map(([id, d]) => `<div class="dlg-ligne" data-ind="${id}"><b>${esc(d.court)}</b><span>${esc(d.nom)}</span><span class="${S.inds.some(x => x.id === id) ? "ajoute" : "c"}">${S.inds.some(x => x.id === id) ? "✔ sur le graphique" : esc(d.cat)}</span></div>`).join("");
  }
  function ajouterInd(id) {
    const d = INDS[id];
    if (d.calque && S.inds.some(x => x.id === id)) { toast(d.court + " est déjà sur le graphique."); return; }
    S.inds.push({ uid: "i" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), id, p: JSON.parse(JSON.stringify(d.p)) });
    sauverPrefs(); donnees(); rendreInd(); toast(d.nom + " ajouté.");
  }
  let paramUid = null;
  function ouvrirParam(uid) {
    const ind = S.inds.find(x => x.uid === uid); if (!ind) return;
    paramUid = uid; const d = INDS[ind.id], p = Object.assign({}, d.p, ind.p);
    $("#dlgParamTitre").textContent = d.nom;
    $("#dlgParamCorps").innerHTML = Object.entries(p).map(([k, v]) => `<label>${esc(NOMS_PARAM[k] || k)}${typeof v === "boolean" ? `<input type="checkbox" data-k="${k}" ${v ? "checked" : ""}>`
      : String(v).startsWith("#") ? `<input type="color" data-k="${k}" value="${v}">` : typeof v === "string" ? `<input type="text" maxlength="80" data-k="${k}" value="${esc(v)}">`
      : `<input type="number" step="any" data-k="${k}" value="${v}">`}</label>`).join("");
    $("#dlgParam").classList.add("ouvert");
  }
  const k0 = el => ["decalage", "opacite"].includes(el.dataset.k);      // paramètres qui peuvent valoir 0
  function validerParam(defaut) {
    const ind = S.inds.find(x => x.uid === paramUid); if (!ind) return;
    if (defaut) ind.p = JSON.parse(JSON.stringify(INDS[ind.id].p));
    else $$("#dlgParamCorps [data-k]").forEach(el => { ind.p[el.dataset.k] = el.type === "checkbox" ? el.checked : el.type === "color" ? el.value : el.type === "text" ? el.value.trim().slice(0, 80) : k0(el) ? +el.value || 0 : Math.max(0.0001, +el.value || INDS[ind.id].p[el.dataset.k]); });
    if (G.indSeries[ind.uid]) { for (const s of G.indSeries[ind.uid]) chart.removeSeries(s); delete G.indSeries[ind.uid]; }
    sauverPrefs(); fermerDlgs(); donnees();
  }


  // ================================================================== analyses enregistrées et sessions de backtest
  const RES_ANA = { attente: ["En attente", "#787b86"], gagnante: ["Gagnante", VERT], perdante: ["Perdante", ROUGE], nulle: ["Nulle (BE)", "#2962ff"], annulee: ["Annulée", "#b2b5be"] };
  const BIAIS_ANA = { haussier: ["▲ Haussier", VERT], baissier: ["▼ Baissier", ROUGE], neutre: ["◆ Neutre", "#787b86"] };
  const ouvrirFen = id => { $(id).classList.add("ouvert"); };
  function imageGraphique(largeurMax = 1400) {
    const img = chart.takeScreenshot(), c = img.getContext("2d");
    c.drawImage(calque, 0, 0, calque.width, calque.height, 0, 0, img.width, img.height);
    const k = Math.min(1, largeurMax / img.width), cv = document.createElement("canvas");
    cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
    const cx = cv.getContext("2d"); cx.fillStyle = S.reg ? S.reg.fond : "#fff"; cx.fillRect(0, 0, cv.width, cv.height); cx.drawImage(img, 0, 0, cv.width, cv.height);
    return cv.toDataURL("image/jpeg", 0.85);
  }
  function ouvrirDlgAnalyse(a) {
    G.anaEdit = a || null;
    const n = nVis(), last = G.bars[n - 1];
    $("#anaTitreDlg").textContent = a ? "Modifier l'analyse" : "Enregistrer l'analyse";
    if (a) { $("#anaApercu").src = a.image ? `/api/analyse/image?id=${a.id}&v=${a.modifie || 0}` : ""; }
    else { G.anaImage = imageGraphique(); $("#anaApercu").src = G.anaImage; }
    $("#anaApercu").style.display = a && !a.image ? "none" : "";
    $("#anaTitre").value = a ? a.titre || "" : `${S.actif} ${LIB_UNITE[S.unite]}`;
    $("#anaStrat").value = a ? a.strategie || "" : $("#oStrat").value;
    $("#anaBiais").value = a ? a.biais || "neutre" : "neutre";
    $("#anaRes").value = a ? a.resultat || "attente" : "attente";
    $("#anaR").value = a && a.r != null ? a.r : "";
    $("#anaNotes").value = a ? a.notes || "" : "";
    $("#anaInfo").textContent = a ? `${a.actif} · ${a.unite} · ${fdate(a.t)}${a.mode === "replay" ? " (replay)" : ""}`
      : `${S.actif} · ${LIB_UNITE[S.unite]} · ${last ? fdate(last[0] + G.sec) : ""}${G.mode === "replay" ? " (replay)" : ""} · vos dessins sont gardés avec l'analyse`;
    ouvrirFen("#dlgAnalyse"); setTimeout(() => $("#anaTitre").focus(), 50);
  }
  async function validerAnalyse() {
    const a = G.anaEdit, n = nVis(), last = G.bars[n - 1], rv = $("#anaR").value;
    const corps = { titre: $("#anaTitre").value, strategie: $("#anaStrat").value, biais: $("#anaBiais").value, resultat: $("#anaRes").value, notes: $("#anaNotes").value, r: rv === "" ? null : +rv };
    if (a) corps.id = a.id;
    else Object.assign(corps, { actif: S.actif, unite: S.unite, t: last ? last[0] + G.sec : Math.floor(Date.now() / 1000), mode: G.mode, prix: last ? last[4] : null, image: G.anaImage, dessins: G.dessins });
    const r = await api("/api/analyse", corps);
    if (!r.ok) { toast("⚠ " + (r.message || "analyse non enregistrée"), false); return; }
    $("#dlgAnalyse").classList.remove("ouvert"); G.anaImage = null;
    toast(a ? "Analyse modifiée." : "Analyse enregistrée : retrouvez-la dans « Mes analyses ».");
    chargerAnalyses();
  }
  async function chargerAnalyses() {
    let r; try { r = await api("/api/analyses"); } catch (e) { return; }
    G.analyses = r.analyses;
    const fs = $("#fAnaStrat").value, fr = $("#fAnaRes").value, strats = [...new Set(r.analyses.map(a => a.strategie || "Sans nom"))].sort();
    $("#fAnaStrat").innerHTML = `<option value="">Toutes les stratégies</option>` + strats.map(s => `<option ${s === fs ? "selected" : ""}>${esc(s)}</option>`).join("");
    const st = r.stats, wr = x => x.winrate == null ? "—" : x.winrate + " %";
    const choisie = fs ? st.par_strategie.find(x => x.cle === fs) || st.global : st.global;
    const tuile = (t, v, c) => `<div class="tuile"><div class="t">${t}</div><b style="color:${c || "inherit"}">${v}</b></div>`;
    $("#statsAnalyses").innerHTML = r.analyses.length ? `<div class="tuiles">${tuile("Winrate des analyses" + (fs ? " · " + esc(fs) : ""), wr(choisie), choisie.winrate >= 50 ? VERT : choisie.winrate != null ? ROUGE : "")}
        ${tuile("Analyses", choisie.total)}${tuile("Gagnantes", choisie.gagnantes, VERT)}${tuile("Perdantes", choisie.perdantes, ROUGE)}${tuile("Nulles (BE)", choisie.nulles)}${tuile("En attente", choisie.en_attente)}
        ${choisie.r_total != null ? tuile("Total en R", (choisie.r_total > 0 ? "+" : "") + choisie.r_total + " R", choisie.r_total >= 0 ? VERT : ROUGE) : ""}</div>
      ${!fs && st.par_strategie.length > 1 ? `<table class="tab"><tr><th>Stratégie</th><th>Analyses</th><th>Gagnantes</th><th>Perdantes</th><th>Winrate</th><th>Total R</th></tr>${st.par_strategie.map(x => `<tr><td><b>${esc(x.cle)}</b></td><td>${x.total}</td><td>${x.gagnantes}</td><td>${x.perdantes}</td><td><b>${wr(x)}</b></td><td>${x.r_total != null ? x.r_total + " R" : "—"}</td></tr>`).join("")}</table>` : ""}
      <p class="discret">Le winrate compte les analyses gagnantes et perdantes (les nulles, annulées et en attente sont à part). Mettez à jour le résultat quand le trade se termine.</p>`
      : `<p class="discret">Aucune analyse enregistrée. Préparez votre graphique (dessins, niveaux), puis cliquez sur 💾 en haut ou sur « Enregistrer l'analyse en cours » : la capture, l'actif, la date, vos dessins, la stratégie et vos notes sont gardés. Indiquez ensuite si elle a été gagnante ou perdante pour suivre votre winrate.</p>`;
    const liste = r.analyses.filter(a => (!fs || (a.strategie || "Sans nom") === fs) && (!fr || (a.resultat || "attente") === fr));
    $("#grilleAnalyses").innerHTML = liste.map(a => {
      const b = BIAIS_ANA[a.biais] || BIAIS_ANA.neutre;
      return `<div class="carte-ana" data-id="${a.id}">
        ${a.image ? `<img loading="lazy" src="/api/analyse/image?id=${a.id}&v=${a.modifie || 0}" data-ana-act="voir" title="Agrandir">` : `<div class="sans-image">${esc(a.actif)}</div>`}
        <div class="ca-corps"><div class="ca-titre">${esc(a.titre || a.actif)}</div>
          <div class="discret">${esc(a.actif)} · ${esc(a.unite)} · ${fdate(a.t)}${a.mode === "replay" ? " · replay" : ""}</div>
          <div class="ca-ligne"><span style="color:${b[1]}">${b[0]}</span>${a.strategie ? `<span class="discret">· ${esc(a.strategie)}</span>` : ""}</div>
          <div class="ca-ligne"><select data-ana-res style="color:${(RES_ANA[a.resultat] || RES_ANA.attente)[1]}">${Object.entries(RES_ANA).map(([k, v]) => `<option value="${k}" ${k === (a.resultat || "attente") ? "selected" : ""}>${v[0]}</option>`).join("")}</select>${a.r != null ? `<b style="color:${a.r >= 0 ? VERT : ROUGE}">${a.r > 0 ? "+" : ""}${a.r} R</b>` : ""}</div>
          <div class="ca-actions"><button data-ana-act="ouvrir">Ouvrir sur le graphique</button><button data-ana-act="modifier">Modifier</button><button data-ana-act="suppr" title="Supprimer">✕</button></div></div></div>`;
    }).join("");
  }
  async function actionAnalyse(e) {
    const carte = e.target.closest(".carte-ana"); if (!carte) return;
    const a = (G.analyses || []).find(x => x.id === carte.dataset.id); if (!a) return;
    const b = e.target.closest("[data-ana-act]"); if (!b) return;
    const act = b.dataset.anaAct;
    if (act === "voir") {
      $("#imgTitre").textContent = `${a.titre || a.actif} · ${a.actif} ${a.unite} · ${fdate(a.t)}`;
      $("#imgGrande").src = `/api/analyse/image?id=${a.id}&v=${a.modifie || 0}`;
      $("#imgNotes").textContent = a.notes || ""; ouvrirFen("#dlgImage");
    } else if (act === "modifier") ouvrirDlgAnalyse(a);
    else if (act === "suppr") { if (await demander(`Supprimer l'analyse « ${a.titre || a.actif} » ?`)) { await api("/api/analyse/supprimer", { id: a.id }); chargerAnalyses(); } }
    else if (act === "ouvrir") {
      if (G.mode === "replay" && G.rt != null && a.t > G.rt) { toast("Quittez le replay pour ouvrir une analyse plus récente que le replay en cours.", false); return; }
      await changerActif(a.actif); if (a.unite && uniteValide(a.unite)) { await changerUnite(a.unite); majUnites(); } await allerDate(a.t);
      toast(`Analyse ouverte : ${a.titre || a.actif}${a.dessins && a.dessins.length ? " (" + a.dessins.length + " dessin(s) enregistré(s) avec l'analyse)" : ""}`);
    }
  }
  // sessions de backtest
  async function chargerSessions() {
    let r; try { r = await api("/api/sessions"); } catch (e) { return; }
    G.sessions = r.sessions;
    if (S.session && !r.sessions.some(s => s.id === S.session && !s.termine)) { S.session = null; sauverPrefs(); }
    const v = $("#fSession").value;
    $("#fSession").innerHTML = `<option value="">Tous les backtests</option>` + r.sessions.map(s => `<option value="${s.id}" ${s.id === v ? "selected" : ""}>${esc(s.nom)}${s.stats.n ? " · " + s.stats.reussite + " %" : ""}</option>`).join("");
    const cur = r.sessions.find(s => s.id === S.session);
    $("#btActif").innerHTML = cur ? `<span>🧪 Backtest en cours : <b>${esc(cur.nom)}</b> · ${esc(cur.strategie)} · ${cur.stats.n || 0} trade(s)${cur.stats.n ? " · réussite " + cur.stats.reussite + " % · " + (cur.stats.r_total > 0 ? "+" : "") + cur.stats.r_total + " R" : ""}</span><button class="gros gris" data-bt-act="terminer" data-id="${cur.id}">Terminer ce backtest</button>`
      : `<span class="discret">Aucun backtest en cours : les trades sont enregistrés sans session.</span><button class="gros gris" data-bt-act="nouveau">＋ Nouveau backtest</button>`;
    $("#listeBT").innerHTML = r.sessions.length ? `<h4>Mes backtests</h4><table class="tab"><tr><th>Backtest</th><th>Stratégie</th><th>Trades</th><th>Réussite</th><th>Espérance</th><th>Total</th><th>Drawdown</th><th>État</th><th></th></tr>` +
      r.sessions.map(s => { const g = s.stats, c = x => x > 0 ? VERT : x < 0 ? ROUGE : "inherit";
        return `<tr><td><b>${esc(s.nom)}</b><br><span class="discret">depuis le ${new Date(s.cree * 1000).toLocaleDateString(LOC)}</span></td><td>${esc(s.strategie)}</td><td>${g.n || 0}</td>
          <td><b>${g.n ? g.reussite + " %" : "—"}</b></td><td style="color:${c(g.esperance)}">${g.n ? (g.esperance > 0 ? "+" : "") + g.esperance + " R" : "—"}</td><td style="color:${c(g.r_total)}">${g.n ? (g.r_total > 0 ? "+" : "") + g.r_total + " R" : "—"}</td>
          <td>${g.n ? g.drawdown_max + " R" : "—"}</td><td>${s.id === S.session ? "🧪 en cours" : s.termine ? "terminé" : "en pause"}</td>
          <td class="part-actions"><button data-bt-act="voir" data-id="${s.id}">Statistiques</button>${s.id === S.session ? `<button data-bt-act="terminer" data-id="${s.id}">Terminer</button>` : `<button data-bt-act="reprendre" data-id="${s.id}">Continuer</button>`}<button data-bt-act="supprimer" data-id="${s.id}" title="Supprimer">✕</button></td></tr>`; }).join("") + `</table>` : "";
  }
  async function actionBT(e) {
    const b = e.target.closest("[data-bt-act]"); if (!b) return;
    const a = b.dataset.btAct, id = b.dataset.id, s = (G.sessions || []).find(x => x.id === id);
    if (a === "nouveau") { $("#btNom").value = ""; $("#btStrat").value = $("#oStrat").value; $("#btRegles").value = ""; ouvrirFen("#dlgBT"); setTimeout(() => $("#btNom").focus(), 50); return; }
    if (a === "voir") { $("#fSession").value = id; $('.onglets-bas [data-bas="testeur"]').click(); chargerStats(); return; }
    if (a === "terminer") { await api("/api/session", { action: "terminer", id }); if (S.session === id) { S.session = null; sauverPrefs(); } toast("Backtest terminé : ses résultats restent dans « Mes backtests »."); }
    if (a === "reprendre") { await api("/api/session", { action: "reprendre", id }); S.session = id; sauverPrefs(); if (s) $("#oStrat").value = s.strategie; toast(`Backtest « ${s ? s.nom : ""} » repris : les prochains trades y seront rangés.`); }
    if (a === "supprimer") {
      if (!await demander(`Supprimer le backtest « ${s ? s.nom : ""} » ?`)) return;
      const avec = (s && s.stats.n) ? await demander(`Supprimer aussi ses ${s.stats.n} trade(s) ? Sinon, ils sont gardés (sans backtest).`, { ok: "Supprimer les trades", annuler: "Garder les trades" }) : false;
      await api("/api/session", { action: "supprimer", id, avec_trades: avec }); if (S.session === id) { S.session = null; sauverPrefs(); }
    }
    chargerSessions(); chargerStats();
  }
  function ouvrirDlgTrade() {
    $("#mtActif").innerHTML = G.catalogue.map(x => `<option value="${x.code}" ${x.code === S.actif ? "selected" : ""}>${x.code}</option>`).join("");
    $("#mtUnite").innerHTML = UNITES.map(u => `<option value="${u}" ${u === S.unite ? "selected" : ""}>${LIB_UNITE[u]}</option>`).join("");
    const d = new Date(Date.now() - new Date().getTimezoneOffset() * 60000); $("#mtDate").value = d.toISOString().slice(0, 16);
    $("#mtR").value = ""; $("#mtNote").value = ""; $("#mtStrat").value = $("#oStrat").value;
    const cur = (G.sessions || []).find(s => s.id === S.session);
    $("#mtInfo").textContent = cur ? `Ce trade sera rangé dans le backtest en cours : ${cur.nom}.` : "Aucun backtest en cours : le trade sera enregistré sans session.";
    ouvrirFen("#dlgTrade");
  }
  async function validerTrade() {
    const r = parseFloat($("#mtR").value), t = Math.floor(new Date($("#mtDate").value).getTime() / 1000);
    if (isNaN(r)) { toast("Indiquez le résultat en R (ex. 2 pour un gain de 2R, -1 pour une perte).", false); return; }
    if (!t) { toast("Indiquez la date du trade.", false); return; }
    const res = await api("/api/trade", { actif: $("#mtActif").value, unite: $("#mtUnite").value, sens: +$("#mtSens").value, r, t_entree: t, t_sortie: t,
      strategie: $("#mtStrat").value, note: $("#mtNote").value, session: S.session || null, capital: +$("#oCapital").value || 0, risque_pct: +$("#oRisque").value || 1 });
    if (!res.ok) { toast("⚠ " + (res.message || "trade non enregistré"), false); return; }
    $("#dlgTrade").classList.remove("ouvert"); toast("Trade ajouté."); chargerStats(); chargerSessions();
  }
  function brancherAnalyses() {
    $("#bAnalyse").onclick = () => ouvrirDlgAnalyse(); $("#bAnalyse2").onclick = () => ouvrirDlgAnalyse();
    $("#anaOk").onclick = validerAnalyse; $("#btOk").onclick = async () => {
      const r = await api("/api/session", { action: "creer", nom: $("#btNom").value, strategie: $("#btStrat").value, regles: $("#btRegles").value });
      if (!r.ok) { toast("⚠ " + (r.message || "backtest non créé"), false); return; }
      S.session = r.session.id; sauverPrefs(); $("#oStrat").value = r.session.strategie; $("#dlgBT").classList.remove("ouvert");
      toast(`Backtest « ${r.session.nom} » commencé : lancez un replay et placez vos positions.`); chargerSessions(); chargerStats();
    };
    $("#mtOk").onclick = validerTrade; $("#bAjoutTrade").onclick = ouvrirDlgTrade;
    $("#bNouveauBT").onclick = () => actionBT({ target: Object.assign(document.createElement("b"), { dataset: { btAct: "nouveau" } }) });
    $$("[data-fermer]").forEach(b => b.onclick = () => b.closest(".dlg-fond").classList.remove("ouvert"));
    $("#grilleAnalyses").onclick = actionAnalyse;
    $("#grilleAnalyses").onchange = async e => {
      const sel = e.target.closest("[data-ana-res]"), carte = e.target.closest(".carte-ana"); if (!sel || !carte) return;
      const r = await api("/api/analyse", { id: carte.dataset.id, resultat: sel.value }); if (!r.ok) toast("⚠ " + (r.message || "échec"), false); chargerAnalyses();
    };
    $("#fAnaStrat").onchange = chargerAnalyses; $("#fAnaRes").onchange = chargerAnalyses; $("#fSession").onchange = chargerStats;
    $("#btActif").onclick = actionBT; $("#listeBT").onclick = actionBT;
    chargerSessions();
  }

  // ================================================================== testeur de stratégie
  async function chargerStats() {
    const s = $("#fStrat").value, m = $("#fMode").value, ss = $("#fSession").value;
    let r; try { r = await api(`/api/stats?strategie=${encodeURIComponent(s)}&mode=${m}&session=${ss}`); } catch (e) { return; }
    $("#listeStrat").innerHTML = r.strategies.map(x => `<option value="${esc(x)}">`).join("");
    const v = $("#fStrat").value;
    $("#fStrat").innerHTML = `<option value="">Toutes les stratégies</option>` + r.strategies.map(x => `<option ${x === v ? "selected" : ""}>${esc(x)}</option>`).join("");
    const gl = r.global, col = x => x > 0 ? VERT : x < 0 ? ROUGE : "inherit";
    if (!gl) { $("#stats").innerHTML = `<p class="discret">Pas encore de trade. Lancez un replay sur n'importe lequel des 44 actifs, placez des positions : chaque position clôturée est enregistrée ici avec sa stratégie.</p>`; $("#tTrades").innerHTML = ""; return; }
    const tuile = (t, val, c) => `<div class="tuile"><div class="t">${t}</div><b style="color:${c || "inherit"}">${val}</b></div>`;
    const tab = (titre, arr) => arr && arr.length ? `<div><h4>${titre}</h4><table class="tab"><tr><th></th><th>Trades</th><th>Réussite</th><th>Espérance</th><th>Total</th></tr>
      ${arr.map(x => `<tr><td>${esc(x.cle)}</td><td>${x.n}</td><td>${x.reussite} %</td><td style="color:${col(x.esperance)}">${x.esperance > 0 ? "+" : ""}${x.esperance} R</td><td style="color:${col(x.r_total)}">${x.r_total > 0 ? "+" : ""}${x.r_total} R</td></tr>`).join("")}</table></div>` : "";
    const verdict = gl.n < 30 ? `${gl.n} trade(s) : il en faut au moins 30 pour juger une stratégie.` : gl.esperance > 0.2 ? "Espérance positive sur un échantillon suffisant : la stratégie a un avantage mesuré." : gl.esperance > 0 ? "Espérance faiblement positive : avantage fragile (écart et commissions non comptés)." : "Espérance négative : cette stratégie perd sur ce backtest.";
    $("#stats").innerHTML = `<div class="tuiles">${tuile("Bénéfice net", (gl.r_total > 0 ? "+" : "") + gl.r_total + " R" + (gl.montant != null ? " · " + (gl.montant > 0 ? "+" : "") + gl.montant + " $" : ""), col(gl.r_total))}
      ${tuile("Total des trades", gl.n)}${tuile("Pourcentage de réussite", gl.reussite + " %")}${tuile("Facteur de profit", gl.facteur_profit ?? "—")}
      ${tuile("Drawdown max", gl.drawdown_max + " R", ROUGE)}${tuile("Trade moyen (espérance)", (gl.esperance > 0 ? "+" : "") + gl.esperance + " R", col(gl.esperance))}
      ${tuile("Gain moyen / perte moyenne", "+" + gl.gain_moyen + " / " + gl.perte_moyenne + " R")}${tuile("Pertes d'affilée max", gl.pertes_d_affilee_max)}</div>
      <div class="verdict">${verdict}</div><canvas id="courbe" style="width:100%;height:150px"></canvas>
      <div class="blocs">${tab("Par séance", r.par.seance)}${tab("Par actif", r.par.actif)}${tab("Par jour", r.par.jour)}${tab("Achat / vente", r.par.sens)}${tab("Par unité de temps", (r.par.unite || []).map(x => Object.assign({}, x, { cle: LIB_UNITE[x.cle] || x.cle })))}${!s ? tab("Par stratégie", r.par_strategie) : ""}</div>`;
    courbe(gl.courbe);
    $("#tTrades").innerHTML = `<tr><th>N°</th><th>Sortie</th><th>Actif</th><th>Sens</th><th>Entrée</th><th>Sortie</th><th>Résultat</th><th>Stratégie</th><th>Mode</th><th></th></tr>` +
      r.trades.map((t, i) => `<tr><td>${r.trades.length - i}</td><td>${esc(new Date(t.t_sortie * 1000).toLocaleString(LOC, { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" }))}</td>
        <td><b>${esc(t.actif)}</b> ${esc(t.unite)}</td><td style="color:${t.sens > 0 ? BLEU : ROUGE}">${t.sens > 0 ? "Achat" : "Vente"}</td><td>${t.entree ?? "—"}</td><td>${t.sortie ?? "—"} <span class="discret">${esc(t.raison.split(" ")[0])}</span></td>
        <td style="color:${col(t.r)}"><b>${t.r > 0 ? "+" : ""}${t.r} R</b>${t.montant != null ? " · " + t.montant + " $" : ""}</td><td>${esc(t.strategie)}</td><td>${t.mode}</td><td><button data-suppr="${t.id}" title="Supprimer">✕</button></td></tr>`).join("");
    $$("#tTrades [data-suppr]").forEach(b => b.onclick = async () => { if (await demander("Supprimer ce trade du testeur ?")) { await api("/api/trade/supprimer", { id: b.dataset.suppr }); chargerStats(); } });
  }
  function courbe(v) {
    const cv = $("#courbe"); if (!cv || !v.length) return;
    const dpr = window.devicePixelRatio || 1, w = cv.clientWidth, h = 150; cv.width = w * dpr; cv.height = h * dpr;
    const c = cv.getContext("2d"); c.setTransform(dpr, 0, 0, dpr, 0, 0);
    const pts = [0, ...v], lo = Math.min(...pts), hi = Math.max(...pts), sp = hi - lo || 1;
    const x = i => 10 + i / (pts.length - 1) * (w - 20), y = p => h - 14 - (p - lo) / sp * (h - 28);
    c.fillStyle = "rgba(41,98,255,.08)"; c.beginPath(); c.moveTo(x(0), y(0)); pts.forEach((p, i) => c.lineTo(x(i), y(p))); c.lineTo(x(pts.length - 1), y(0)); c.fill();
    c.strokeStyle = "rgba(120,123,134,.5)"; c.beginPath(); c.moveTo(0, y(0)); c.lineTo(w, y(0)); c.stroke();
    c.strokeStyle = BLEU; c.lineWidth = 2; c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(x(i), y(p)) : c.moveTo(x(i), y(p))); c.stroke();
    c.fillStyle = "#787b86"; c.font = "11px sans-serif"; c.fillText("Courbe des résultats (R cumulés)", 12, 14);
  }

  // ================================================================== barre d'outils de gauche
  const outilCourant = grp => {
    const tous = grp.sections.flatMap(s => s[1]);
    if (grp.id === "curseurs") return S.curseur || "curseur";
    return S.groupeOutil[grp.id] && tous.includes(S.groupeOutil[grp.id]) ? S.groupeOutil[grp.id] : tous[0];
  };
  function construireOutils() {
    const bouton = (id, titre, attrs = "", fleche = "") => `<div class="outil-groupe">${fleche}<button class="principal" ${attrs} title="${esc(titre)}">${svg(id)}</button></div>`;
    let html = "";
    for (const grp of GROUPES) {
      const cur = outilCourant(grp), actif = grp.id === "curseurs" ? G.outil === "curseur" || G.outil === "gomme" : grp.sections.some(s => s[1].includes(G.outil));
      html += `<div class="outil-groupe" data-groupe="${grp.id}"><button class="principal ${actif ? "actif" : ""}" data-outil="${grp.id === "curseurs" ? "curseur" : cur}" data-icone="${cur}" title="${esc(OUTILS[cur][0] + ((OUTILS[cur][2] || LIGNES_DROITES.has(cur)) ? " (" + [OUTILS[cur][2], LIGNES_DROITES.has(cur) ? "Maj : ligne droite" : ""].filter(Boolean).join(" · ") + ")" : ""))}">${svg(cur)}</button><button class="fleche-groupe" data-volet="${grp.id}" title="Plus d'outils"><svg viewBox="0 0 8 12" width="7" height="10"><path d="M2 2l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>`;
    }
    html += `<div class="outil-groupe" data-groupe="icones"><button class="principal ${G.outil === "icone" ? "actif" : ""}" data-volet="icones" title="Icônes et émojis">${svg("icones")}</button><button class="fleche-groupe" data-volet="icones"><svg viewBox="0 0 8 12" width="7" height="10"><path d="M2 2l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>`;
    html += '<span class="sep-h"></span>';
    html += bouton("regle", "Règle : glisser pour mesurer", `data-outil="regle" class="principal ${G.outil === "regle" ? "actif" : ""}"`);
    html += `<div class="outil-groupe"><button class="principal ${G.outil === "zoom" ? "actif" : ""}" data-outil="zoom" title="Zoom avant : glisser sur la période à agrandir">${svg("zoom")}</button></div>`;
    if (G.zooms && G.zooms.length) html += `<div class="outil-groupe"><button class="principal" id="tDezoom" title="Zoom arrière (revenir)">${svg("dezoom")}</button></div>`;
    html += '<span class="sep-h"></span>';
    html += `<div class="outil-groupe"><button class="principal bascule ${S.aimant ? "actif" : ""}" id="tAimant" title="${S.aimant === "fort" ? "Aimant fort" : S.aimant ? "Aimant faible" : "Mode aimant"} (Ctrl en dessinant)">${svg("aimant")}</button><button class="fleche-groupe" data-volet="aimant"><svg viewBox="0 0 8 12" width="7" height="10"><path d="M2 2l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>`;
    html += `<div class="outil-groupe"><button class="principal bascule ${S.continuer ? "actif" : ""}" id="tContinuer" title="Continuer à dessiner (garder l'outil après un dessin)">${svg("continuer")}</button></div>`;
    html += `<div class="outil-groupe"><button class="principal bascule ${S.verrou ? "actif" : ""}" id="tVerrou" title="Verrouiller tous les outils de dessin">${svg("verrou")}</button></div>`;
    html += `<div class="outil-groupe"><button class="principal bascule ${S.masquer || S.masquerInd ? "actif" : ""}" id="tMasquer" title="Masquer tous les dessins">${svg("masquer")}</button><button class="fleche-groupe" data-volet="masquer"><svg viewBox="0 0 8 12" width="7" height="10"><path d="M2 2l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>`;
    html += '<span class="sep-h"></span>';
    html += `<div class="outil-groupe"><button class="principal" id="tEffacer" title="Supprimer les dessins">${svg("effacer")}</button><button class="fleche-groupe" data-volet="supprimer"><svg viewBox="0 0 8 12" width="7" height="10"><path d="M2 2l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>`;
    html += '<span class="flex"></span>';
    html += `<div class="outil-groupe"><button class="principal bascule ${S.voirFavoris ? "actif" : ""}" id="tFavoris" title="Afficher la barre des favoris">${svg("favoris")}</button></div>`;
    const barre = $("#outils"), defil = barre.scrollTop;          // petit écran : la barre défile, on garde la position
    barre.innerHTML = html; barre.scrollTop = defil;
    brancherBulleOutils();
    barreFavoris();
  }
  // Bulle d'aide sombre à droite de la barre d'outils : nom de l'outil et raccourci
  function brancherBulleOutils() {
    const barre = $("#outils"); if (!barre || barre.dataset.bulle) return; barre.dataset.bulle = "1";
    const bulle = document.createElement("div"); bulle.className = "bulle-outil"; document.body.appendChild(bulle);
    let cible = null;
    const cacher = () => { bulle.classList.remove("vue"); cible = null; };
    barre.addEventListener("mouseover", e => {
      const el = e.target.closest("button[title], button[data-bulle]"); if (!el || !barre.contains(el)) return;
      if (el.title) { el.dataset.bulle = el.title; el.removeAttribute("title"); }
      if (el === cible) return; cible = el;
      const t = el.dataset.bulle || ""; const m = t.match(/^(.*?)\s*\(([^)]*)\)\s*$/);
      bulle.innerHTML = m ? `${esc(m[1])}<span class="rac">${esc(m[2])}</span>` : esc(t);
      const r = (el.closest(".outil-groupe") || el).getBoundingClientRect();
      bulle.style.left = (barre.getBoundingClientRect().right + 6) + "px"; bulle.style.top = (r.top + r.height / 2) + "px";
      bulle.classList.add("vue");
    });
    barre.addEventListener("mouseleave", cacher); barre.addEventListener("mousedown", cacher); barre.addEventListener("scroll", cacher);
  }
  let volet = null;
  function ouvrirVolet(nom, bouton) {
    fermerVolet();
    document.querySelector(".bulle-outil")?.classList.remove("vue");
    const r = bouton.getBoundingClientRect();
    volet = document.createElement("div"); volet.className = "volet ouvert";
    const ligne = (id, actif) => `<button data-choix="${id}" class="${actif ? "actif" : ""}">${svg(id)}<span class="nom">${esc(OUTILS[id][0])}</span><span class="raccourci">${esc(OUTILS[id][2] || "")}</span>
      <span class="etoile ${S.favoris.includes(id) ? "pleine" : ""}" data-fav="${id}" title="Ajouter aux favoris">${S.favoris.includes(id) ? "★" : "☆"}</span></button>`;
    if (nom === "icones") {
      const onglet = S.ongletIcones || "Emojis";
      const cats = onglet === "Emojis" ? Object.keys(ICONES).filter(k => k !== "Icônes") : ["Icônes"];
      volet.classList.add("icones");
      volet.innerHTML = (S.iconesRecentes.length ? `<div class="titre-pop">Récemment utilisé</div><div class="grille-icones">${S.iconesRecentes.map(x => `<button data-icone="${esc(x)}">${esc(x)}</button>`).join("")}</div>` : "") +
        cats.map(k => `<div class="titre-pop">${esc(k)}</div><div class="grille-icones">${ICONES[k].map(x => `<button data-icone="${esc(x)}">${esc(x)}</button>`).join("")}</div>`).join("") +
        `<div class="onglets-icones">${["Emojis", "Icônes"].map(o => `<button data-onglet="${o}" class="${o === onglet ? "actif" : ""}">${o}</button>`).join("")}</div>`;
    } else if (nom === "aimant") {
      volet.innerHTML = [["faible", "Aimant faible"], ["fort", "Aimant fort"]].map(([k, t]) => `<button data-aimant="${k}" class="${S.aimant === k ? "actif" : ""}">${svg("aimant")}<span class="nom">${t}</span></button>`).join("");
    } else if (nom === "masquer") {
      volet.innerHTML = [["dessins", "Masquer tous les dessins", S.masquer], ["indicateurs", "Masquer tous les indicateurs", S.masquerInd], ["tout", "Masquer dessins et indicateurs", S.masquer && S.masquerInd]]
        .map(([k, t, a]) => `<button data-masquer="${k}" class="${a ? "actif" : ""}">${svg("masquer")}<span class="nom">${t}</span></button>`).join("");
    } else if (nom === "supprimer") {
      volet.innerHTML = [["dessins", "Supprimer les " + G.dessins.length + " dessin(s)"], ["indicateurs", "Supprimer les " + S.inds.length + " indicateur(s)"], ["tout", "Supprimer dessins et indicateurs"]]
        .map(([k, t]) => `<button data-supprimer="${k}">${svg("effacer")}<span class="nom">${t}</span></button>`).join("");
    } else {
      const grp = GROUPES.find(g => g.id === nom);
      volet.innerHTML = grp.sections.map(([titre, ids]) => (titre ? `<div class="titre-pop">${esc(titre)}</div>` : '<div class="trait-pop"></div>') +
        ids.map(id => ligne(id, G.outil === id || (grp.id === "curseurs" && id === (S.curseur || "curseur") && G.outil === "curseur"))).join("")).join("");
    }
    document.body.appendChild(volet);
    const h = volet.offsetHeight;
    volet.style.left = (r.right + 4) + "px"; volet.style.top = Math.max(8, Math.min(r.top - 6, window.innerHeight - h - 8)) + "px";
    volet.onclick = async e => {
      const fav = e.target.closest("[data-fav]");
      if (fav) { e.stopPropagation(); const id = fav.dataset.fav, ajout = !S.favoris.includes(id); S.favoris = ajout ? [...S.favoris, id] : S.favoris.filter(x => x !== id);
        toast(ajout ? "★ « " + OUTILS[id][0] + " » ajouté aux favoris (barre en haut du graphique)" : "« " + OUTILS[id][0] + " » retiré des favoris"); if (!S.voirFavoris && S.favoris.length) S.voirFavoris = true; sauverPrefs(); construireOutils(); ouvrirVolet(nom, $(`#outils [data-groupe="${nom}"]`) || bouton); return; }
      const ic = e.target.closest("[data-icone]"); if (ic && volet.classList.contains("icones")) { G.iconeChoisie = ic.dataset.icone; S.iconesRecentes = [ic.dataset.icone, ...S.iconesRecentes.filter(x => x !== ic.dataset.icone)].slice(0, 10); sauverPrefs(); choisirOutil("icone"); fermerVolet(); return; }
      const og = e.target.closest("[data-onglet]"); if (og) { S.ongletIcones = og.dataset.onglet; sauverPrefs(); ouvrirVolet(nom, bouton); return; }
      const am = e.target.closest("[data-aimant]"); if (am) { S.aimant = S.aimant === am.dataset.aimant ? false : am.dataset.aimant; sauverPrefs(); construireOutils(); fermerVolet(); return; }
      const ma = e.target.closest("[data-masquer]"); if (ma) { const k = ma.dataset.masquer;
        if (k === "dessins") S.masquer = !S.masquer; else if (k === "indicateurs") S.masquerInd = !S.masquerInd; else { const v = !(S.masquer && S.masquerInd); S.masquer = v; S.masquerInd = v; }
        G.sel = -1; barreDessin(); sauverPrefs(); construireOutils(); donnees(); fermerVolet(); return; }
      const su = e.target.closest("[data-supprimer]"); if (su) { const k = su.dataset.supprimer;
        if (!await demander(k === "dessins" ? "Supprimer tous les dessins de " + S.actif + " ?" : k === "indicateurs" ? "Retirer tous les indicateurs ?" : "Supprimer tous les dessins et retirer tous les indicateurs ?", { ok: k === "indicateurs" ? "Retirer" : "Supprimer" })) return;
        if (k !== "indicateurs") { memoriser(); G.dessins = []; G.sel = -1; barreDessin(); sauverDessins(); }
        if (k !== "dessins") { S.inds = []; sauverPrefs(); donnees(); }
        sale = true; fermerVolet(); return; }
      const b = e.target.closest("[data-choix]"); if (!b) return;
      const id = b.dataset.choix;
      if (nom === "curseurs") { if (id !== "gomme") { S.curseur = id; sauverPrefs(); appliquerCurseur(); choisirOutil("curseur"); } else choisirOutil("gomme"); }
      else { S.groupeOutil[nom] = id; sauverPrefs(); choisirOutil(id); }
      construireOutils(); fermerVolet();
    };
  }
  function fermerVolet() { if (volet) { volet.remove(); volet = null; } }
  // clic droit sur le graphique : actions sur le dessin touché (ou sur tous les dessins)
  function menuContextuel(e) {
    const p = pos(e), g = geo();
    if (p.x > g.W && p.y <= g.H) { menuEchelle(e); return; }
    if (p.x > g.W || p.y > g.H) return;
    e.preventDefault(); e.stopPropagation(); fermerVolet();
    let k = -1; if (!S.masquer) for (let i = G.dessins.length - 1; i >= 0; i--) if (visible(G.dessins[i]) && toucheDessin(G.dessins[i], p, g)) { k = i; break; }
    volet = document.createElement("div"); volet.className = "volet ouvert contexte";
    if (k >= 0) {
      G.sel = k; barreDessin(); sale = true; const d = G.dessins[k];
      volet.innerHTML = `<div class="titre-pop">${esc(OUTILS[d.type] ? OUTILS[d.type][0] : d.type)}</div>
        <button data-c-act="suppr">${svg("effacer")}<span class="nom">Supprimer</span><span class="raccourci">Suppr</span></button>
        <button data-c-act="clone">${svg("rect")}<span class="nom">Dupliquer</span></button>
        <button data-c-act="lock">${svg("verrou")}<span class="nom">${d.lock ? "Déverrouiller" : "Verrouiller"}</span></button>
        <button data-c-act="style">${svg("formes")}<span class="nom">Paramètres…</span></button>
        ${estPosition(d) ? `<button data-c-act="ordre">${svg(d.type)}<span class="nom">Passer cet ordre (simulé)</span></button>` : ""}
        <button data-c-act="cacher">${svg("masquer")}<span class="nom">Masquer ce dessin</span></button>
        ${["texte", "note", "noteprix", "epingle", "tableau", "callout", "commentaire", "etiquette", "panneau", "flechehaut", "flechebas"].includes(d.type) ? `<button data-c-act="texte">${svg("texte")}<span class="nom">Modifier le texte</span></button>` : ""}
        <div class="couleurs-contexte">${COULEURS.map(c => `<button data-c-coul="${c}" style="background:${c}" title="Couleur"></button>`).join("")}</div>`;
    } else {
      volet.innerHTML = `<button data-c-act="tout">${svg("effacer")}<span class="nom">Supprimer tous les dessins de ${S.actif}</span></button>
        <button data-c-act="masquer">${svg("masquer")}<span class="nom">${S.masquer ? "Afficher" : "Masquer"} les dessins</span></button>
        <button data-c-act="echelle">${svg("zoom")}<span class="nom">Réinitialiser l'affichage</span></button>
        <button data-c-act="reglages"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1" stroke="currentColor" stroke-width="1.5"/></svg><span class="nom">Réglages…</span></button>`;
    }
    document.body.appendChild(volet);
    volet.style.left = Math.min(e.clientX, window.innerWidth - volet.offsetWidth - 8) + "px";
    volet.style.top = Math.min(e.clientY, window.innerHeight - volet.offsetHeight - 8) + "px";
    volet.onclick = async ev => {
      const b = ev.target.closest("button"); if (!b) return;
      const a = b.dataset.cAct;
      if (b.dataset.cCoul) modifierSel(x => { x.c = b.dataset.cCoul; });
      else if (a === "suppr") { if (supprimerSel()) toast("Dessin supprimé (Ctrl+Z pour annuler)"); }
      else if (a === "clone") { const d = G.dessins[G.sel]; memoriser(); const cl = JSON.parse(JSON.stringify(d)); cl.id = Math.random().toString(36).slice(2, 10); cl.pts = cl.pts.map(q => ({ t: tDe(idxDe(q.t) + 5), p: q.p })); G.dessins.push(cl); G.sel = G.dessins.length - 1; barreDessin(); sauverDessins(); }
      else if (a === "lock") modifierSel(x => { x.lock = !x.lock; });
      else if (a === "style") { fermerVolet(); setTimeout(() => ouvrirStyleDessin(), 0); return; }
      else if (a === "ordre") placerDepuisDessin(G.dessins[G.sel]);
      else if (a === "cacher") { modifierSel(x => { x.cache = true; }); G.sel = -1; barreDessin(); toast("Dessin masqué : réaffichez-le depuis l'arborescence des objets (barre de droite)."); }
      else if (a === "texte") { fermerVolet(); setTimeout(editerSel, 0); return; }
      else if (a === "tout") { if (G.dessins.length && await demander("Supprimer tous les dessins de " + S.actif + " ?")) { memoriser(); G.dessins = []; G.sel = -1; barreDessin(); sauverDessins(); } }
      else if (a === "masquer") { S.masquer = !S.masquer; sauverPrefs(); construireOutils(); }
      else if (a === "reglages") ouvrirReglages();
      else if (a === "echelle") { chart.timeScale().resetTimeScale(); chart.priceScale("right").applyOptions({ autoScale: true }); }
      sale = true; fermerVolet();
    };
  }
  function majOutils() {
    if ($("#outils").children.length) construireOutils();
    $("#bAlerte").classList.toggle("actif", G.outil === "alerte");
  }
  function appliquerCurseur() {
    const c = S.curseur || "curseur";
    chart.applyOptions({ crosshair: optionsCurseur() });
    zone.style.cursor = c === "flechec" || c === "demo" ? "default" : "";
  }
  function barreFavoris() {
    if (JSON.stringify(S.favoris) === JSON.stringify(["trend", "hline", "hray", "vline", "rect", "fibo", "long", "short", "texte"])) {   // ancienne liste par défaut -> celle de TradingView
      S.favoris = ["trend", "rect", "chemin", "courbe", "callout", "etiquette", "hray", "vline", "xabcd", "texte", "long", "polyligne", "fibo", "hline", "short"]; sauverPrefs();
    }
    let el = $("#barreFav");
    if (!el) { el = document.createElement("div"); el.id = "barreFav"; el.className = "barre-fav"; zone.appendChild(el); }
    el.style.display = S.voirFavoris && S.favoris.length ? "flex" : "none";
    if (S.favPos) { el.style.left = S.favPos.x + "px"; el.style.top = S.favPos.y + "px"; el.style.transform = "none"; }
    el.innerHTML = `<span class="poignee" title="Déplacer"><svg viewBox="0 0 10 18" width="10" height="18" fill="currentColor"><circle cx="2.5" cy="3" r="1.3"/><circle cx="7.5" cy="3" r="1.3"/><circle cx="2.5" cy="9" r="1.3"/><circle cx="7.5" cy="9" r="1.3"/><circle cx="2.5" cy="15" r="1.3"/><circle cx="7.5" cy="15" r="1.3"/></svg></span>` + S.favoris.filter(id => OUTILS[id]).map(id => `<button data-outil="${id}" class="${G.outil === id ? "actif" : ""}" title="${esc(OUTILS[id][0])}">${svg(id)}</button>`).join("");
    el.onclick = e => { const b = e.target.closest("[data-outil]"); if (b) { choisirOutil(G.outil === b.dataset.outil ? "curseur" : b.dataset.outil); } };
    garderFavDansGraphique();
    el.querySelector(".poignee").onmousedown = e => {
      e.preventDefault(); e.stopPropagation(); const r0 = el.getBoundingClientRect(), z = zone.getBoundingClientRect(), dx = e.clientX - r0.left, dy = e.clientY - r0.top;
      const mv = ev => { S.favPos = { x: Math.max(0, ev.clientX - z.left - dx), y: Math.max(0, ev.clientY - z.top - dy) }; el.style.left = S.favPos.x + "px"; el.style.top = S.favPos.y + "px"; el.style.transform = "none"; };
      const up = () => { window.removeEventListener("mousemove", mv); window.removeEventListener("mouseup", up); sauverPrefs(); };
      window.addEventListener("mousemove", mv); window.addEventListener("mouseup", up);
    };
  }
  function garderFavDansGraphique() {               // la barre des favoris reste toujours entièrement visible (fenêtre étroite, plein écran…)
    const el = $("#barreFav"); if (!el || el.style.display === "none" || !S.favPos) return;
    const W = zone.clientWidth, H = zone.clientHeight, w = el.offsetWidth, h = el.offsetHeight;
    const x = Math.max(0, Math.min(S.favPos.x, W - w - 4)), y = Math.max(0, Math.min(S.favPos.y, H - h - 4));
    el.style.left = x + "px"; el.style.top = y + "px"; el.style.transform = "none";
  }
  window.addEventListener("resize", () => setTimeout(garderFavDansGraphique, 50));
  function choisirImage() {
    const i = document.createElement("input"); i.type = "file"; i.accept = "image/*";
    i.onchange = () => {
      const f = i.files[0]; if (!f) { finOutil(); return; }
      const lec = new FileReader();
      lec.onload = () => { const im = new Image(); im.onload = () => {
        const k = Math.min(1, 700 / Math.max(im.width, im.height)), cv = document.createElement("canvas"); cv.width = Math.round(im.width * k); cv.height = Math.round(im.height * k);
        cv.getContext("2d").drawImage(im, 0, 0, cv.width, cv.height); G.imageEnAttente = cv.toDataURL("image/jpeg", 0.85);
        toast("Image prête : tracez maintenant son cadre sur le graphique."); }; im.src = lec.result; };
      lec.readAsDataURL(f);
    };
    i.click();
  }

  // ================================================================== boutons et clavier
  // barre des unités : les favorites (+ l'unité affichée), puis ▾ pour toutes les unités, comme sur TradingView
  function majUnites() {
    const liste = UNITES.filter(u => S.unitesFav.includes(u)).concat(S.unitesFav.includes(S.unite) ? [] : [S.unite]).sort(ordreU);
    $("#unites").innerHTML = liste.map(u => `<button data-u="${u}" class="${u === S.unite ? "actif" : ""}" title="${nomLongU(u)}">${LIB_UNITE[u]}</button>`).join("") +
      `<button id="uMenu" class="u-menu" title="Toutes les unités de temps (ou tapez un nombre au clavier : 5, 45, 2h, 15s, 3M…)">▾</button>`;
  }
  function menuUnites(e) {
    e && e.stopPropagation(); fermerVolet();
    const groupes = [["S", "Secondes"], ["M", "Minutes"], ["H", "Heures"], ["D", "Jours"], ["W", "Semaines"], ["N", "Mois"]];
    const ligne = u => `<button data-choix-u="${u}" class="${u === S.unite ? "actif" : ""}"><span class="nom">${nomLongU(u)}</span>
      ${S.unitesPerso.includes(u) ? `<span class="suppr-u" data-suppr-u="${u}" title="Retirer cette unité personnalisée">✕</span>` : ""}
      <span class="etoile ${S.unitesFav.includes(u) ? "pleine" : ""}" data-fav-u="${u}" title="${S.unitesFav.includes(u) ? "Retirer de la barre" : "Ajouter à la barre"}">${S.unitesFav.includes(u) ? "★" : "☆"}</span></button>`;
    volet = document.createElement("div"); volet.className = "volet ouvert menu-unites";
    volet.innerHTML = groupes.map(([t, nom]) => { const us = UNITES.filter(u => analyserU(u)[0] === t); return us.length ? `<div class="titre-pop">${nom}</div>` + us.map(ligne).join("") : ""; }).join("") +
      `<div class="titre-pop">Unité personnalisée</div><div class="u-ajout"><input id="uNb" type="number" min="1" max="1439" value="2"><select id="uType">${groupes.map(([t, nom]) => `<option value="${t}" ${t === "M" ? "selected" : ""}>${nom.toLowerCase()}</option>`).join("")}</select><button id="uAjout">Ajouter</button></div>`;
    document.body.appendChild(volet);
    const r = $("#uMenu").getBoundingClientRect();
    volet.style.left = Math.max(8, Math.min(r.left - 120, window.innerWidth - volet.offsetWidth - 8)) + "px"; volet.style.top = (r.bottom + 4) + "px";
    volet.querySelector("#uNb").onkeydown = ev => { ev.stopPropagation(); if (ev.key === "Enter") volet.querySelector("#uAjout").click(); };
    volet.onclick = async ev => {
      const fav = ev.target.closest("[data-fav-u]"), sup = ev.target.closest("[data-suppr-u]"), ch = ev.target.closest("[data-choix-u]");
      if (fav) { const u = fav.dataset.favU; S.unitesFav = S.unitesFav.includes(u) ? S.unitesFav.filter(x => x !== u) : S.unitesFav.concat(u); sauverPrefs(); majUnites(); menuUnites(); return; }
      if (sup) { const u = sup.dataset.supprU; S.unitesPerso = S.unitesPerso.filter(x => x !== u); S.unitesFav = S.unitesFav.filter(x => x !== u); const i = UNITES.indexOf(u); if (i >= 0 && !UNITES_TV.includes(u)) UNITES.splice(i, 1); sauverPrefs(); majUnites(); menuUnites(); return; }
      if (ev.target.closest("#uAjout")) {
        const t = volet.querySelector("#uType").value, k = parseInt(volet.querySelector("#uNb").value, 10), [mi, ma] = LIMITES_U[t];
        if (!(k >= mi && k <= ma)) { toast(`Choisissez un nombre de ${mi} à ${ma} ${NOMS_U[t][1]}.`, false); return; }
        const u = normaliserU(t, k);
        if (!UNITES.includes(u)) { UNITES.push(u); UNITES.sort(ordreU); S.unitesPerso.push(u); }
        if (!S.unitesFav.includes(u)) S.unitesFav.push(u);
        sauverPrefs(); fermerVolet(); await changerUnite(u); majUnites(); toast(`Unité ${nomLongU(u)} ajoutée à la barre.`); return;
      }
      if (ch) { fermerVolet(); await changerUnite(ch.dataset.choixU); majUnites(); }
    };
  }
  // saisie d'une unité au clavier, comme sur TradingView : 5 + Entrée = 5 minutes ; 2h, 15s, 3j, 2w, 3M (mois)
  function saisieUnite(e) {
    const bloc = $("#saisieUnite") || (() => { const d = document.createElement("div"); d.id = "saisieUnite"; d.className = "saisie-unite"; zone.appendChild(d); return d; })();
    const finir = () => { G.saisieU = null; bloc.style.display = "none"; clearTimeout(G.saisieUT); };
    if (e.key === "Escape") { finir(); return true; }
    if (e.key === "Backspace") { G.saisieU = G.saisieU.slice(0, -1); if (!G.saisieU) { finir(); return true; } }
    else if (e.key === "Enter") {
      const m = /^(\d{1,4})([smhjdwM]?)$/.exec(G.saisieU); finir();
      if (!m) return true;
      const t = { s: "S", m: "M", "": "M", h: "H", j: "D", d: "D", w: "W", M: "N" }[m[2]], k = +m[1];
      if (!(k >= LIMITES_U[t][0] && k <= LIMITES_U[t][1])) { toast("Unité impossible : " + k + " " + NOMS_U[t][1] + ".", false); return true; }
      changerUnite(normaliserU(t, k)).then(majUnites); return true;
    }
    else if (/^[0-9]$/.test(e.key) || (/^[smhjdwM]$/.test(e.key) && /^\d+$/.test(G.saisieU))) G.saisieU += e.key;
    else return true;
    const m = /^(\d{1,4})([smhjdwM]?)$/.exec(G.saisieU);
    const t = m ? { s: "S", m: "M", "": "M", h: "H", j: "D", d: "D", w: "W", M: "N" }[m[2]] : null;
    bloc.innerHTML = `<b>${esc(G.saisieU)}</b><span>${m ? nomLongU(normaliserU(t, +m[1])) : "…"} · Entrée pour valider</span>`; bloc.style.display = "flex";
    clearTimeout(G.saisieUT); G.saisieUT = setTimeout(finir, 4000);
    return true;
  }

  // ================================================================== coin de l'échelle des prix (A, L, réglages) et horloge
  function majCoin() {
    const el = $("#coinEchelle"); if (!el || !chart) return;
    const ts = chart.timeScale(), l = Math.max(0, zone.clientWidth - ts.width()), h = ts.height();
    el.style.width = l + "px"; el.style.height = h + "px"; el.style.display = l > 30 && h > 10 ? "" : "none";
    let auto = true; try { auto = chart.priceScale("right").options().autoScale !== false; } catch (e) { /* rien */ }
    $("#cAuto").classList.toggle("actif", auto); $("#cLog").classList.toggle("actif", +S.echelle === 1);
  }
  const NOMS_FUSEAU = { local: "Heure de ce PC", utc: "UTC", ny: "New York", paris: "Paris" };
  function libelleFuseau() {
    if (S.fuseau === "ny") return "New York"; if (S.fuseau === "paris") return "Paris";
    const h = decalage(Date.now() / 1000) / 3600;
    return h ? "UTC" + (h > 0 ? "+" : "−") + Math.abs(h) : "UTC";
  }
  function majHorloge() {
    const t = Date.now() / 1000, d = new Date((t + decalage(t)) * 1000);
    $("#horloge").textContent = d.toISOString().slice(11, 19) + " " + libelleFuseau();
  }
  function brancherCoin() {
    $("#cAuto").onclick = () => {
      const auto = chart.priceScale("right").options().autoScale !== false;
      chart.priceScale("right").applyOptions({ autoScale: !auto }); majCoin(); sale = true;
    };
    $("#cLog").onclick = () => { S.echelle = +S.echelle === 1 ? 0 : 1; sauverPrefs(); chart.applyOptions(optionsTheme()); chart.priceScale("right").applyOptions({ autoScale: true }); majCoin(); sale = true; };
    $("#cReg").onclick = () => ouvrirReglages("echelles");
    $("#horloge").onclick = e => {
      e.stopPropagation(); fermerVolet();
      volet = document.createElement("div"); volet.className = "volet ouvert";
      volet.innerHTML = `<div class="titre-pop">Fuseau horaire</div>` + Object.entries(NOMS_FUSEAU).map(([k, n]) => `<button data-fuseau="${k}" class="${S.fuseau === k ? "actif" : ""}"><span class="nom">${n}</span>${S.fuseau === k ? '<span class="raccourci">✓</span>' : ""}</button>`).join("");
      document.body.appendChild(volet);
      const r = $("#horloge").getBoundingClientRect();
      volet.style.left = Math.min(r.left, window.innerWidth - volet.offsetWidth - 8) + "px"; volet.style.top = Math.max(8, r.top - volet.offsetHeight - 6) + "px";
      volet.onclick = ev => { const b = ev.target.closest("[data-fuseau]"); if (!b) return; S.fuseau = b.dataset.fuseau; sauverPrefs(); creerSerie(); donnees(); majHorloge(); fermerVolet(); };
    };
    majHorloge(); setInterval(majHorloge, 1000); setInterval(majCoin, 400);
  }

  // ================================================================== dessins : visibilité, paramètres, arborescence des objets, fenêtre de données
  const visible = d => !d.cache && (!d.vis || d.vis.includes(S.unite));
  const nomDessin = d => (d.nom || (OUTILS[d.type] ? OUTILS[d.type][0] : d.type)) + (d.txt ? " · " + String(d.txt).split("\n")[0].slice(0, 24) : "");
  // panneau de droite : liste de suivi / arborescence des objets / fenêtre de données
  function montrerVue(vue) {
    const meme = S.listeVisible && (S.vueDroite || "liste") === vue;
    S.listeVisible = !meme; S.vueDroite = vue; sauverPrefs(); appliquerVue();
  }
  function appliquerVue() {
    const v = S.vueDroite || "liste";
    $("#droite").classList.toggle("cache", !S.listeVisible); $("#droite").dataset.vue = v;
    $("#bListe").classList.toggle("actif", S.listeVisible && v === "liste");
    $("#bObjets").classList.toggle("actif", S.listeVisible && v === "objets");
    $("#bDonnees").classList.toggle("actif", S.listeVisible && v === "donnees");
    majObjets(); majDonnees();
  }
  function majObjets() {
    if (!S.listeVisible || S.vueDroite !== "objets") return;
    const btn = (act, k, titre, txt, actif) => `<button data-o-act="${act}" data-k="${k}" title="${titre}" class="${actif ? "actif" : ""}">${txt}</button>`;
    const lignes = G.dessins.map((d, k) => [d, k]).reverse().map(([d, k]) => `<div class="obj-ligne ${k === G.sel ? "sel" : ""} ${visible(d) ? "" : "masque"}" data-k="${k}">
        <span class="obj-ico">${svg(d.type)}</span><span class="obj-nom">${esc(nomDessin(d))}${d.vis ? ` <span class="discret">(${d.vis.length} unité${d.vis.length > 1 ? "s" : ""})</span>` : ""}</span>
        ${btn("style", k, "Paramètres", "⚙")}${btn("lock", k, d.lock ? "Déverrouiller" : "Verrouiller", d.lock ? "🔒" : "🔓", d.lock)}${btn("voir", k, d.cache ? "Afficher" : "Masquer", d.cache ? "◌" : "👁")}${btn("suppr", k, "Supprimer", "✕")}</div>`).join("");
    const inds = S.inds.map(ind => `<div class="obj-ligne ${ind.cache ? "masque" : ""}" data-uid="${ind.uid}"><span class="obj-ico">∿</span><span class="obj-nom">${esc(INDS[ind.id].nom || INDS[ind.id].court)}</span>
        <button data-i-act="voir" title="${ind.cache ? "Afficher" : "Masquer"}">${ind.cache ? "◌" : "👁"}</button><button data-i-act="suppr" title="Retirer">✕</button></div>`).join("");
    $("#vueObjets").innerHTML = `<div class="tete-liste"><b>Arborescence des objets</b></div>
      <div class="obj-titre">${S.actif} · dessins (${G.dessins.length})</div>${lignes || '<div class="discret obj-vide">Aucun dessin sur cet actif.</div>'}
      <div class="obj-titre">Indicateurs (${S.inds.length})</div>${inds || '<div class="discret obj-vide">Aucun indicateur.</div>'}
      ${G.dessins.length ? `<div class="obj-pied"><button data-o-act="toutvoir">${G.dessins.some(d => d.cache) ? "Tout afficher" : "Tout masquer"}</button><button data-o-act="toutsuppr">Tout supprimer</button></div>` : ""}`;
  }
  async function actionObjets(e) {
    const b = e.target.closest("[data-o-act], [data-i-act]"), l = e.target.closest(".obj-ligne");
    if (b && b.dataset.iAct) {
      const ind = S.inds.find(x => x.uid === l.dataset.uid); if (!ind) return;
      if (b.dataset.iAct === "voir") ind.cache = !ind.cache; else S.inds = S.inds.filter(x => x !== ind);
      sauverPrefs(); donnees(); majObjets(); return;
    }
    if (b) {
      const a = b.dataset.oAct, k = +b.dataset.k, d = G.dessins[k];
      if (a === "toutvoir") { memoriser(); const montrer = G.dessins.some(x => x.cache); G.dessins.forEach(x => { x.cache = !montrer; }); }
      else if (a === "toutsuppr") { if (!await demander("Supprimer tous les dessins de " + S.actif + " ?")) return; memoriser(); G.dessins = []; G.sel = -1; }
      else if (!d) return;
      else if (a === "style") { G.sel = k; barreDessin(); ouvrirStyleDessin(); return; }
      else if (a === "lock") { memoriser(); d.lock = !d.lock; }
      else if (a === "voir") { memoriser(); d.cache = !d.cache; if (d.cache && G.sel === k) G.sel = -1; }
      else if (a === "suppr") { memoriser(); G.dessins.splice(k, 1); G.sel = -1; }
      barreDessin(); sauverDessins(true); sale = true; majObjets(); return;
    }
    if (l && l.dataset.k != null) {         // clic sur la ligne : sélectionner et montrer le dessin
      const k = +l.dataset.k, d = G.dessins[k]; if (!d) return;
      if (!visible(d)) { toast("Ce dessin est masqué (ou caché sur cette unité de temps)."); }
      G.sel = k; barreDessin(); sale = true; majObjets();
      const i = idxDe(d.pts[0].t), r = chart.timeScale().getVisibleLogicalRange();
      if (r && (i < r.from || i > r.to)) { const w = r.to - r.from; chart.timeScale().setVisibleLogicalRange({ from: i - w / 2, to: i + w / 2 }); }
    }
  }
  function majDonnees() {
    if (!S.listeVisible || S.vueDroite !== "donnees") return;
    const n = nVis(), i = G.survol != null ? G.survol : n - 1, b = G.bars[i];
    if (!b) { $("#vueDonnees").innerHTML = ""; return; }
    const v = b[4] - b[1], c = v >= 0 ? VERT : ROUGE, ligne = (k, val, col) => `<div class="don-ligne"><span>${k}</span><b style="color:${col || "inherit"}">${val}</b></div>`;
    let h = `<div class="tete-liste"><b>Fenêtre de données</b></div><div class="don-bloc"><div class="don-titre">${esc(S.actif)} · ${LIB_UNITE[S.unite]}</div>
      ${ligne("Date", fdate(b[0]))}${ligne("Ouverture", fp(b[1]), c)}${ligne("Plus haut", fp(b[2]), c)}${ligne("Plus bas", fp(b[3]), c)}${ligne("Clôture", fp(b[4]), c)}
      ${ligne("Variation", (v >= 0 ? "+" : "") + fp(v) + " (" + (b[1] ? (v / b[1] * 100).toFixed(2) : "0.00") + " %)", c)}${ligne("Amplitude", fp(b[2] - b[3]))}${b[5] ? ligne("Volume", Math.round(b[5]).toLocaleString(LOC)) : ""}</div>`;
    for (const ind of S.inds) {
      const vals = G.valeursInd && G.valeursInd[ind.uid]; if (!vals || ind.cache) continue;
      h += `<div class="don-bloc"><div class="don-titre">${esc(INDS[ind.id].court)}</div>` + vals.map(o => ligne(esc(o.nom), o.data[i] != null ? (ind.id === "vol" ? Math.round(o.data[i]).toLocaleString(LOC) : fp(o.data[i], Math.abs(o.data[i]) > 50 ? 2 : chiffres())) : "—", o.couleur)).join("") + `</div>`;
    }
    $("#vueDonnees").innerHTML = h;
  }
  // fenêtre de paramètres d'un dessin (double-clic, ⚙ de la barre, clic droit)
  const datePourChamp = t => new Date(lt(t) * 1000).toISOString().slice(0, 16);
  const tempsDuChamp = v => { const aff = Date.parse(v + ":00Z") / 1000; return aff - decalage(aff); };
  function ouvrirStyleDessin(onglet) {
    const d = G.dessins[G.sel]; if (!d) return;
    G.ddAvant = JSON.stringify(d); G.ddStyleAvant = JSON.stringify((S.dernierStyle || {})[d.type] || null);
    G.ddOnglet = onglet || (FIBO_REGLABLES.has(d.type) ? "style" : G.ddOnglet) || "style";
    titreStyleDessin(d);
    rendreStyleDessin(); $("#dlgDessin").classList.add("ouvert");
  }
  function titreStyleDessin(d) {                    // « Ligne de tendance ✎ » : un clic sur le crayon pour renommer le dessin
    const t = $("#ddTitre"), nom = d.nom || (OUTILS[d.type] ? OUTILS[d.type][0] : d.type);
    t.innerHTML = `<span class="dd-nom">${esc(nom)}</span><button type="button" class="dd-renommer" title="Renommer ce dessin">✎</button>`;
    t.querySelector(".dd-renommer").onclick = () => {
      t.innerHTML = `<input class="dd-nom-champ" maxlength="60" value="${esc(nom)}">`;
      const ch = t.querySelector("input"); ch.focus(); ch.select();
      const valider = () => { const v = ch.value.trim(); if (v && v !== (OUTILS[d.type] || [d.type])[0]) d.nom = v.slice(0, 60); else delete d.nom; sale = true; titreStyleDessin(d); };
      ch.onkeydown = ev => { ev.stopPropagation(); if (ev.key === "Enter") valider(); if (ev.key === "Escape") titreStyleDessin(d); };
      ch.onblur = valider;
    };
  }
  function rendreStyleDessin() {
    const d = G.dessins[G.sel]; if (!d) return;
    const onglets = [["style", "Style"], ...(TYPES_TEXTE.includes(d.type) ? [["texte", "Texte"]] : LIGNES_TV.has(d.type) || d.type === "rect" ? [["texteL", "Texte"]] : []), ["coord", "Coordonnées"], ["vis", "Visibilité"]];
    if (!onglets.some(o => o[0] === G.ddOnglet)) G.ddOnglet = "style";
    $("#ddOnglets").innerHTML = onglets.map(([k, t]) => `<button data-dd-onglet="${k}" class="${k === G.ddOnglet ? "actif" : ""}"><span>${t}</span></button>`).join("");
    const col = d.c || (d.type === "alerte" ? S.reg.aCouleur : BLEU);
    let h = "";
    if (G.ddOnglet === "style" && estPosition(d)) h = `<div class="reg-titre">Couleurs</div>
      <div class="reg-ligne"><span>Zone d'objectif (gain)</span><span class="flex"></span><input type="color" data-dd="c2" value="${esc(d.c2 || VERT)}"></div>
      <div class="reg-ligne"><span>Zone de stop (perte)</span><span class="flex"></span><input type="color" data-dd="c3" value="${esc(d.c3 || ROUGE)}"></div>
      <div class="reg-ligne"><span>Ligne d'entrée</span><span class="flex"></span><input type="color" data-dd="c" value="${esc(/^#[0-9a-f]{6}$/i.test(d.c || "") ? d.c : "#787b86")}"></div>
      <div class="reg-ligne"><span>Opacité des zones</span><span class="flex"></span><select data-dd="op">${[0.1, 0.15, 0.2, 0.3, 0.4, 0.5].map(v => `<option value="${v}" ${(d.op ?? 0.2) == v ? "selected" : ""}>${Math.round(v * 100)} %</option>`).join("")}</select></div>
      <div class="reg-ligne"><span>Épaisseur de la ligne d'entrée</span><span class="flex"></span><select data-dd="w">${[1, 1.6, 2, 3].map(v => `<option value="${v}" ${(d.w || 1.6) == v ? "selected" : ""}>${v === 1.6 ? "Normale" : v + " px"}</option>`).join("")}</select></div>
      <div class="reg-titre">Calcul</div>
      <div class="reg-ligne"><span>Taille du compte</span><span class="flex"></span><input type="number" min="1" step="any" data-dd="compte" value="${d.compte ?? 10000}"></div>
      <div class="reg-ligne"><span>Risque (% du compte)</span><span class="flex"></span><input type="number" min="0.01" max="100" step="0.05" data-dd="risque" value="${d.risque ?? 1}"></div>
      <label class="reg-ligne"><input type="checkbox" data-dd="etiq" ${d.etiq !== false ? "checked" : ""}><span>Afficher les étiquettes (objectif, stop, ratio, quantité)</span></label>
      <div class="reg-titre">Comportement</div>
      <label class="reg-ligne"><input type="checkbox" data-dd="lock" ${d.lock ? "checked" : ""}><span>Verrouiller (ne peut plus être déplacé)</span></label>
      <label class="reg-ligne"><input type="checkbox" data-dd="cache" ${d.cache ? "checked" : ""}><span>Masquer ce dessin</span></label>`;
    else if (G.ddOnglet === "coord" && estPosition(d)) h = [["Entrée", 0, true, true], ["Stop", 1, true, false], ["Objectif", 2, true, false], ["Fin de la zone", 3, false, true]].map(([nom, k, prix, temps]) => `<div class="reg-titre">${nom}</div>
      ${prix ? `<div class="reg-ligne"><span>Prix</span><span class="flex"></span><input type="number" step="any" data-dd-pt="${k}" data-champ="p" value="${d.pts[k].p}"></div>` : ""}
      ${temps ? `<div class="reg-ligne"><span>Date et heure</span><span class="flex"></span><input type="datetime-local" data-dd-pt="${k}" data-champ="t" value="${datePourChamp(d.pts[k].t)}"></div>` : ""}`).join("");
    else if (G.ddOnglet === "style" && LIGNES_TV.has(d.type)) {           // ligne de tendance, comme TradingView
      const coche = (k, def) => `<input type="checkbox" data-dd="${k}" ${(d[k] ?? def) ? "checked" : ""}>`;
      const choix = (k, opts, val) => `<select data-dd="${k}">${opts.map(([v, t]) => `<option value="${v}" ${String(val) === String(v) ? "selected" : ""}>${t}</option>`).join("")}</select>`;
      const pr = prolLigne(d), prol = pr.g && pr.d ? "deux" : pr.g ? "gauche" : pr.d ? "droite" : "aucun";
      const coulL = /^#[0-9a-f]{6}$/i.test(col) ? col : "#2962ff";
      h = `<div class="fibo-tv">
        <div class="ft-ligne"><span>Droite</span><span class="flex"></span><input type="color" data-dd="c" value="${esc(coulL)}" title="Couleur">
          ${choix("w", [[1, "1 px"], [2, "2 px"], [3, "3 px"], [4, "4 px"]], d.w && d.w !== 1.6 ? d.w : 1)}${choix("s", [["0", "──── Plein"], ["1", "─ ─ ─ Tirets"], ["2", "····· Pointillés"]], d.s || 0)}</div>
        <div class="ft-ligne"><span>Extrémités</span><span class="flex"></span>${choix("boutG", [["", "○── Normal"], ["fleche", "◀── Flèche"]], d.boutG || "")}${choix("boutD", [["", "──○ Normal"], ["fleche", "──▶ Flèche"]], d.boutD || (d.type === "fleche" ? "fleche" : ""))}</div>
        <div class="ft-ligne"><span>Prolonger</span><span class="flex"></span>${choix("prolonger", [["aucun", "Ne pas élargir"], ["gauche", "Prolonger à gauche"], ["droite", "Prolonger à droite"], ["deux", "Prolonger des deux côtés"]], prol)}</div>
        <div class="ft-ligne"><label>${coche("milieu", false)}<span>Point médian</span></label></div>
        <div class="ft-ligne"><label>${coche("etiqPrix", false)}<span>Étiquettes de prix</span></label></div>
        <div class="reg-titre">Info</div>
        <div class="ft-ligne"><span>Stats</span><span class="flex"></span>${choix("stats", [["masque", "Masqué"], ["compact", "Compact"], ["complet", "Valeurs"]], statsDe(d))}</div>
        <div class="ft-ligne"><span>Position des stats</span><span class="flex"></span>${choix("statsPos", [["gauche", "Gauche"], ["centre", "Centre"], ["droite", "Droite"]], d.statsPos || "droite")}</div>
        <div class="ft-ligne"><label>${coche("statsToujours", d.type === "info")}<span>Toujours montrer les statistiques</span></label></div>
        <div class="reg-titre">Comportement</div>
        <label class="reg-ligne"><input type="checkbox" data-dd="lock" ${d.lock ? "checked" : ""}><span>Verrouiller (ne peut plus être déplacé)</span></label>
        <label class="reg-ligne"><input type="checkbox" data-dd="cache" ${d.cache ? "checked" : ""}><span>Masquer ce dessin</span></label></div>`;
    }
    else if (G.ddOnglet === "style" && d.type === "rect") {               // rectangle, comme TradingView
      const coche = (k, def) => `<input type="checkbox" data-dd="${k}" ${(d[k] ?? def) ? "checked" : ""}>`;
      const choix = (k, opts, val) => `<select data-dd="${k}">${opts.map(([v, t]) => `<option value="${v}" ${String(val) === String(v) ? "selected" : ""}>${t}</option>`).join("")}</select>`;
      const hex = (v, def) => /^#[0-9a-f]{6}$/i.test(v || "") ? v : def, coulB = hex(col, "#2962ff");
      const STYLES = [["0", "──── Plein"], ["1", "─ ─ ─ Tirets"], ["2", "····· Pointillés"]];
      const prol = d.prolG && d.prolD ? "deux" : d.prolG ? "gauche" : d.prolD ? "droite" : "aucun";
      h = `<div class="fibo-tv">
        <div class="ft-ligne"><span>Prolonger</span><span class="flex"></span>${choix("prolonger", [["aucun", "Ne pas élargir"], ["gauche", "Prolonger à gauche"], ["droite", "Prolonger à droite"], ["deux", "Prolonger des deux côtés"]], prol)}</div>
        <div class="ft-ligne"><span>Bordure</span><span class="flex"></span><input type="color" data-dd="c" value="${esc(coulB)}" title="Couleur de la bordure">
          ${choix("w", [[1, "1 px"], [2, "2 px"], [3, "3 px"], [4, "4 px"]], d.w && d.w !== 1.6 ? d.w : 1)}${choix("s", STYLES, d.s || 0)}</div>
        <div class="ft-ligne"><label>${coche("mediane", false)}<span>Ligne médiane</span></label><span class="flex"></span><input type="color" data-dd="cMed" value="${esc(hex(d.cMed, coulB))}" title="Couleur de la ligne médiane">${choix("sMed", STYLES, d.sMed ?? 1)}</div>
        <div class="ft-ligne"><label>${coche("fond", true)}<span>Arrière-plan</span></label><span class="flex"></span><input type="color" data-dd="cFond" value="${esc(hex(d.cFond, coulB))}" title="Couleur de l'arrière-plan">
          <input type="range" min="0" max="100" step="1" data-dd="fondOp" value="${d.fondOp ?? 15}" title="Opacité de l'arrière-plan"><span class="ft-val">${d.fondOp ?? 15} %</span></div>
        <div class="reg-titre">Comportement</div>
        <label class="reg-ligne"><input type="checkbox" data-dd="lock" ${d.lock ? "checked" : ""}><span>Verrouiller (ne peut plus être déplacé)</span></label>
        <label class="reg-ligne"><input type="checkbox" data-dd="cache" ${d.cache ? "checked" : ""}><span>Masquer ce dessin</span></label></div>`;
    }
    else if (G.ddOnglet === "texteL" && (LIGNES_TV.has(d.type) || d.type === "rect")) {
      const choix = (k, opts, val) => `<select data-dd="${k}">${opts.map(([v, t]) => `<option value="${v}" ${String(val) === String(v) ? "selected" : ""}>${t}</option>`).join("")}</select>`;
      const coulT = /^#[0-9a-f]{6}$/i.test(d.cTx || "") ? d.cTx : (/^#[0-9a-f]{6}$/i.test(col) ? col : "#2962ff");
      h = `<div class="fibo-tv">
        <div class="ft-ligne"><input type="color" data-dd="cTx" value="${esc(coulT)}" title="Couleur du texte">
          ${choix("tTx", [10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 40].map(v => [v, v]), d.tTx || 14)}
          <button type="button" class="tx-style ${d.gras ? "actif" : ""}" data-bascule="gras" title="Gras"><b>B</b></button>
          <button type="button" class="tx-style ${d.ital ? "actif" : ""}" data-bascule="ital" title="Italique"><i>I</i></button></div>
        <textarea data-dd="txt" class="dd-texte" rows="4" placeholder="Ajouter du texte">${esc(d.txt || "")}</textarea>
        <div class="ft-ligne"><span>Alignement du texte</span><span class="flex"></span>${choix("alTxV", [["haut", "Haut"], ["milieu", "Milieu"], ["bas", "Bas"]], d.alTxV || "haut")}${choix("alTxH", [["gauche", "Gauche"], ["centre", "Centre"], ["droite", "Droite"]], d.alTxH || "centre")}</div></div>`;
    }
    else if (G.ddOnglet === "style" && FIBO_REGLABLES.has(d.type)) {      // réglages du Fibonacci, disposés comme sur TradingView
      const autre = !!NIV_AUTRES[d.type];
      const coche = (k, def) => `<input type="checkbox" data-dd="${k}" ${(d[k] ?? def) ? "checked" : ""}>`;
      const couleur = (k, def) => `<input type="color" data-dd="${k}" value="${esc(/^#[0-9a-f]{6}$/i.test(d[k] || "") ? d[k] : def)}">`;
      const choix = (k, opts, val) => `<select data-dd="${k}">${opts.map(([v, t]) => `<option value="${v}" ${String(val) === String(v) ? "selected" : ""}>${t}</option>`).join("")}</select>`;
      const STYLES = [["0", "──── Plein"], ["1", "─ ─ ─ Tirets"], ["2", "····· Pointillés"]], EPAIS = [[1, "1 px"], [2, "2 px"], [3, "3 px"], [4, "4 px"]];
      const prol = d.prolG && d.prolD !== false ? "deux" : d.prolG ? "gauche" : d.prolD === false ? "aucun" : "droite";
      h = `<div class="fibo-tv">
        ${autre ? "" : `<div class="ft-ligne"><label>${coche("tendance", true)}<span>Ligne de tendance</span></label><span class="flex"></span>${couleur("cT", "#787b86")}${choix("sT", STYLES, d.sT ?? 1)}</div>`}
        <div class="ft-ligne"><span>Ligne des niveaux</span><span class="flex"></span>${choix("w", EPAIS, d.w && d.w !== 1.6 ? d.w : 1)}${choix("s", STYLES, d.s || 0)}</div>
        ${autre ? "" : `<div class="ft-ligne"><span>Prolonger</span><span class="flex"></span>${choix("prolonger", [["aucun", "Ne pas élargir"], ["gauche", "Prolonger à gauche"], ["droite", "Prolonger à droite"], ["deux", "Prolonger des deux côtés"]], prol)}</div>`}
        <div class="fibo-grille">` + nivFibo(d).map((x, k) => `<div class="fibo-niv">
          <input type="checkbox" data-fn="${k}" data-champ="on" ${x.on !== false ? "checked" : ""} title="Afficher ce niveau">
          <input type="number" step="any" data-fn="${k}" data-champ="v" value="${x.v}" title="Valeur du niveau (modifiable)">
          <input type="color" data-fn="${k}" data-champ="c" value="${esc(/^#[0-9a-f]{6}$/i.test(x.c || "") ? x.c : "#787b86")}" title="Couleur du niveau">
          <button class="fibo-suppr" data-fn-suppr="${k}" title="Supprimer ce niveau">✕</button></div>`).join("") + `</div>
        <div class="part-nouveau" style="margin-top:8px"><button class="gros gris" data-fn-ajout="1">+ Ajouter un niveau</button><button class="gros gris" data-fn-reinit="1">Niveaux par défaut</button></div>
        <div class="ft-ligne"><label>${coche("uneCouleur", !!d.c)}<span>Utiliser une couleur</span></label><span class="flex"></span>${couleur("c", "#787b86")}</div>
        ${autre ? "" : `<div class="ft-ligne"><label>${coche("fond", true)}<span>Arrière-plan</span></label><span class="flex"></span>
          <input type="range" min="0" max="60" step="1" data-dd="fondOp" value="${d.fondOp ?? 7}" title="Opacité de l'arrière-plan"><span class="ft-val">${d.fondOp ?? 7} %</span></div>
        <div class="ft-ligne"><label>${coche("inverser", false)}<span>Inverser</span></label></div>
        <div class="ft-ligne"><label>${coche("prixAff", true)}<span>Prix</span></label></div>
        <div class="ft-ligne"><label>${coche("nivAff", true)}<span>Niveaux</span></label><span class="flex"></span>${choix("pctSel", [["val", "Valeurs"], ["pct", "Pourcentages"]], d.pct ? "pct" : "val")}</div>
        <div class="ft-ligne"><span>Étiquettes</span><span class="flex"></span>${choix("etiqPos", [["gauche", "Gauche"], ["centre", "Centre"], ["droite", "Droite"]], d.etiqPos || "gauche")}${choix("etiqV", [["haut", "Haut"], ["milieu", "Milieu"], ["bas", "Bas"]], d.etiqV || "haut")}</div>
        <div class="ft-ligne"><span>Taille du texte</span><span class="flex"></span>${choix("tp", [[10, "10"], [11, "11"], [12, "12"], [14, "14"], [16, "16"], [20, "20"]], d.tp || 11)}</div>`}
        <div class="reg-titre">Comportement</div>
        <label class="reg-ligne"><input type="checkbox" data-dd="lock" ${d.lock ? "checked" : ""}><span>Verrouiller (ne peut plus être déplacé)</span></label>
        <label class="reg-ligne"><input type="checkbox" data-dd="cache" ${d.cache ? "checked" : ""}><span>Masquer ce dessin</span></label></div>`;
    }
    else if (G.ddOnglet === "style") h = `<div class="reg-titre">Ligne</div>
      <div class="reg-ligne"><span>Couleur</span><span class="flex"></span><input type="color" data-dd="c" value="${esc(/^#[0-9a-f]{6}$/i.test(col) ? col : "#2962ff")}"></div>
      <div class="reg-ligne"><span>Épaisseur</span><span class="flex"></span><select data-dd="w">${[1, 1.6, 2, 3, 4].map(w => `<option value="${w}" ${(d.w || 1.6) == w ? "selected" : ""}>${w === 1.6 ? "Normale" : w + " px"}</option>`).join("")}</select></div>
      <div class="reg-ligne"><span>Style</span><span class="flex"></span><select data-dd="s">${[["0", "Plein"], ["1", "Tirets"], ["2", "Pointillés"]].map(([v, t]) => `<option value="${v}" ${String(d.s || 0) === v ? "selected" : ""}>${t}</option>`).join("")}</select></div>
      <div class="reg-titre">Comportement</div>
      <label class="reg-ligne"><input type="checkbox" data-dd="lock" ${d.lock ? "checked" : ""}><span>Verrouiller (ne peut plus être déplacé)</span></label>
      <label class="reg-ligne"><input type="checkbox" data-dd="cache" ${d.cache ? "checked" : ""}><span>Masquer ce dessin</span></label>`;
    else if (G.ddOnglet === "texte") h = `<div class="reg-titre">Texte</div><textarea data-dd="txt" class="dd-texte" rows="4">${esc(d.txt || "")}</textarea>
      ${d.type === "texte" ? `<div class="reg-ligne"><span>Taille</span><span class="flex"></span><select data-dd="w">${[1, 2, 3, 4, 5, 6].map(w => `<option value="${w}" ${(d.w || 2) == w ? "selected" : ""}>${12 + w * 2} px</option>`).join("")}</select></div>` : ""}`;
    else if (G.ddOnglet === "coord") h = `<div class="fibo-tv">` + d.pts.map((pt, k) => `<div class="ft-ligne dd-coord"><span>#${k + 1} (prix, date)</span><span class="flex"></span>
      <input type="number" step="any" data-dd-pt="${k}" data-champ="p" value="${pt.p}" title="Prix"><input type="datetime-local" data-dd-pt="${k}" data-champ="t" value="${datePourChamp(pt.t)}" title="Date et heure"></div>`).join("") + `</div>`;
    else h = `<div class="reg-titre">Afficher ce dessin sur ces unités de temps</div>` + UNITES.map(u => `<label class="reg-ligne"><input type="checkbox" data-dd-vis="${u}" ${!d.vis || d.vis.includes(u) ? "checked" : ""}><span>${LIB_UNITE[u]}${u === S.unite ? ' <span class="discret">(unité affichée)</span>' : ""}</span></label>`).join("") +
      `<div class="part-nouveau" style="margin-top:8px"><button class="gros gris" data-dd-tout="1">Toutes</button><button class="gros gris" data-dd-tout="0">Seulement ${LIB_UNITE[S.unite]}</button></div>`;
    $("#ddCorps").innerHTML = h;
  }
  function changerStyleDessin(e) {
    const d = G.dessins[G.sel]; if (!d) return; const el = e.target;
    if (el.dataset.fn != null) {                          // niveaux du Fibonacci
      const niv = nivFibo(d).map(x => Object.assign({}, x)), x = niv[+el.dataset.fn]; if (!x) return;
      if (el.dataset.champ === "on") x.on = el.checked; else if (el.dataset.champ === "v") { if (el.value === "" || !isFinite(+el.value)) return; x.v = +el.value; } else x.c = el.value;
      d.niv = niv; retenirStyle(d);
    }
    else if (el.dataset.dd === "prolonger") { const v = el.value; d.prolG = v === "gauche" || v === "deux"; d.prolD = v === "droite" || v === "deux"; retenirStyle(d); }
    else if (el.dataset.dd === "pctSel") { d.pct = el.value === "pct"; retenirStyle(d); }
    else if (el.dataset.dd) { const k = el.dataset.dd; d[k] = el.type === "checkbox" ? el.checked : ["w", "s", "op", "compte", "risque", "fondOp", "sT", "tp", "tTx", "sMed"].includes(k) ? +el.value : el.value;
      if (k === "fondOp" && el.nextElementSibling) el.nextElementSibling.textContent = el.value + " %";
      if (k === "c" && FIBO_REGLABLES.has(d.type) && el.type === "color") { d.uneCouleur = true; const u = $("#ddCorps [data-dd=uneCouleur]"); if (u) u.checked = true; } if (k === "cache" && !el.checked) delete d.cache; if (CLES_STYLE.includes(k)) retenirStyle(d); }
    else if (el.dataset.ddPt != null) {
      const k = +el.dataset.ddPt, pt = d.pts[k];
      if (estPosition(d)) { const v = el.dataset.champ === "p" ? (el.value !== "" ? +el.value : null) : (el.value ? tempsDuChamp(el.value) : null); if (v != null) bougerPosition(d, k, el.dataset.champ === "p" ? { t: d.pts[k].t, p: v } : { t: v, p: d.pts[k].p }); }
      else { if (el.dataset.champ === "p" && el.value !== "") pt.p = +el.value; if (el.dataset.champ === "t" && el.value) pt.t = tempsDuChamp(el.value); }
    }
    else if (el.dataset.ddVis) { const tous = [...$$("#ddCorps [data-dd-vis]")].filter(x => x.checked).map(x => x.dataset.ddVis); d.vis = tous.length === UNITES.length ? undefined : tous; if (!d.vis) delete d.vis; }
    sale = true; barreDessin();
  }
  function brancherStyleDessin() {
    $("#ddOnglets").onclick = e => { const b = e.target.closest("[data-dd-onglet]"); if (b) { G.ddOnglet = b.dataset.ddOnglet; rendreStyleDessin(); } };
    $("#ddCorps").addEventListener("input", changerStyleDessin); $("#ddCorps").addEventListener("change", changerStyleDessin);
    $("#ddCorps").onclick = e => {
      const d = G.dessins[G.sel]; if (!d) return;
      const bb = e.target.closest("[data-bascule]");
      if (bb) { const k = bb.dataset.bascule; d[k] = !d[k]; bb.classList.toggle("actif", !!d[k]); retenirStyle(d); sale = true; return; }
      const f = e.target.closest("[data-fn-ajout],[data-fn-suppr],[data-fn-reinit]");
      if (f) {                                             // Fibonacci : ajouter / supprimer un niveau, revenir aux niveaux par défaut
        let niv = nivFibo(d).map(x => Object.assign({}, x));
        if (f.dataset.fnAjout) { const max = Math.max(...niv.map(x => +x.v || 0)); niv.push({ v: +(max + 0.5).toFixed(3), c: "#787b86", on: true }); }
        else if (f.dataset.fnSuppr != null) niv.splice(+f.dataset.fnSuppr, 1);
        else niv = nivFiboDefaut(d.type);
        d.niv = niv; retenirStyle(d); rendreStyleDessin(); sale = true; barreDessin(); return;
      }
      const b = e.target.closest("[data-dd-tout]"); if (!b) return; if (b.dataset.ddTout === "1") delete d.vis; else d.vis = [S.unite]; rendreStyleDessin(); sale = true;
    };
    const fermer = garder => {
      const d = G.dessins[G.sel];
      if (d && G.ddAvant) {
        if (garder && JSON.stringify(d) !== G.ddAvant) {         // annuler (Ctrl+Z) revient à l'état d'avant la fenêtre
          G.annuler.push(JSON.stringify(G.dessins.map(x => x === d ? JSON.parse(G.ddAvant) : x))); G.refaire = []; sauverDessins(true);
        } else if (!garder) {
          for (const k of Object.keys(d)) delete d[k]; Object.assign(d, JSON.parse(G.ddAvant));
          const st = JSON.parse(G.ddStyleAvant || "null"); S.dernierStyle = S.dernierStyle || {};   // « Annuler » : le style retenu redevient celui d'avant
          if (st) S.dernierStyle[d.type] = st; else delete S.dernierStyle[d.type]; sauverPrefs();
        }
      }
      G.ddAvant = null; $("#dlgDessin").classList.remove("ouvert"); barreDessin(); sale = true; majObjets();
    };
    $("#ddOk").onclick = () => fermer(true); $("#ddAnnuler").onclick = () => fermer(false); $("#ddFermer").onclick = () => fermer(false);
    G.fermerStyleDessin = fermer;
    $("#bListe").onclick = () => montrerVue("liste"); $("#bObjets").onclick = () => montrerVue("objets"); $("#bDonnees").onclick = () => montrerVue("donnees");
    $("#vueObjets").onclick = actionObjets;
    appliquerVue();
  }

  // ================================================================== plusieurs graphiques, comparaison, menu de l'échelle, mises en page
  const DISPOS = { "1": 0, "2h": 1, "2v": 1, "3": 2, "4": 3 };
  const COUL_COMP = ["#ff9800", "#9c27b0", "#00bcd4"];
  S.dispo = S.dispo || "1"; S.cellules = S.cellules || [{ actif: "GOLD", unite: "H1" }, { actif: "NASDAQ", unite: "M30" }, { actif: "BITCOIN", unite: "H4" }];
  S.comparer = (S.comparer || []).filter(c => c !== S.actif); if (S.syncCurseur === undefined) S.syncCurseur = true;
  G.cells = []; G.compSeries = {}; G.compData = {};
  function optionsCellule(c, ch) {
    const o = optionsTheme();
    if (ch != null) o.localization = { locale: LOC, priceFormatter: p => Number(p).toFixed(ch) };   // précision de l'actif de ce graphique
    o.watermark = Object.assign({}, o.watermark, { text: `${c.actif}, ${FILI_UNITE[c.unite]}`, fontSize: 40 });
    o.rightPriceScale = Object.assign({}, o.rightPriceScale, { mode: 0, invertScale: false });
    return o;
  }
  function appliquerDispo() {
    const n = DISPOS[S.dispo] ?? 0, gr = $("#grille");
    gr.dataset.dispo = S.dispo;
    while (G.cells.length > n) { const c = G.cells.pop(); try { c.chart.remove(); } catch (e) { /* rien */ } c.el.remove(); }
    while (G.cells.length < n) {
      const i = G.cells.length, el = document.createElement("div");
      el.className = "cellule"; el.style.gridArea = "c" + (i + 1);
      el.innerHTML = `<div class="c-graph"></div><div class="c-tete"><button class="c-sym" title="Changer d'actif"></button><select class="c-unite" title="Unité de temps">${UNITES.map(u => `<option value="${u}">${LIB_UNITE[u]}</option>`).join("")}</select>
        <span class="c-ohlc"></span><button class="c-max" title="Ouvrir sur le graphique principal (avec tous les outils)">⤢</button></div>`;
      gr.appendChild(el);
      const cfg = S.cellules[i] || (S.cellules[i] = { actif: "EURUSD", unite: "H1" });
      const ch = nouveauGraphique(el.querySelector(".c-graph"), Object.assign({ autoSize: true }, optionsCellule(cfg)));
      const cell = { el, chart: ch, serie: null, bars: [], i };
      G.cells.push(cell);
      el.querySelector(".c-sym").onclick = () => ouvrirDlg("cellule:" + i);
      el.querySelector(".c-unite").onchange = ev => { S.cellules[i].unite = ev.target.value; sauverPrefs(); chargerCellule(cell); };
      el.querySelector(".c-max").onclick = async () => { const c = S.cellules[i]; await changerActif(c.actif); if (c.unite !== S.unite) await changerUnite(c.unite); };
      ch.subscribeCrosshairMove(p => legendeCellule(cell, p && p.logical != null ? Math.round(p.logical) : null));
      chargerCellule(cell);
    }
    setTimeout(tailleCalque, 50);
  }
  function serieCellule(cell) {
    if (cell.serie) cell.chart.removeSeries(cell.serie);
    const c = couleursBougies();
    cell.serie = cell.chart.addCandlestickSeries({ upColor: c.up, downColor: c.down, borderUpColor: c.bordUp, borderDownColor: c.bordDown, wickUpColor: c.mecheUp, wickDownColor: c.mecheDown,
      priceLineVisible: S.reg.ligneDernier, lastValueVisible: S.reg.etiqDernier, priceFormat: { type: "price", precision: cell.chiffres ?? 5, minMove: Math.pow(10, -(cell.chiffres ?? 5)) } });
  }
  async function chargerCellule(cell) {
    const cfg = S.cellules[cell.i], cle = cfg.actif + "|" + cfg.unite;
    cell.cle = cle;
    cell.el.querySelector(".c-sym").textContent = cfg.actif; cell.el.querySelector(".c-unite").value = cfg.unite;
    cell.el.querySelector(".c-ohlc").textContent = "chargement…";
    let r; try { r = await api(`/api/bougies?actif=${cfg.actif}&unite=${cfg.unite}&n=1500`); } catch (e) { r = { erreur: "serveur injoignable" }; }
    if (cell.cle !== cle || !G.cells.includes(cell)) return;
    if (r.erreur) { cell.el.querySelector(".c-ohlc").textContent = "⚠ " + r.erreur; return; }
    cell.bars = r.bougies || []; cell.sec = r.secondes; cell.chiffres = r.chiffres;
    cell.chart.applyOptions(optionsCellule(cfg, cell.chiffres)); serieCellule(cell); donneesCellule(cell);
  }
  function barsCellule(cell) {     // en replay, jamais de bougie plus récente que le replay
    if (G.mode !== "replay" || G.rt == null) return cell.bars;
    return cell.bars.filter(b => b[0] + (cell.sec || 0) <= G.rt);
  }
  function donneesCellule(cell) {
    if (!cell.serie) return;
    cell.vis = barsCellule(cell);
    cell.serie.setData(cell.vis.filter(b => b && b[0] != null && b[4] != null).map(b => ({ time: lt(b[0]), open: b[1], high: b[2], low: b[3], close: b[4] })));
    legendeCellule(cell, null);
  }
  function legendeCellule(cell, i) {
    const v = cell.vis || [], b = v[i != null && i >= 0 && i < v.length ? i : v.length - 1];
    if (!b) return;
    const ch = cell.chiffres ?? 5, c = b[4] >= b[1] ? VERT : ROUGE, f = x => Number(x).toFixed(ch);
    cell.el.querySelector(".c-ohlc").innerHTML = `O<b style="color:${c}">${f(b[1])}</b> H<b style="color:${c}">${f(b[2])}</b> B<b style="color:${c}">${f(b[3])}</b> C<b style="color:${c}">${f(b[4])}</b>`;
  }
  async function rafraichirCellules() {
    if (G.mode === "replay" || G.cellulesEnCours) return;
    G.cellulesEnCours = true; setTimeout(() => { G.cellulesEnCours = false; }, 60000);   // sécurité si une réponse ne revient jamais
    try { await rafraichirCellules2(); } finally { G.cellulesEnCours = false; }
  }
  async function rafraichirCellules2() {
    for (const cell of G.cells) {
      const cfg = S.cellules[cell.i];
      try {
        const r = await api(`/api/recent?actif=${cfg.actif}&unite=${cfg.unite}`);
        if (!r.bougies || cell.cle !== cfg.actif + "|" + cfg.unite) continue;
        for (const b of r.bougies) { const k = cell.bars.findIndex(x => x[0] === b[0]); if (k >= 0) cell.bars[k] = b; else if (!cell.bars.length || b[0] > cell.bars[cell.bars.length - 1][0]) cell.bars.push(b); }
        donneesCellule(cell);
      } catch (e) { /* réseau : on réessaie au prochain tour */ }
    }
  }
  function syncCurseur(p) {
    if (!S.syncCurseur || !G.cells.length) return;
    const t = p && p.time != null ? p.time : null;
    for (const cell of G.cells) {
      if (!cell.serie || !cell.vis || !cell.vis.length) continue;
      if (t == null) { cell.chart.clearCrosshairPosition(); continue; }
      let lo = 0, hi = cell.vis.length - 1, k = -1;            // dernière bougie de la cellule qui commence avant ce moment
      while (lo <= hi) { const m = (lo + hi) >> 1; if (lt(cell.vis[m][0]) <= t) { k = m; lo = m + 1; } else hi = m - 1; }
      if (k < 0) { cell.chart.clearCrosshairPosition(); continue; }
      cell.chart.setCrosshairPosition(cell.vis[k][4], lt(cell.vis[k][0]), cell.serie);
      legendeCellule(cell, k);
    }
  }
  function themeCellules() { for (const cell of G.cells) { cell.chart.applyOptions(optionsCellule(S.cellules[cell.i], cell.chiffres)); if (cell.serie) { serieCellule(cell); donneesCellule(cell); } } }

  // comparer des actifs (courbes en %, sur le même graphique)
  async function chargerComparaisons() {
    const unite = S.unite, actif = S.actif;
    for (const code of S.comparer) {
      try {
        const r = await api(`/api/bougies?actif=${code}&unite=${unite}&n=${Math.max(500, G.bars.length)}${G.bars.length && G.mode === "replay" && G.rt ? "&fin=" + Math.floor(G.rt) : ""}`);
        if (unite !== S.unite || actif !== S.actif) return;
        G.compData[code] = r.bougies || [];
      } catch (e) { G.compData[code] = []; }
    }
    majComparaisons();
  }
  function majComparaisons() {
    for (const code of Object.keys(G.compSeries)) if (!S.comparer.includes(code)) { try { chart.removeSeries(G.compSeries[code]); } catch (e) { /* série déjà retirée */ } delete G.compSeries[code]; }
    const n = nVis(), tFin = n ? G.bars[n - 1][0] : Infinity, t0 = G.bars.length ? G.bars[0][0] : 0;
    S.comparer.forEach((code, k) => {
      if (!G.compSeries[code]) G.compSeries[code] = chart.addLineSeries({ color: COUL_COMP[k % 3], lineWidth: 2, priceScaleId: "right", priceLineVisible: false, lastValueVisible: true, title: code, crosshairMarkerVisible: true });
      G.compSeries[code].applyOptions({ color: COUL_COMP[k % 3] });
      G.compSeries[code].setData((G.compData[code] || []).filter(b => b[0] >= t0 && b[0] <= tFin).map(b => ({ time: lt(b[0]), value: b[4] })));
    });
    chart.priceScale("right").applyOptions({ mode: S.comparer.length ? 2 : +S.echelle });
    if (!G.legendeEnCours) { G.legendeEnCours = true; try { legende(); } finally { G.legendeEnCours = false; } }
  }
  function ajouterComparaison(code) {
    if (code === S.actif) { toast("C'est déjà l'actif du graphique.", false); return; }
    if (S.comparer.includes(code)) return;
    if (S.comparer.length >= 3) { toast("3 actifs comparés au maximum : retirez-en un (✕ dans la légende).", false); return; }
    S.comparer.push(code); sauverPrefs(); chargerComparaisons();
    toast(`${code} ajouté en comparaison : l'échelle passe en pourcentage pour comparer les mouvements.`);
  }
  function retirerComparaison(code) { S.comparer = S.comparer.filter(c => c !== code); sauverPrefs(); majComparaisons(); legende(); }

  // clic droit sur l'échelle des prix
  function menuEchelle(e) {
    e.preventDefault(); e.stopPropagation(); fermerVolet();
    let auto = true; try { auto = chart.priceScale("right").options().autoScale !== false; } catch (x) { /* rien */ }
    const coche = v => v ? '<span class="raccourci">✓</span>' : "", m = S.comparer.length ? 2 : +S.echelle;
    volet = document.createElement("div"); volet.className = "volet ouvert contexte";
    volet.innerHTML = `<div class="titre-pop">Échelle des prix</div>
      <button data-e-act="auto"><span class="nom">Auto (adapte les données à l'écran)</span>${coche(auto)}</button>
      <button data-e-act="reinit"><span class="nom">Réinitialiser l'échelle des prix</span><span class="raccourci">Alt+R</span></button>
      <div class="titre-pop">Mode</div>
      ${[[0, "Normale"], [1, "Logarithmique"], [2, "Pourcentage"], [3, "Indexée à 100"]].map(([v, t]) => `<button data-e-mode="${v}" ${S.comparer.length && v !== 2 ? 'disabled title="Retirez les actifs comparés pour changer de mode"' : ""}><span class="nom">${t}</span>${coche(m === v)}</button>`).join("")}
      <button data-e-act="inverse"><span class="nom">Inverser l'échelle</span>${coche(S.inverse)}</button>
      <div class="titre-pop">Étiquettes</div>
      <button data-e-act="etiq"><span class="nom">Étiquette du dernier prix</span>${coche(S.reg.etiqDernier)}</button>
      <button data-e-act="ligne"><span class="nom">Ligne du dernier prix</span>${coche(S.reg.ligneDernier)}</button>
      <button data-e-act="rebours"><span class="nom">Compte à rebours de la bougie</span>${coche(S.rebours)}</button>
      <button data-e-act="reglages"><span class="nom">Réglages de l'échelle…</span></button>`;
    document.body.appendChild(volet);
    volet.style.left = Math.min(e.clientX, window.innerWidth - volet.offsetWidth - 8) + "px";
    volet.style.top = Math.min(e.clientY, window.innerHeight - volet.offsetHeight - 8) + "px";
    volet.onclick = ev => {
      const b = ev.target.closest("button"); if (!b || b.disabled) return;
      const a = b.dataset.eAct;
      if (b.dataset.eMode != null) { S.echelle = +b.dataset.eMode; chart.applyOptions(optionsTheme()); chart.priceScale("right").applyOptions({ autoScale: true }); }
      else if (a === "auto") chart.priceScale("right").applyOptions({ autoScale: !auto });
      else if (a === "reinit") chart.priceScale("right").applyOptions({ autoScale: true });
      else if (a === "inverse") { S.inverse = !S.inverse; chart.applyOptions(optionsTheme()); }
      else if (a === "etiq") { S.reg.etiqDernier = !S.reg.etiqDernier; serie.applyOptions({ lastValueVisible: S.reg.etiqDernier }); }
      else if (a === "ligne") { S.reg.ligneDernier = !S.reg.ligneDernier; serie.applyOptions({ priceLineVisible: S.reg.ligneDernier }); }
      else if (a === "rebours") S.rebours = !S.rebours;
      else if (a === "reglages") { fermerVolet(); ouvrirReglages("echelles"); return; }
      sauverPrefs(); majComparaisons(); majCoin(); sale = true; fermerVolet();
    };
  }

  // disposition et mises en page
  // Mises en page, comme TradingView : gardées dans le logiciel (préférences), récupérées une fois depuis l'ancien stockage du navigateur
  if (!S.mises) { try { S.mises = JSON.parse(localStorage.getItem("mbgMisesEnPage") || "{}"); } catch (e) { S.mises = {}; } }
  if (S.sauvegardeAuto === undefined) S.sauvegardeAuto = true;
  S.misesRecentes = (S.misesRecentes || []).filter(n => S.mises[n]);
  const lireMises = () => S.mises || {};
  const CLES_MISE = ["actif", "unite", "type", "inds", "reg", "theme", "dispo", "cellules", "comparer", "echelle", "inverse", "fuseau", "filigrane", "rebours", "syncCurseur", "onglets"];
  const instantaneMise = () => JSON.parse(JSON.stringify(Object.fromEntries(CLES_MISE.filter(k => S[k] !== undefined).map(k => [k, S[k]]))));
  function noterRecente(n) { S.misesRecentes = [n, ...(S.misesRecentes || []).filter(x => x !== n)].slice(0, 5); }
  function enregistrerMise(n, silencieux) {
    n = String(n || "").trim().slice(0, 50); if (!n) return false;
    S.mises = S.mises || {}; S.mises[n] = instantaneMise(); S.miseCourante = n; noterRecente(n); sauverPrefs(); majBoutonMise();
    if (!silencieux) toast(`Mise en page « ${n} » enregistrée.`);
    return true;
  }
  function ouvrirMise(n) {
    const m = (S.mises || {})[n]; if (!m) return;
    if (S.sauvegardeAuto && S.miseCourante && S.miseCourante !== n && S.mises[S.miseCourante]) S.mises[S.miseCourante] = instantaneMise();
    Object.assign(S, JSON.parse(JSON.stringify(m))); S.miseCourante = n; noterRecente(n); sauverPrefs();
    setTimeout(() => location.reload(), 300);                          // laisse partir l'enregistrement, puis recharge le graphique
  }
  let minuteurAuto = null;
  function sauvegardeAutoMise() {                                      // appelée à chaque changement de réglage
    if (!S.sauvegardeAuto || !S.miseCourante || !S.mises || !S.mises[S.miseCourante]) return;
    clearTimeout(minuteurAuto); minuteurAuto = setTimeout(() => { if (S.mises[S.miseCourante]) S.mises[S.miseCourante] = instantaneMise(); }, 1500);
  }
  function majBoutonMise() { const el = $("#miseNom"); if (el) { el.textContent = S.miseCourante || "Sans nom"; el.parentNode.title = "Mise en page : " + (S.miseCourante || "pas encore enregistrée"); } }
  function telechargerFichier(nom, contenu, type) {
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([contenu], { type })); a.download = nom;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }
  function telechargerDonnees() {                                      // bougies affichées, en CSV (s'ouvre dans Excel)
    const n = nVis(); if (!n) { toast("Aucune donnée à télécharger.", false); return; }
    const lignes = ["date;ouverture;haut;bas;cloture;volume"];
    for (let i = 0; i < n; i++) { const b = G.bars[i]; lignes.push([new Date(b[0] * 1000).toISOString().replace("T", " ").slice(0, 19), b[1], b[2], b[3], b[4], b[5] || 0].join(";")); }
    telechargerFichier(`${S.actif}_${S.unite}_${new Date().toISOString().slice(0, 10)}.csv`, lignes.join("\r\n"), "text/csv;charset=utf-8");
    toast(`${n} bougies de ${S.actif} (${S.unite}) téléchargées.`);
  }
  function partagerMise() {                                            // fichier à envoyer à un autre utilisateur de MaBoussole
    const n = S.miseCourante || "Ma mise en page";
    telechargerFichier(n.replace(/[^\w\- ]+/g, "_") + ".maboussole.json", JSON.stringify({ format: "maboussole-mise-en-page", version: 1, nom: n, mise: instantaneMise() }, null, 1), "application/json");
    toast("Fichier de la mise en page créé : envoyez-le, l'autre personne l'ouvre avec « Importer une mise en page ».");
  }
  function importerMise() {
    const i = document.createElement("input"); i.type = "file"; i.accept = ".json,application/json";
    i.onchange = () => {
      const f = i.files[0]; if (!f || f.size > 2e6) return;
      const lec = new FileReader();
      lec.onload = async () => {
        let o; try { o = JSON.parse(lec.result); } catch (e) { toast("Ce fichier n'est pas une mise en page MaBoussole.", false); return; }
        if (!o || o.format !== "maboussole-mise-en-page" || !o.mise || typeof o.mise !== "object") { toast("Ce fichier n'est pas une mise en page MaBoussole.", false); return; }
        const propre = Object.fromEntries(CLES_MISE.filter(k => o.mise[k] !== undefined).map(k => [k, o.mise[k]]));   // seulement les réglages connus
        const nom = await saisir("Nom de la mise en page importée :", String(o.nom || "Mise en page importée").slice(0, 50)); if (!nom) return;
        S.mises[nom.trim().slice(0, 50)] = JSON.parse(JSON.stringify(propre)); sauverPrefs(); toast(`Mise en page « ${nom} » importée.`); ouvrirMise(nom.trim().slice(0, 50));
      };
      lec.readAsText(f);
    };
    i.click();
  }
  function menuMise(e) {
    e.stopPropagation(); fermerVolet();
    const rec = (S.misesRecentes || []).filter(n => S.mises[n]);
    volet = document.createElement("div"); volet.className = "volet ouvert menu-mise";
    volet.innerHTML = `
      <button data-m="sauver"><span>Sauvegarder la mise en page</span><kbd>Ctrl + S</kbd></button>
      <label class="mm-bascule"><span>Sauvegarde automatique</span><input type="checkbox" data-m="auto" ${S.sauvegardeAuto ? "checked" : ""}><i></i></label>
      <button data-m="partager"><span>Partager la mise en page (fichier)…</span></button>
      <hr>
      <button data-m="copie"><span>Créer une copie…</span></button>
      <button data-m="renommer" ${S.miseCourante ? "" : "disabled"}><span>Renommer…</span></button>
      <button data-m="donnees"><span>Télécharger les données du graphique…</span></button>
      <hr>
      <button data-m="nouvelle"><span>＋ Créer une nouvelle mise en page…</span></button>
      <button data-m="importer"><span>Importer une mise en page…</span></button>
      ${rec.length ? `<div class="titre-pop">Récemment utilisé</div>` + rec.map(n => { const m = S.mises[n]; return `<button data-m="ouvrir" data-nom="${esc(n)}" class="mm-recente ${n === S.miseCourante ? "actif" : ""}"><b>${esc(n)}</b><small>${esc(m.actif || "")}, ${esc(LIB_UNITE[m.unite] || m.unite || "")}</small></button>`; }).join("") : ""}
      <hr>
      <button data-m="liste"><span>Ouvrir la mise en page…</span></button>`;
    document.body.appendChild(volet);
    const r = $("#bMise").getBoundingClientRect();
    volet.style.left = Math.max(8, Math.min(r.left, innerWidth - volet.offsetWidth - 8)) + "px"; volet.style.top = (r.bottom + 4) + "px";
    volet.onchange = ev => { if (ev.target.dataset.m === "auto") { S.sauvegardeAuto = ev.target.checked; sauverPrefs(); if (S.sauvegardeAuto && S.miseCourante) enregistrerMise(S.miseCourante, true); } };
    volet.onclick = async ev => {
      const b = ev.target.closest("button[data-m]"); if (!b || b.disabled) return;
      const a = b.dataset.m; fermerVolet();
      if (a === "sauver") sauverMiseCourante();
      else if (a === "partager") partagerMise();
      else if (a === "donnees") telechargerDonnees();
      else if (a === "importer") importerMise();
      else if (a === "ouvrir") ouvrirMise(b.dataset.nom);
      else if (a === "liste") listeMises();
      else if (a === "copie") { const n = await saisir("Nom de la copie :", (S.miseCourante ? S.miseCourante + " (copie)" : "Ma mise en page")); if (n) enregistrerMise(n); }
      else if (a === "renommer") {
        const n = (await saisir("Nouveau nom de la mise en page :", S.miseCourante) || "").trim().slice(0, 50); if (!n || n === S.miseCourante) return;
        S.mises[n] = S.mises[S.miseCourante]; delete S.mises[S.miseCourante];
        S.misesRecentes = (S.misesRecentes || []).map(x => x === S.miseCourante ? n : x); S.miseCourante = n; sauverPrefs(); majBoutonMise(); toast(`Mise en page renommée « ${n} ».`);
      }
      else if (a === "nouvelle") {
        const n = (await saisir("Nom de la nouvelle mise en page :", "") || "").trim().slice(0, 50); if (!n) return;
        if (S.sauvegardeAuto && S.miseCourante && S.mises[S.miseCourante]) S.mises[S.miseCourante] = instantaneMise();
        S.inds = [{ uid: "i" + Date.now().toString(36), id: "vol", p: {} }]; S.comparer = []; S.dispo = "1"; S.echelle = 0; S.inverse = false;
        enregistrerMise(n, true); toast(`Nouvelle mise en page « ${n} ».`); setTimeout(() => location.reload(), 300);
      }
    };
  }
  async function sauverMiseCourante() {
    if (S.miseCourante) { enregistrerMise(S.miseCourante); return; }
    const n = await saisir("Nom de la mise en page :", "Ma mise en page"); if (n) enregistrerMise(n);
  }
  async function listeMises() {                                        // « Ouvrir la mise en page… » : toutes les mises en page, avec recherche
    const fond = document.createElement("div"); fond.className = "boite-fond";
    fond.innerHTML = `<div class="boite liste-mises" role="dialog" aria-modal="true"><div class="boite-titre">Ouvrir la mise en page</div>
      <input class="boite-saisie" id="lmRecherche" placeholder="Rechercher" maxlength="50"><div class="lm-liste"></div>
      <div class="boite-boutons"><button class="boite-non">Fermer</button></div></div>`;
    document.body.appendChild(fond);
    const rendre = () => {
      const q = fond.querySelector("#lmRecherche").value.toLowerCase(), noms = Object.keys(S.mises || {}).filter(n => n.toLowerCase().includes(q)).sort((x, y) => x.localeCompare(y));
      fond.querySelector(".lm-liste").innerHTML = noms.length ? noms.map(n => { const m = S.mises[n]; return `<div class="lm-ligne ${n === S.miseCourante ? "actif" : ""}"><button data-o="${esc(n)}"><b>${esc(n)}</b><small>${esc(m.actif || "")}, ${esc(LIB_UNITE[m.unite] || m.unite || "")}</small></button><button class="lm-suppr" data-x="${esc(n)}" title="Supprimer">✕</button></div>`; }).join("")
        : `<p class="discret">Aucune mise en page enregistrée. Utilisez « Sauvegarder la mise en page » (Ctrl + S).</p>`;
    };
    rendre();
    const fermer = () => fond.remove();
    fond.querySelector("#lmRecherche").oninput = rendre;
    fond.querySelector("#lmRecherche").onkeydown = ev => { ev.stopPropagation(); if (ev.key === "Escape") fermer(); };
    fond.querySelector(".boite-non").onclick = fermer;
    fond.addEventListener("mousedown", ev => { if (ev.target === fond) fermer(); });
    fond.querySelector(".lm-liste").onclick = async ev => {
      const o = ev.target.closest("[data-o]"), x = ev.target.closest("[data-x]");
      if (o) { fermer(); ouvrirMise(o.dataset.o); }
      if (x) {
        const n = x.dataset.x; if (!await demander(`Supprimer la mise en page « ${n} » ?`)) return;
        delete S.mises[n]; S.misesRecentes = (S.misesRecentes || []).filter(y => y !== n); if (S.miseCourante === n) S.miseCourante = null; sauverPrefs(); majBoutonMise(); rendre();
      }
    };
    setTimeout(() => fond.querySelector("#lmRecherche").focus(), 50);
  }
  const ICO_DISPO = { "1": '<rect x="3" y="4" width="18" height="16" rx="1.5"/>', "2h": '<rect x="3" y="4" width="18" height="16" rx="1.5"/><path d="M12 4v16"/>',
    "2v": '<rect x="3" y="4" width="18" height="16" rx="1.5"/><path d="M3 12h18"/>', "3": '<rect x="3" y="4" width="18" height="16" rx="1.5"/><path d="M12 4v16M12 12h9"/>',
    "4": '<rect x="3" y="4" width="18" height="16" rx="1.5"/><path d="M12 4v16M3 12h18"/>' };
  function menuDispo(e) {
    e.stopPropagation(); fermerVolet();
    const mises = lireMises();
    volet = document.createElement("div"); volet.className = "volet ouvert menu-dispo";
    volet.innerHTML = `<div class="titre-pop">Disposition</div><div class="dispo-icones">${Object.keys(DISPOS).map(k => `<button data-dispo="${k}" class="${S.dispo === k ? "actif" : ""}" title="${k === "1" ? "1 graphique" : (DISPOS[k] + 1) + " graphiques"}"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.5">${ICO_DISPO[k]}</svg></button>`).join("")}</div>
      <label class="dispo-sync"><input type="checkbox" id="dSync" ${S.syncCurseur ? "checked" : ""}> Synchroniser le curseur entre les graphiques</label>
      <div class="titre-pop">Mises en page</div>
      ${Object.keys(mises).length ? Object.keys(mises).map(n => `<div class="mod-ligne"><button data-mise="${esc(n)}"><span class="nom">${esc(n)}</span></button><button class="suppr" data-mise-suppr="${esc(n)}" title="Supprimer">✕</button></div>`).join("") : '<div class="discret" style="padding:4px 14px">Aucune mise en page enregistrée.</div>'}
      <div class="dispo-sauver"><input id="dNom" maxlength="40" placeholder="Nom (ex. Or multi-unités)"><button id="dSauver">Enregistrer</button></div>`;
    document.body.appendChild(volet);
    const r = $("#bDispo").getBoundingClientRect();
    volet.style.left = Math.max(8, Math.min(r.left, window.innerWidth - volet.offsetWidth - 8)) + "px"; volet.style.top = (r.bottom + 4) + "px";
    volet.querySelector("#dSync").onchange = ev => { S.syncCurseur = ev.target.checked; sauverPrefs(); if (!S.syncCurseur) G.cells.forEach(c => c.chart.clearCrosshairPosition()); };
    volet.querySelector("#dSauver").onclick = () => {
      const n = volet.querySelector("#dNom").value.trim().slice(0, 40); if (!n) { volet.querySelector("#dNom").focus(); return; }
      enregistrerMise(n);
      fermerVolet();
    };
    volet.querySelector("#dNom").onkeydown = ev => { ev.stopPropagation(); if (ev.key === "Enter") volet.querySelector("#dSauver").click(); };
    volet.onclick = async ev => {
      const b = ev.target.closest("button"); if (!b) return;
      if (b.dataset.dispo) { S.dispo = b.dataset.dispo; sauverPrefs(); appliquerDispo(); fermerVolet(); }
      else if (b.dataset.mise) ouvrirMise(b.dataset.mise);
      else if (b.dataset.miseSuppr) { if (!await demander(`Supprimer la mise en page « ${b.dataset.miseSuppr} » ?`)) return; delete S.mises[b.dataset.miseSuppr]; if (S.miseCourante === b.dataset.miseSuppr) S.miseCourante = null; sauverPrefs(); majBoutonMise(); fermerVolet(); menuDispo(ev); }
    };
  }
  function brancherMulti() {
    $("#bDispo").onclick = menuDispo;
    $("#bMise").onclick = menuMise; majBoutonMise();
    $("#bComparer").onclick = () => ouvrirDlg("comparer");
    chart.subscribeCrosshairMove(syncCurseur);
    appliquerDispo(); setInterval(rafraichirCellules, 20000);
  }

  // ================================================================== données OANDA (jeton personnel de l'utilisateur)
  async function ouvrirOanda() {
    let c = {}; try { c = (await api("/api/config")).oanda || {}; } catch (e) { /* rien */ }
    $("#oaEnv").value = c.env || "demo"; $("#oaJeton").value = ""; $("#oaActif").checked = !!c.actif; $("#oaActif").disabled = !c.configure;
    $("#oaRetirer").style.display = c.configure ? "" : "none";
    $("#oaEtat").innerHTML = !c.disponible ? "⚠ La protection du jeton n'est disponible que sous Windows." : c.configure
      ? `<b style="color:${VERT}">✓ Jeton enregistré</b> (compte ${c.env === "reel" ? "réel" : "démo"}${c.verifie ? ", vérifié le " + dateCourte(c.verifie) : ""}). Pour le remplacer, collez-en un nouveau.` : "Aucun jeton enregistré.";
    $("#dlgOanda").classList.add("ouvert");
  }
  async function apresOanda(msg) { toast(msg); $("#dlgOanda").classList.remove("ouvert"); if (G.mode === "direct") { await charger(); demarrerDirect(); } G.cells.forEach(chargerCellule); }
  function brancherOanda() {
    $("#regCorps").addEventListener("click", e => { if (e.target.closest("#bOanda")) ouvrirOanda(); });
    $("#oaOk").onclick = async () => {
      const jeton = $("#oaJeton").value.trim();
      $("#oaOk").disabled = true; $("#oaOk").textContent = "Vérification…";
      const r = await api("/api/oanda", jeton ? { jeton, env: $("#oaEnv").value } : { actif: $("#oaActif").checked }).catch(() => ({ ok: false, message: "serveur injoignable" }));
      $("#oaOk").disabled = false; $("#oaOk").textContent = "Vérifier et enregistrer"; $("#oaJeton").value = "";
      if (!r.ok) { $("#oaEtat").innerHTML = `<b style="color:${ROUGE}">⚠ ${esc(r.message || "échec")}</b>`; return; }
      apresOanda(r.oanda.actif ? "OANDA activé : les graphiques utilisent maintenant les bougies d'OANDA." : "OANDA désactivé : retour aux sources gratuites.");
    };
    $("#oaActif").onchange = async () => { const r = await api("/api/oanda", { actif: $("#oaActif").checked }); if (r.ok) apresOanda(r.oanda.actif ? "OANDA activé." : "OANDA désactivé : retour aux sources gratuites."); };
    $("#oaRetirer").onclick = async () => { if (!await demander("Retirer le jeton OANDA de ce PC ?", { ok: "Retirer" })) return; const r = await api("/api/oanda", { retirer: true }); if (r.ok) apresOanda("Jeton OANDA retiré de ce PC."); };
  }

  // ================================================================== onglets de graphiques (plusieurs actifs ouverts à la fois)
  const MAX_ONGLETS = 20;
  function initOnglets() {
    const ok = o => o && G.catalogue.some(x => x.code === o.actif) && uniteValide(o.unite);
    S.onglets = Array.isArray(S.onglets) ? S.onglets.filter(ok).slice(0, MAX_ONGLETS) : [];
    if (!S.onglets.length) S.onglets = [{ actif: S.actif, unite: S.unite }];
    S.ongletActif = Math.min(Math.max(0, S.ongletActif | 0), S.onglets.length - 1);
    S.onglets[S.ongletActif] = { actif: S.actif, unite: S.unite };
  }
  function rendreOnglets() {
    const el = $("#ongletsGraph"); if (!el || !S.onglets) return;
    el.innerHTML = `<button class="og-plus" id="ogPlus" title="Nouvel onglet : ouvrir un autre actif (Ctrl + T)">+</button>` + S.onglets.map((o, i) => `<div class="onglet-g ${i === S.ongletActif ? "actif" : ""}" data-i="${i}" title="${esc(nomActif(o.actif))} · ${esc(nomLongU(o.unite))}">
        <span class="og-nom">${esc(o.actif)}</span><span class="og-u">${esc(LIB_UNITE[o.unite] || "")}</span>
        ${S.onglets.length > 1 ? `<button class="og-x" data-fermer-o="${i}" title="Fermer l'onglet">✕</button>` : ""}</div>`).join("");
    el.querySelector(".onglet-g.actif")?.scrollIntoView({ block: "nearest", inline: "nearest" });
  }
  function majOnglet() {                          // l'onglet affiché suit l'actif et l'unité du graphique
    if (!S.onglets) return;
    S.onglets[S.ongletActif] = { actif: S.actif, unite: S.unite }; sauverPrefs(); rendreOnglets();
  }
  async function allerOnglet(i) {
    if (i === S.ongletActif || !S.onglets[i] || G.charge) return;
    if (G.mode === "replay" && G.positions.some(p => p.active) && !await demander("Changer d'onglet ferme les positions simulées du replay. Continuer ?", { ok: "Continuer", danger: false })) return;
    const o = S.onglets[i]; S.ongletActif = i; rendreOnglets();
    if (o.actif === S.actif) { if (o.unite !== S.unite) await changerUnite(o.unite); }
    else { if (G.mode === "replay") viderPositions(); S.unite = o.unite; majUnites(); await changerActif(o.actif); }
    majOnglet();
  }
  async function nouvelOnglet(actif, unite) {
    if (S.onglets.length >= MAX_ONGLETS) { toast(MAX_ONGLETS + " onglets au maximum : fermez-en un.", false); return; }
    S.onglets.push({ actif, unite: unite || S.unite }); await allerOnglet(S.onglets.length - 1);
  }
  async function fermerOnglet(i) {
    if (S.onglets.length <= 1) return;
    const etaitActif = i === S.ongletActif;
    S.onglets.splice(i, 1);
    if (i < S.ongletActif) S.ongletActif--;
    if (etaitActif) { S.ongletActif = -1; await allerOnglet(Math.min(i, S.onglets.length - 1)); }
    else { sauverPrefs(); rendreOnglets(); }
  }
  function menuOnglet(e, i) {
    e.preventDefault(); fermerVolet();
    volet = document.createElement("div"); volet.className = "volet ouvert contexte";
    volet.innerHTML = `<button data-og="dup"><span class="nom">Dupliquer l'onglet</span></button>
      <button data-og="autres" ${S.onglets.length < 2 ? "disabled" : ""}><span class="nom">Fermer les autres onglets</span></button>
      <button data-og="droite" ${i >= S.onglets.length - 1 ? "disabled" : ""}><span class="nom">Fermer les onglets à droite</span></button>
      <button data-og="fermer" ${S.onglets.length < 2 ? "disabled" : ""}><span class="nom">Fermer l'onglet</span><span class="raccourci">clic molette</span></button>`;
    document.body.appendChild(volet);
    volet.style.left = Math.min(e.clientX, window.innerWidth - volet.offsetWidth - 8) + "px"; volet.style.top = Math.min(e.clientY, window.innerHeight - volet.offsetHeight - 8) + "px";
    volet.onclick = async ev => {
      const b = ev.target.closest("[data-og]"); if (!b || b.disabled) return; fermerVolet();
      const a = b.dataset.og;
      if (a === "dup") { S.onglets.splice(i + 1, 0, Object.assign({}, S.onglets[i])); if (i < S.ongletActif) S.ongletActif++; await allerOnglet(i + 1); }
      else if (a === "fermer") await fermerOnglet(i);
      else if (a === "autres") { const garde = S.onglets[i]; const etait = i === S.ongletActif; S.onglets = [garde]; S.ongletActif = etait ? 0 : -1; if (etait) { sauverPrefs(); rendreOnglets(); } else await allerOnglet(0); }
      else if (a === "droite") { const actifPerdu = S.ongletActif > i; S.onglets = S.onglets.slice(0, i + 1); if (actifPerdu) { S.ongletActif = -1; await allerOnglet(i); } else { sauverPrefs(); rendreOnglets(); } }
    };
  }
  function brancherOnglets() {
    initOnglets(); rendreOnglets();
    const el = $("#ongletsGraph");
    el.onclick = e => {
      const x = e.target.closest("[data-fermer-o]"); if (x) { e.stopPropagation(); fermerOnglet(+x.dataset.fermerO); return; }
      if (e.target.closest("#ogPlus")) { ouvrirDlg("onglet"); return; }
      const o = e.target.closest(".onglet-g"); if (o) allerOnglet(+o.dataset.i);
    };
    el.addEventListener("auxclick", e => { const o = e.target.closest(".onglet-g"); if (o && e.button === 1) { e.preventDefault(); fermerOnglet(+o.dataset.i); } });
    el.addEventListener("mousedown", e => { if (e.button === 1) e.preventDefault(); });         // pas de défilement automatique au clic molette
    el.oncontextmenu = e => { const o = e.target.closest(".onglet-g"); if (o) menuOnglet(e, +o.dataset.i); };
    el.addEventListener("wheel", e => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { el.scrollLeft += e.deltaY; e.preventDefault(); } }, { passive: false });
  }
  function appliquerReglages() {
    document.body.classList.toggle("sombre", S.theme === "sombre");
    chart.applyOptions(optionsTheme()); creerSerie(); donnees();
    $("#ordreRapide").style.display = S.reg.tOrdreRapide ? "" : "none";
    if ($("#horloge")) { majHorloge(); majCoin(); themeCellules(); majComparaisons(); }
    sale = true;
  }
  const IR = p => `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.5">${p}</svg>`;
  const SEL_PREC = [["auto", "Par défaut (selon l'actif)"], ["0", "1"], ["1", "0,1"], ["2", "0,01"], ["3", "0,001"], ["4", "0,0001"], ["5", "0,00001"], ["6", "0,000001"]];
  const OPTS_MT5 = [["", "La plateforme ouverte"]];
  const ONGLETS_REG = [
    ["symbole", "Symbole", IR('<path d="M8 4v3M8 17v3M16 6v3M16 15v3"/><rect x="5.5" y="7" width="5" height="10"/><rect x="13.5" y="9" width="5" height="6"/>'), [
      ["t", "Bougies"], ["chk2", "Corps", "corps", "corpsH", "corpsB"], ["chk2", "Bordures", "bord", "bordH", "bordB"], ["chk2", "Mèches", "meche", "mecheH", "mecheB"],
      ["chk", "Colorer les bougies selon la clôture précédente", "clotPrec"],
      ["t", "Données"], ["sel", "Précision des prix", "precision", SEL_PREC],
      ["sel", "Fuseau horaire", "S.fuseau", [["local", "Heure de ce PC"], ["utc", "UTC"], ["ny", "New York"], ["paris", "Paris"]]],
      ["txt", "Les graphiques sont dessinés uniquement avec les cotations du marché réel : flux en direct d'un courtier (forex, or, argent, platine, palladium, indices, dollar DXY, indices synthétiques), Binance pour la crypto, et Dukascopy (banque suisse) pour l'historique ancien. Jamais Yahoo. Les actifs sans cotation réelle sont masqués.", "", "admin"],
      ["chk", "Utiliser MetaTrader 5 s'il est ouvert (bougies de votre broker)", "mt5", "admin"],
      ["sel", "Courtier MetaTrader", "mt5t", OPTS_MT5, "admin"],
      ["txt", "Une plateforme MetaTrader 5 par courtier (Pepperstone, IC Markets, FXCM, Forex.com…) : installez celle du courtier avec un compte démo gratuit, ouvrez-la, puis choisissez-la ici. MetaTrader reste la source principale quand il est coché.", "", "admin"],
      ["txt", "Sans MetaTrader : le flux réel du courtier Deriv (gratuit, sans compte), Binance et Dukascopy. MetaTrader n'est jamais lancé par l'application.", "", "admin"],
      ["txt", "Deriv donne les vraies bougies de 32 actifs sur 44 (forex, or, argent, platine, indices US, DAX, FTSE, Nikkei ; la crypto vient de Binance), mises à jour toutes les 3 secondes, avec 1 an d'historique. Les autres actifs et l'historique plus ancien viennent des sources gratuites.", "", "admin"],
      ["txt", '<button class="gros gris" id="bOanda" type="button">Données OANDA (jeton personnel)…</button> Si OANDA est disponible dans votre pays.', "", "admin"]]],
    ["etat", "Ligne d'état", IR('<path d="M4 6h16M4 12h10M4 18h13"/>'), [
      ["t", "Symbole"], ["chk", "Nom de l'actif et unité de temps", "lTitre"], ["chk", "Source des données", "lSource"], ["chk", "Valeurs O H B C", "lOHLC"],
      ["chk", "Variation de la bougie", "lVar"], ["chk", "Volume", "lVol"],
      ["t", "Indicateurs"], ["chk", "Noms et paramètres", "lIndTitres"], ["chk", "Valeurs", "lIndValeurs"]]],
    ["echelles", "Échelles et lignes", IR('<path d="M18 3v18M18 7h3M18 12h3M18 17h3M3 15l5-5 4 3 4-6"/>'), [
      ["t", "Échelle des prix"], ["sel", "Mode", "S.echelle", [["0", "Normale"], ["1", "Logarithmique"], ["2", "Pourcentage"], ["3", "Indexée à 100"]]],
      ["chk", "Inverser l'échelle", "S.inverse"],
      ["t", "Lignes et étiquettes"], ["chk", "Ligne du dernier prix", "ligneDernier"], ["chk", "Étiquette du dernier prix", "etiqDernier"],
      ["chk", "Compte à rebours de la bougie", "S.rebours"], ["chk", "Valeurs des indicateurs sur l'échelle", "etiqInd"], ["chk", "Prix des dessins sur l'échelle", "etiqDessins"],
      ["t", "Marges"], ["num", "Marge en haut", "margeHaut", 0, 40, "%"], ["num", "Marge en bas", "margeBas", 0, 40, "%"], ["num", "Espace à droite", "margeDroite", 0, 200, "bougies"]]],
    ["toile", "Toile", IR('<rect x="3" y="4" width="18" height="14" rx="1"/><path d="M3 14l5-4 4 3 3-2 6 4M8 21h8"/>'), [
      ["t", "Fond"], ["sel", "Thème", "S.theme", [["clair", "Clair"], ["sombre", "Sombre"]]],
      ["sel", "Fond", "fondType", [["uni", "Couleur unie"], ["degrade", "Dégradé"]]], ["col", "Couleur du fond", "fond", "fond2"],
      ["t", "Grille"], ["chkc", "Lignes verticales", "grilleV", "grilleVC"], ["chkc", "Lignes horizontales", "grilleH", "grilleHC"],
      ["t", "Curseur"], ["col", "Couleur", "curseurC"], ["sel", "Style", "curseurStyle", [["0", "Plein"], ["1", "Pointillé"], ["2", "Tirets"], ["3", "Longs tirets"]]],
      ["t", "Filigrane"], ["chkc", "Actif et unité de temps au centre", "S.filigrane", "filigraneC"],
      ["t", "Échelles"], ["col", "Texte", "texteC"], ["num", "Taille du texte", "taille", 9, 18, "px"], ["col", "Lignes des échelles", "bordC"]]],
    ["trading", "Trading", IR('<path d="M4 17l5-5 4 3 7-8M15 7h5v5"/>'), [
      ["t", "Graphique"], ["chk", "Boutons Vendre / Acheter sur le graphique", "tOrdreRapide"], ["chk", "Positions et ordres sur le graphique (entrée, stop, objectif)", "tPositions"],
      ["t", "Exécution"], ["chk", "Demander confirmation avant de fermer une position", "tConfirmer"], ["chk", "Son à la clôture d'une position", "tSon"],
      ["txt", "Les positions restent simulées : aucun ordre réel n'est envoyé."]]],
    ["alertes", "Alertes", IR('<circle cx="12" cy="13" r="7"/><path d="M12 9v4l3 2M5 4L2 7M19 4l3 3"/>'), [
      ["t", "Sur le graphique"], ["chkc", "Lignes des alertes", "aLignes", "aCouleur"],
      ["t", "Quand une alerte se déclenche"], ["chk", "Jouer un son", "aSon"], ["chk", "Notification Windows", "aNotif"], ["chk", "Supprimer l'alerte une fois déclenchée", "aSupprAuto"]]],
    ["evenements", "Événements", IR('<rect x="4" y="5" width="16" height="15" rx="1"/><path d="M4 10h16M8 3v4M16 3v4"/>'), [
      ["t", "Calendrier économique"], ["chk", "Afficher les annonces économiques des devises de l'actif", "evEco"],
      ["chk", "Impact fort", "evFort"], ["chk", "Impact moyen", "evMoyen"], ["chk", "Impact faible", "evFaible"],
      ["txt", "Pastilles en bas du graphique ; survolez-les pour voir l'heure, le réel, le prévu et le précédent. En replay, les annonces futures sont cachées."],
      ["t", "Séances"], ["chk", "Séparateurs de jours", "evSeparateurs"]]],
  ];
  const valReg = k => k === "tr" ? G.regTR !== false : k === "mt5" ? !!G.regMT5 : k === "mt5t" ? (G.regMT5T || "") : k === "deriv" ? G.regDeriv !== false : k.startsWith("S.") ? S[k.slice(2)] : S.reg[k];
  function ligneReg(l) {
    const [ty, lib, k, a, b] = l;
    const cb = x => `<input type="checkbox" data-k="${x}" ${valReg(x) ? "checked" : ""}>`, co = x => `<input type="color" data-k="${x}" value="${esc(valReg(x))}" title="Couleur">`;
    switch (ty) {
      case "t": return `<div class="reg-titre">${lib}</div>`;
      case "txt": return `<p class="reg-note">${lib}</p>`;
      case "chk": return `<label class="reg-ligne">${cb(k)}<span>${lib}</span></label>`;
      case "chkc": return `<div class="reg-ligne"><label>${cb(k)}<span>${lib}</span></label><span class="flex"></span>${co(a)}</div>`;
      case "chk2": return `<div class="reg-ligne"><label>${cb(k)}<span>${lib}</span></label><span class="flex"></span>${co(a)}${co(b)}</div>`;
      case "col": return `<div class="reg-ligne"><span>${lib}</span><span class="flex"></span>${co(k)}${a && (a !== "fond2" || S.reg.fondType === "degrade") ? co(a) : ""}</div>`;
      case "sel": return `<div class="reg-ligne"><span>${lib}</span><span class="flex"></span><select data-k="${k}">${a.map(([v, t]) => `<option value="${v}" ${String(valReg(k)) === v ? "selected" : ""}>${t}</option>`).join("")}</select></div>`;
      case "num": return `<div class="reg-ligne"><span>${lib}</span><span class="flex"></span><input type="number" data-k="${k}" min="${a}" max="${b}" value="${valReg(k)}"><span class="unite">${l[5] || ""}</span></div>`;
    }
    return "";
  }
  function rendreReglages() {
    const o = ONGLETS_REG.find(x => x[0] === S.ongletReg) || ONGLETS_REG[0];
    $("#regOnglets").innerHTML = ONGLETS_REG.map(x => `<button data-onglet="${x[0]}" class="${x === o ? "actif" : ""}">${x[2]}<span>${x[1]}</span></button>`).join("");
    $("#regCorps").innerHTML = o[3].filter(l => G.admin !== false || (l[3] !== "admin" && l[4] !== "admin")).map(ligneReg).join("");
  }
  const instantane = () => JSON.stringify({ reg: S.reg, theme: S.theme, fuseau: S.fuseau, echelle: S.echelle, inverse: S.inverse, rebours: S.rebours, filigrane: S.filigrane });
  function restaurer(json) { const o = JSON.parse(json); Object.assign(S, o); S.reg = Object.assign(REG_DEF(S.theme), o.reg); }
  async function ouvrirReglages(onglet) {
    if (onglet) S.ongletReg = onglet;
    G.regAvant = instantane();
    try { const c = await api("/api/config"); G.regMT5 = G.regMT5Avant = !!c.metatrader; G.regDeriv = G.regDerivAvant = c.deriv !== false;
      G.regMT5T = G.regMT5TAvant = c.mt5_terminal || ""; G.regTR = G.regTRAvant = c.temps_reel_seul !== false; OPTS_MT5.splice(1, OPTS_MT5.length, ...(c.terminaux || []).map(t => [t.id, t.nom])); } catch (e) { G.regMT5 = G.regMT5Avant = false; G.regDeriv = G.regDerivAvant = true; }
    rendreReglages(); $("#regModeles").classList.remove("ouvert"); $("#dlgReg").classList.add("ouvert");
  }
  function annulerReglages() {
    if (G.regAvant) { restaurer(G.regAvant); G.regAvant = null; appliquerReglages(); }
    $("#dlgReg").classList.remove("ouvert");
  }
  async function validerReglages() {
    G.regAvant = null; sauverPrefs(); $("#dlgReg").classList.remove("ouvert");
    if (G.admin !== false && G.regDeriv !== G.regDerivAvant && G.regMT5 === G.regMT5Avant) {
      await api("/api/config", { deriv: G.regDeriv });
      toast(G.regDeriv ? "Deriv activé : cotations réelles." : "Deriv désactivé : sources gratuites (Yahoo, Binance, Dukascopy).");
      if (G.mode === "direct") { await charger(); demarrerDirect(); } G.cells.forEach(chargerCellule);
    }
    if (G.admin !== false && G.regTR !== G.regTRAvant && G.regTR !== undefined) {
      await api("/api/config", { temps_reel_seul: G.regTR }); G.regTRAvant = G.regTR;
      try { G.catalogue = (await api("/api/catalogue")).actifs || []; } catch (e) { /* rien */ }
      toast(G.regTR ? "Uniquement le temps réel : les actifs sans temps réel sont masqués." : "Tous les actifs sont affichés (certains viennent de Yahoo, parfois en différé).");
      if (G.regTR && !G.catalogue.some(x => x.code === S.actif)) { S.actif = "EURUSD"; sauverPrefs(); }
      charger();
    }
    if (G.admin !== false && (G.regMT5T || "") !== (G.regMT5TAvant || "")) {
      await api("/api/config", { mt5_terminal: G.regMT5T || "" }); G.regMT5TAvant = G.regMT5T;
      toast("Courtier MetaTrader : " + ((OPTS_MT5.find(o => o[0] === G.regMT5T) || [, ""])[1]));
    }
    if (G.admin !== false && G.regMT5 !== G.regMT5Avant) {
      await api("/api/config", { metatrader: G.regMT5, deriv: G.regDeriv });
      toast(G.regMT5 ? "MetaTrader 5 sera utilisé s'il est ouvert." : "MetaTrader 5 n'est plus utilisé : flux réel Deriv, Binance et Dukascopy.");
      if (G.mode === "direct") { await charger(); demarrerDirect(); }
    }
  }
  const lireModeles = () => { try { return JSON.parse(localStorage.getItem("mbgModeles") || "{}"); } catch (e) { return {}; } };
  function menuModeles() {
    const m = lireModeles(), noms = Object.keys(m);
    $("#regModeles .pop").innerHTML = `<button data-mod-act="sauver">Enregistrer les réglages comme modèle…</button><button data-mod-act="defaut">Revenir aux réglages par défaut</button>
      ${noms.length ? `<div class="titre-pop">Mes modèles</div>` + noms.map(n => `<div class="mod-ligne"><button data-mod="${esc(n)}">${esc(n)}</button><button class="suppr" data-mod-suppr="${esc(n)}" title="Supprimer ce modèle">✕</button></div>`).join("") : ""}`;
  }
  // ================================================================== partage en réseau local (administrateur)
  const dateCourte = t => t ? new Date(t * 1000).toLocaleString(LOC, { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : "—";
  async function majPartage() {
    let e; try { e = await api("/api/partage"); } catch (x) { return; }
    if (e.erreur && !e.codes) return;
    $("#partActif").checked = e.actif;
    const TYPES_J = { connexion: ["Connexion", VERT], code_inconnu: ["Mauvais code", ORANGE], code_refuse: ["Code refusé", ORANGE], code_repasse: ["Code repassé", ROUGE],
      admin_refuse: ["Admin refusé", ROUGE], admin_invite: ["Invité hors droits", ROUGE], traversee: ["Lecture de fichiers", ROUGE],
      jeton_copie: ["Connexion recopiée", ROUGE], bloque: ["Blocage", ROUGE], debit: ["Trop de requêtes", ROUGE], origine: ["Autre site refusé", ROUGE],
      bug: ["Bug du logiciel", ROUGE], bug_page: ["Bug de la page", ROUGE], panne: ["Panne", ROUGE], retabli: ["Rétabli", VERT], alerte_test: ["Alerte d'essai", BLEU], intrusion: ["Adresse détournée", ROUGE] };
    const jr = e.journal || [], alertes = jr.filter(x => !["connexion", "retabli", "alerte_test"].includes(x.type) && Date.now() / 1000 - x.t < 86400).length;
    const sv = e.surveillance || {};
    $("#survAlertes").checked = sv.alertes !== false;
    $("#survEtat").textContent = (sv.pannes && sv.pannes.length ? "⚠ Panne en cours. " : "") + (sv.telegram ? "Telegram relié." : "Telegram non relié sur ce PC : les alertes restent dans ce journal.");
    $("#journalNb").textContent = alertes ? alertes : ""; $("#journalNb").style.display = alertes ? "" : "none";
    $("#partJournalTab").innerHTML = jr.length ? `<tr><th>Quand</th><th>Événement</th><th>Appareil</th><th>Détail</th></tr>` + jr.map(x => { const t = TYPES_J[x.type] || [x.type, "inherit"];
      return `<tr><td>${dateCourte(x.t)}</td><td style="color:${t[1]}"><b>${esc(t[0])}</b></td><td><code>${esc(x.ip)}</code></td><td>${esc(x.detail)}</td></tr>`; }).join("")
      : `<tr><td class="discret">Rien à signaler.</td></tr>`;
    $("#partEtat").textContent = !e.actif ? "Désactivé : personne d'autre ne peut se connecter." : e.en_ligne ? `Actif : les invités se connectent sur le port ${e.port}.` : "⚠ " + (e.erreur || "port indisponible");
    $("#partAdresses").innerHTML = e.actif ? `<div class="discret">Adresse à donner aux invités (même Wi-Fi ou même box) :</div>` +
      (e.adresses.length ? e.adresses.map(ip => `<div class="part-url"><code>http://${ip}:${e.port}</code><button class="gros gris" data-copier="http://${ip}:${e.port}">Copier</button></div>`).join("")
        : `<div class="discret">Aucune adresse réseau trouvée : ce PC est-il connecté au Wi-Fi ?</div>`) : "";
    $("#partCodes").innerHTML = e.codes.length ? `<tr><th>Nom</th><th>Code</th><th>État</th><th>Dernière visite</th><th></th></tr>` + e.codes.map(c => {
      const etat = c.revoque ? `<span style="color:${ROUGE}">Révoqué</span>` : c.expire_deja ? `<span style="color:${ROUGE}">Expiré</span>`
        : c.utilise ? `<span style="color:${VERT}">Actif sur un appareil</span>${c.ip ? ` <span class="discret">(${esc(c.ip)})</span>` : ""}` : "Pas encore utilisé";
      return `<tr><td><b>${esc(c.nom)}</b>${c.expire ? `<br><span class="discret">jusqu'au ${dateCourte(c.expire)}</span>` : ""}</td><td><code>••••-••${esc(c.indice)}</code></td><td>${etat}</td>
        <td>${dateCourte(c.vu_le)}</td><td class="part-actions">${c.utilise && !c.revoque ? `<button data-p-act="liberer" data-id="${c.id}" title="Autoriser ce code sur un nouvel appareil">Libérer</button>` : ""}
        ${!c.revoque ? `<button data-p-act="revoquer" data-id="${c.id}">Révoquer</button>` : ""}<button data-p-act="supprimer" data-id="${c.id}">Supprimer</button></td></tr>`;
    }).join("") : `<tr><td class="discret">Aucun code. Créez-en un par personne.</td></tr>`;
  }

  // envoi du logiciel à installer (propriétaire)
  async function majEnvoi() {
    let r; try { r = await api("/api/licence/emises"); } catch (e) { return; }
    const cles = r.cles || [];
    $("#envCles").innerHTML = cles.length ? `<tr><th>Nom</th><th>Code machine</th><th>Créée le</th><th>Fin</th></tr>` + cles.map(c => `<tr><td><b>${esc(c.nom)}</b></td><td><code>${esc(c.machine)}</code></td>
      <td>${esc((c.cree || c.debut || "").replace("T", " "))}</td><td>${c.expire ? esc(c.expire) : "sans limite"}${c.expire && c.expire < new Date().toISOString().slice(0, 10) ? ` <span style="color:${ROUGE}">(expirée)</span>` : ""}</td></tr>`).join("")
      : `<tr><td class="discret">Aucune clé créée.</td></tr>`;
  }
  function brancherEnvoi() {
    $("#survAlertes").onchange = async e => { try { await api("/api/surveillance", { alertes: e.target.checked }); toast(e.target.checked ? "Alertes Telegram activées." : "Alertes Telegram coupées (le journal continue)."); } catch (x) { /* rien */ } };
    $("#survEssai").onclick = async () => { const r = await api("/api/surveillance", { essai: true }).catch(() => ({})); toast(r.ok ? "Alerte d'essai envoyée sur Telegram." : "⚠ " + (r.message || "envoi impossible"), !!r.ok); majPartage(); };
    $("#survVerifier").onclick = async () => {
      $("#survEtat").textContent = "Vérification en cours…";
      const r = await api("/api/surveillance", { verifier: true }).catch(() => ({}));
      const noms = { flux: "temps réel", yahoo: "Yahoo", binance: "crypto", disque: "disque", maboussole: "MaBoussole" };
      await majPartage();
      $("#survEtat").textContent = r.verif ? Object.entries(r.verif).map(([k, ok]) => (ok ? "✓ " : "✗ ") + (noms[k] || k)).join("   ") : "⚠ vérification impossible";
    };
    $$("[data-p-onglet]").forEach(b => b.onclick = () => {
      $$("[data-p-onglet]").forEach(x => x.classList.toggle("actif", x === b));
      $("#partReseau").style.display = b.dataset.pOnglet === "reseau" ? "" : "none"; $("#partEnvoi").style.display = b.dataset.pOnglet === "envoi" ? "" : "none";
      $("#partJournal").style.display = b.dataset.pOnglet === "journal" ? "" : "none"; if (b.dataset.pOnglet === "journal") majPartage();
      if (b.dataset.pOnglet === "envoi") majEnvoi();
    });
    $("#envPaquet").onclick = async () => {
      $("#envPaquet").disabled = true; $("#envPaquet").textContent = "Création…";
      const r = await api("/api/licence/paquet", {}).catch(() => ({ ok: false, message: "serveur injoignable" }));
      $("#envPaquet").disabled = false; $("#envPaquet").textContent = "Créer le fichier .zip";
      if (!r.ok) { toast("⚠ " + (r.message || "échec"), false); return; }
      $("#envResultat").style.display = "";
      $("#envResultat").innerHTML = `<div>Fichier créé (${r.fichiers} fichiers, ${r.taille_ko} Ko) :</div><code>${esc(r.chemin)}</code>
        <button class="gros gris" id="envOuvrir">Ouvrir le dossier</button><div class="discret">Envoyez ce fichier à la personne (WhatsApp, Telegram, e-mail, clé USB…).</div>`;
      $("#envOuvrir").onclick = () => api("/api/ouvrir-dossier", { chemin: r.chemin });
    };
    const majTypeLimite = () => {
      const t = $("#envType").value;
      $("#envJours").style.display = t === "jours" ? "" : "none"; $("#envDate").style.display = t === "date" ? "" : "none";
      $("#envUtil").style.display = t === "utilisations" ? "" : "none";
      $("#envUnite").textContent = { jours: "jours", date: "", utilisations: "ouvertures du logiciel", aucune: "" }[t];
    };
    $("#envType").onchange = majTypeLimite; majTypeLimite();
    api("/api/telechargement").then(t => {
      $("#dlWindows").classList.toggle("indispo", !t.windows); $("#dlMac").classList.toggle("indispo", !t.mac);
      $("#dlEtat").textContent = [t.windows ? "Windows : " + t.windows.taille_mo + " Mo, fabriqué le " + t.windows.date : "Windows : pas encore fabriqué (commande dans « LISEZ-MOI_VERSION_INSTALLABLE.txt »)",
        t.mac ? "Mac : " + t.mac.taille_mo + " Mo, fabriqué le " + t.mac.date : "Mac : à fabriquer sur un Mac (même fichier)"].join(" · ");
      $("#statsTelech").textContent = "téléchargements depuis le site : " + (t.telechargements == null ? "indisponible pour l'instant" : t.telechargements.toLocaleString(LOC));
      if (t.tableau) $("#statsTableau").href = t.tableau;
    }).catch(() => {});
    $("#envCle").onclick = async () => {
      const t = $("#envType").value, corps = { nom: $("#envNom").value, machine: $("#envMachine").value.trim().toUpperCase() };
      if (t === "jours") corps.jours = +$("#envJours").value;
      if (t === "date") { if (!$("#envDate").value) { toast("⚠ Choisissez la date d'expiration.", false); return; } corps.expire_le = $("#envDate").value; }
      if (t === "utilisations") corps.utilisations = +$("#envUtil").value;
      const r = await api("/api/licence/emettre", corps);
      if (!r.ok) { toast("⚠ " + (r.message || "échec"), false); return; }
      $("#envCleRes").style.display = "";
      $("#envCleRes").innerHTML = `<div>Clé d'activation de <b>${esc(r.licence.nom)}</b> (${esc(r.licence.machine)}, ${[r.licence.expire ? "jusqu'au " + esc(r.licence.expire) : "", r.licence.u ? r.licence.u + " utilisations" : ""].filter(Boolean).join(", ") || "sans limite"}) :</div>
        <textarea readonly class="cle-activation">${esc(r.cle)}</textarea><button class="gros gris" data-copier="${esc(r.cle)}">Copier la clé</button>
        <div class="discret">Envoyez-la à la personne : elle la colle dans la page d'activation. Elle ne marche que sur son PC.</div>`;
      $("#envNom").value = ""; $("#envMachine").value = ""; majEnvoi();
    };
  }
  // le calendrier du propriétaire lui est réservé : retiré chez les invités et dans les copies installées ailleurs
  function retirerSMV() {
    if (INDS.smv) delete INDS.smv;
    if (S.inds.some(x => x.id === "smv")) { S.inds = S.inds.filter(x => x.id !== "smv"); sauverPrefs(); }
    G.smv = [];
  }
  function brancherPartage() {
    brancherEnvoi();
    $("#bPartage").onclick = () => { $("#partNouveauCode").style.display = "none"; $("#dlgPartage").classList.add("ouvert"); majPartage(); };
    $("#partFermer").onclick = () => $("#dlgPartage").classList.remove("ouvert");
    $("#partActif").onchange = async () => {
      const r = await api("/api/partage", { action: $("#partActif").checked ? "activer" : "desactiver" });
      if (!r.ok) toast("⚠ " + (r.message || "échec"), false);
      else if ($("#partActif").checked) toast("Partage activé. Si Windows demande l'autorisation du pare-feu, cochez « Réseaux privés » puis Autoriser.");
      majPartage();
    };
    $("#partCreer").onclick = async () => {
      const r = await api("/api/partage", { action: "creer", nom: $("#partNom").value, jours: +$("#partJours").value });
      if (!r.ok) { toast("⚠ " + (r.message || "échec"), false); return; }
      const c = r.code; $("#partNom").value = "";
      $("#partNouveauCode").style.display = "";
      $("#partNouveauCode").innerHTML = `<div>Code de <b>${esc(c.nom)}</b> :</div><div class="gros-code">${esc(c.code)}</div>
        <button class="gros gris" data-copier="${esc(c.code)}">Copier</button><div class="discret">Notez-le maintenant : il ne sera plus jamais affiché (seules ses 2 dernières lettres restent visibles).</div>`;
      majPartage();
    };
    $("#dlgPartage").addEventListener("click", async ev => {
      const cp = ev.target.closest("[data-copier]");
      if (cp) { try { await navigator.clipboard.writeText(cp.dataset.copier); toast("Copié : " + cp.dataset.copier); } catch (x) { await saisir("Copiez :", cp.dataset.copier, { ok: "Fermer", annuler: "Fermer" }); } return; }
      const b = ev.target.closest("[data-p-act]"); if (!b) return;
      const a = b.dataset.pAct, msg = { revoquer: "Révoquer ce code ? La personne perd l'accès tout de suite.", supprimer: "Supprimer ce code ? La personne perd l'accès.", liberer: "Libérer ce code ? L'appareil actuel sera déconnecté et le code pourra être utilisé sur un nouvel appareil." }[a];
      if (!await demander(msg, { ok: "Confirmer" })) return;
      const r = await api("/api/partage", { action: a, id: b.dataset.id });
      if (!r.ok) toast("⚠ " + (r.message || "échec"), false);
      majPartage();
    });
    api("/api/moi").then(m => {
      G.admin = !!m.admin;
      if (m.smv === false) { retirerSMV(); if (G.bars.length) donnees(); }
      else if (m.smv_nom && INDS.smv) { INDS.smv.nom = m.smv_nom; INDS.smv.court = m.smv_nom.replace(/^Calendrier algo /, "Calendrier "); }
      $("#bPartage").style.display = m.peut_partager ? "" : "none";
      $("#ongletEnvoi").style.display = m.proprietaire ? "" : "none";
      if (!m.admin) { $("#badgeInvite").style.display = ""; $("#badgeInvite").textContent = "Invité · " + (m.nom || ""); $("#bInstaller").style.display = "none"; }
      else { setTimeout(() => verifierMaj(false), 8000); setInterval(() => verifierMaj(false), 6 * 3600e3); majBoutonCompte(); }
      if (!m.admin) $("#bCompte").style.display = "none";
    }).catch(() => {});
  }

  // ================================================================== menu du compte (comme TradingView) : le compte = l'e-mail du paiement, sans mot de passe
  const SITE_MBG = "https://babaaariel-beep.github.io/maboussole-site/";
  const IC_COMPTE = {
    accueil: "M4 11l8-7 8 7v9h-5v-6H9v6H4z", aide: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.7M12 17h.01",
    support: "M4 6h16v12H4zM4 7l8 6 8-6", nouveau: "M12 3l2.4 5.3 5.6.6-4.2 3.8 1.2 5.6L12 15.5 7 18.3l1.2-5.6L4 8.9l5.6-.6z",
    maj: "M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5", reglages: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1",
    panneau: "M4 4h16v16H4zM9 4v16", theme: "M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z", langue: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18",
    raccourcis: "M3 7h18v10H3zM7 11h.01M11 11h.01M15 11h.01M8 14h8", deco: "M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"
  };
  const icCompte = k => `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="${IC_COMPTE[k]}"/></svg>`;
  let popCompte = null;
  function fermerCompte() { if (popCompte) { popCompte.remove(); popCompte = null; } }
  function initialeCompte(l) { const t = (l.email || l.nom || (l.proprietaire ? "P" : "?")).trim(); return (t[0] || "?").toUpperCase(); }
  async function majBoutonCompte() {
    let l = null; try { l = await api("/api/licence"); } catch (e) { return; }
    if (!l || l.erreur) { $("#bCompte").style.display = "none"; return; }
    G.compte = l; $("#bCompte").querySelector(".avatar").textContent = initialeCompte(l);
    $("#bCompte").title = "Mon compte" + (l.email ? " : " + l.email : l.nom ? " : " + l.nom : "");
  }
  function appliquerPanneau() {
    const o = $("#outils"); if (!o) return;
    o.style.display = S.masquerPanneau ? "none" : "";
    setTimeout(() => { window.dispatchEvent(new Event("resize")); tailleCalque(); sale = true; }, 30);
  }
  async function ouvrirCompte() {
    if (popCompte) { fermerCompte(); return; }
    let l = G.compte || {}; try { l = await api("/api/licence"); G.compte = l; } catch (e) { /* on garde le dernier état connu */ }
    const nom = l.email || l.nom || (l.proprietaire ? "Propriétaire" : "Mon compte");
    const fr = iso => { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || ""); return m ? `${m[3]}/${m[2]}/${m[1]}` : iso; };
    const sous = l.proprietaire ? "Propriétaire · accès illimité" : l.essai ? `Essai gratuit · ${l.heures_restantes ?? "?"} h restantes`
      : l.expire ? `Accès jusqu'au ${fr(l.expire)}${l.jours_restants != null ? ` (${l.jours_restants} j)` : ""}` : l.ok ? "Accès illimité" : "";
    const ligne = (k, t, plus = "") => `<button data-c="${k}">${icCompte(k)}<span>${t}</span>${plus}</button>`;
    const bascule = (k, t, on) => `<label class="pc-bascule">${icCompte(k)}<span>${t}</span><input type="checkbox" data-c="${k}" ${on ? "checked" : ""}><i></i></label>`;
    popCompte = document.createElement("div"); popCompte.className = "pop-compte"; popCompte.setAttribute("role", "menu");
    popCompte.innerHTML = `<div class="pc-tete"><span class="avatar grand">${esc(initialeCompte(l))}</span><div class="pc-id"><b title="${esc(nom)}">${esc(nom)}</b>
        ${l.email && l.nom ? `<span>${esc(l.nom)}</span>` : ""}<span>${esc(sous)}</span></div></div>
      ${!l.email && l.copie && !l.proprietaire && !l.essai ? `<div class="pc-note">Les clés achetées sur le site affichent ici l'e-mail du paiement.</div>` : ""}
      ${ligne("accueil", "Accueil")}${ligne("aide", "Centre d'aide")}${ligne("support", "Demandes au support")}
      ${ligne("nouveau", "Quoi de neuf")}${ligne("maj", "Rechercher une mise à jour")}<hr>
      ${ligne("reglages", "Paramètres")}${bascule("panneau", "Panneau de dessin", !S.masquerPanneau)}${bascule("theme", "Thème sombre", S.theme === "sombre")}
      <label class="pc-ligne pc-langue">${icCompte("langue")}<span>Langue</span><select data-c="langue" data-notr><option value="fr" ${window.MBG_LANGUE !== "en" ? "selected" : ""}>Français</option><option value="en" ${window.MBG_LANGUE === "en" ? "selected" : ""}>English</option></select></label>
      ${ligne("raccourcis", "Raccourcis clavier", `<span class="discret pc-touche">?</span>`)}
      ${l.copie && !l.proprietaire && l.ok ? `<hr>${ligne("deco", "Déconnexion")}` : ""}`;
    document.body.appendChild(popCompte);
    popCompte.addEventListener("mousedown", e => e.stopPropagation());
    popCompte.onchange = e => {
      const k = e.target.dataset.c;
      if (k === "panneau") { S.masquerPanneau = !e.target.checked; sauverPrefs(); appliquerPanneau(); }
      if (k === "theme") { S.theme = e.target.checked ? "sombre" : "clair"; sauverPrefs(); appliquerReglages(); }
      if (k === "langue" && window.mbgChoisirLangue) window.mbgChoisirLangue(e.target.value);
    };
    popCompte.onclick = async e => {
      const b = e.target.closest("button[data-c]"); if (!b) return;
      const k = b.dataset.c; fermerCompte();
      if (k === "accueil") window.open(SITE_MBG, "_blank", "noopener");
      else if (k === "aide") window.open(SITE_MBG + "#questions", "_blank", "noopener");
      else if (k === "support") location.href = "mailto:babaaariel@gmail.com?subject=" + encodeURIComponent("Support MaBoussole Graphiques") + "&body=" + encodeURIComponent(`\n\n---\nCompte : ${l.email || l.nom || ""}\nCode du PC : ${l.machine || ""}`);
      else if (k === "nouveau") quoiDeNeuf();
      else if (k === "maj") verifierMaj(true);
      else if (k === "reglages") ouvrirReglages();
      else if (k === "raccourcis") afficherRaccourcis();
      else if (k === "deco") {
        if (!await demander("Se déconnecter de ce PC ?\n\nPour revenir, il suffira de recoller votre clé d'activation (celle reçue par e-mail) : elle reste liée à ce PC.", { ok: "Se déconnecter", titre: "Déconnexion" })) return;
        let r; try { r = await api("/api/licence/deconnexion", {}); } catch (x) { r = { ok: false, message: "serveur injoignable" }; }
        if (r.ok) location.href = "/activation"; else toast("⚠ " + (r.message || "échec"), false);
      }
    };
  }
  async function quoiDeNeuf() {
    let loc = {}; try { loc = await (await fetch("/version.json", { cache: "no-store" })).json(); } catch (e) { /* pas de numéro */ }
    const m = G.maj || await lireMaj(false) || {};
    const blocs = [];
    if (m.dispo && (m.nouveautes || []).length) blocs.push(`Nouvelle version disponible (${m.date || m.distante}) :\n` + m.nouveautes.map(n => "• " + n).join("\n"));
    if ((loc.nouveautes || []).length) blocs.push(`Votre version${loc.date ? " (" + loc.date + ")" : ""} :\n` + loc.nouveautes.map(n => "• " + n).join("\n"));
    if (!blocs.length) blocs.push("Aucune note pour cette version.");
    const r = await boiteDialogue(blocs.join("\n\n"), { titre: "Quoi de neuf", ok: m.dispo ? "Mettre à jour" : "Fermer", annuler: m.dispo ? "Plus tard" : null, danger: false });
    if (r && m.dispo) montrerBandeauMaj(m, true);
  }
  document.addEventListener("mousedown", e => { if (popCompte && !(e.target.closest && e.target.closest("#bCompte"))) fermerCompte(); });

  // ================================================================== nouvelle version installée sur ce PC (serveur redémarré) : la page se recharge toute seule
  let versionPage = null;
  async function surveillerVersionPage() {
    let v = null; try { const r = await fetch("/api/ping", { cache: "no-store" }); if (r.ok) { const j = await r.json(); v = (j.version || "") + "|" + (j.appli || ""); } } catch (e) { return; }
    if (!v) return;
    if (versionPage == null) { versionPage = v; return; }
    if (v === versionPage) return;
    const occupe = G.drag || G.crea || document.querySelector(".boite-fond, #dlgDessin.ouvert, #dlgParam.ouvert, .ouvert.fenetre, .pop-compte") || editeur;
    if (occupe) return;                                     // on attend que la personne ait fini
    toast("Nouvelle version installée : rechargement…"); setTimeout(() => location.reload(), 700);
  }
  setTimeout(surveillerVersionPage, 3000); setInterval(surveillerVersionPage, 20000);

  // ================================================================== mise à jour : message dans l'application quand une nouvelle version est publiée
  async function lireMaj(force) {                 // sans signaler « serveur perdu » (il redémarre pendant une mise à jour)
    try { const r = await fetch("/api/maj" + (force ? "?force=1" : ""), { cache: "no-store" }); return r.ok ? await r.json() : null; } catch (e) { return null; }
  }
  async function verifierMaj(force) {
    const r = await lireMaj(force); if (!r) { if (force) toast("Impossible de vérifier : pas de connexion Internet ?", false); return null; }
    G.maj = r;
    if (r.dispo) montrerBandeauMaj(r, force);
    else if (force && r.apercu && r.distante) montrerBandeauMaj(Object.assign({}, r, { auto: false }), true, true);   // PC du propriétaire : aperçu
    else if (force) toast(r.installe === false ? "Cette copie (PC du propriétaire) est toujours à jour." : "Vous avez déjà la dernière version ✓");
    return r;
  }
  function montrerBandeauMaj(r, force, apercu) {
    try { if (!force && localStorage.getItem("mbgMajPlusTard") === r.distante) return; } catch (e) { /* rien */ }
    let el = $("#bandeauMaj"); if (!el) { el = document.createElement("div"); el.id = "bandeauMaj"; el.setAttribute("role", "dialog"); document.body.appendChild(el); }
    const notes = (r.nouveautes || []).slice(0, 8).map(n => `<li>${esc(n)}</li>`).join("");
    el.innerHTML = `<button class="maj-x" data-maj="tard" title="Plus tard">✕</button>
      ${apercu ? `<div class="maj-apercu">Aperçu : voici le message que voient vos clients quand leur version est plus ancienne que celle publiée sur le site. Votre copie, elle, se met à jour toute seule.</div>` : ""}
      <div class="maj-titre">🎉 Nouvelle version disponible${r.date ? ` <span>du ${esc(r.date)}</span>` : ""}</div>
      ${notes ? `<div class="maj-sous">Quoi de neuf :</div><ul>${notes}</ul>` : ""}
      <div class="maj-etat">${r.auto ? "La mise à jour se fait toute seule : MaBoussole redémarre en quelques secondes, vos dessins et réglages sont gardés." : "Téléchargez la nouvelle version, fermez MaBoussole puis lancez le fichier téléchargé."}</div>
      <div class="maj-barre"><i></i></div>
      <div class="maj-boutons"><button class="gros gris" data-maj="tard">Plus tard</button><button class="gros" data-maj="go">${r.auto ? "Mettre à jour" : "Télécharger"}</button></div>`;
    el.classList.add("ouvert");
    el.onclick = async e => {
      const b = e.target.closest("[data-maj]"); if (!b) return;
      if (b.dataset.maj === "tard") { try { localStorage.setItem("mbgMajPlusTard", r.distante || ""); } catch (x) { /* rien */ } el.classList.remove("ouvert"); return; }
      if (apercu) { toast("Aperçu seulement : chez vos clients, ce bouton télécharge et installe la nouvelle version."); return; }
      if (!r.auto) { window.open(r.lien, "_blank", "noopener"); return; }
      b.disabled = true;
      let x; try { x = await api("/api/maj/installer", {}); } catch (err) { x = { ok: false, message: "serveur injoignable" }; }
      if (!x.ok) { el.querySelector(".maj-etat").textContent = "⚠ " + (x.message || "échec"); b.disabled = false; return; }
      suivreMaj(el, r.locale);
    };
  }
  async function suivreMaj(el, avant) {
    const etat = el.querySelector(".maj-etat"), barre = el.querySelector(".maj-barre"), bouton = el.querySelector('[data-maj="go"]');
    let coupe = false; barre.classList.add("visible");
    for (let i = 0; i < 900; i++) {
      await new Promise(f => setTimeout(f, 1000));
      const r = await lireMaj(false);
      if (!r) { coupe = true; etat.textContent = "Redémarrage de MaBoussole…"; continue; }      // ancien serveur arrêté, le nouveau démarre
      if (coupe || (r.locale && r.locale !== avant)) { etat.textContent = "Mise à jour terminée ✓"; barre.firstElementChild.style.width = "100%"; setTimeout(() => location.reload(), 800); return; }
      if (r.etat === "telechargement") { etat.textContent = `Téléchargement de la nouvelle version… ${r.pct} %`; barre.firstElementChild.style.width = r.pct + "%"; }
      else if (r.etat === "installation") etat.textContent = "Installation…";
      else if (r.etat === "redemarrage") etat.textContent = "Redémarrage de MaBoussole…";
      else if (r.etat === "erreur") { etat.textContent = "⚠ " + (r.message || "échec"); bouton.disabled = false; barre.classList.remove("visible"); return; }
    }
  }
  function brancherReglages() {
    brancherPartage(); brancherAnalyses(); brancherCoin(); brancherStyleDessin(); brancherMulti(); brancherOanda(); brancherOnglets();
    $("#mReglages").onclick = () => ouvrirReglages();
    $("#bCompte").onclick = () => ouvrirCompte(); appliquerPanneau();
    $("#regFermer").onclick = annulerReglages; $("#regAnnuler").onclick = annulerReglages; $("#regOk").onclick = validerReglages;
    $("#regOnglets").onclick = e => { const b = e.target.closest("[data-onglet]"); if (b) { S.ongletReg = b.dataset.onglet; rendreReglages(); } };
    const changer = e => {
      const el = e.target.closest("[data-k]"); if (!el) return;
      const k = el.dataset.k, v = el.type === "checkbox" ? el.checked : el.type === "number" ? Math.max(+el.min, Math.min(+el.max, +el.value || 0)) : el.value;
      if (k === "mt5") { G.regMT5 = v; return; }
      if (k === "mt5t") { G.regMT5T = v; return; }
      if (k === "tr") { G.regTR = v; return; }
      if (k === "deriv") { G.regDeriv = v; return; }
      if (k.startsWith("S.")) S[k.slice(2)] = v; else S.reg[k] = v;
      if (k === "S.theme") Object.assign(S.reg, TOILES[v]);
      if (k === "S.theme" || k === "fondType") rendreReglages();
      appliquerReglages();
    };
    $("#regCorps").addEventListener("change", changer);
    $("#regCorps").addEventListener("input", e => { if (e.target.type === "color") changer(e); });
    $("#regModeles > button").onclick = e => { e.stopPropagation(); menuModeles(); $("#regModeles").classList.toggle("ouvert"); };
    $("#regModeles .pop").onclick = async e => {
      const b = e.target.closest("button"); if (!b) return;
      const m = lireModeles();
      if (b.dataset.modAct === "sauver") {
        const n = ((await saisir("Nom du modèle :", "Mon modèle")) || "").trim().slice(0, 40); if (!n) return;
        m[n] = JSON.parse(instantane()); try { localStorage.setItem("mbgModeles", JSON.stringify(m)); toast(`Modèle « ${n} » enregistré.`); } catch (er) { toast("⚠ Modèle non enregistré.", false); }
      } else if (b.dataset.modAct === "defaut") {
        Object.assign(S, { echelle: 0, inverse: false, rebours: true, filigrane: true }); S.reg = REG_DEF(S.theme); appliquerReglages(); rendreReglages();
      } else if (b.dataset.mod && m[b.dataset.mod]) {
        restaurer(JSON.stringify(m[b.dataset.mod])); appliquerReglages(); rendreReglages();
      } else if (b.dataset.modSuppr) {
        if (!await demander(`Supprimer le modèle « ${b.dataset.modSuppr} » ?`)) return;
        delete m[b.dataset.modSuppr]; try { localStorage.setItem("mbgModeles", JSON.stringify(m)); } catch (er) { /* rien */ } menuModeles(); return;
      }
      $("#regModeles").classList.remove("ouvert");
    };
    $("#dlgReg").addEventListener("mousedown", e => { if (!e.target.closest("#regModeles")) $("#regModeles").classList.remove("ouvert"); });
    $("#ordreRapide").style.display = S.reg.tOrdreRapide ? "" : "none";
  }
  function brancher() {
    $("#unites").onclick = e => { if (e.target.closest("#uMenu")) { menuUnites(e); return; } const u = e.target.closest("[data-u]")?.dataset.u; if (u) changerUnite(u).then(majUnites); };
    majUnites();
    $$(".menu > .tb, .menu > button").forEach(b => b.onclick = e => { const m = b.parentElement, o = m.classList.contains("ouvert"); $$(".menu").forEach(x => x.classList.remove("ouvert")); if (!o) m.classList.add("ouvert"); e.stopPropagation(); });
    document.addEventListener("mousedown", e => {
      const c = s => !!(e.target && e.target.closest && e.target.closest(s));
      if (!c(".menu")) $$(".menu").forEach(x => x.classList.remove("ouvert"));
      if (volet && !c(".volet") && !c("[data-volet]")) fermerVolet();
    });
    $$("#mType [data-type]").forEach(b => { b.classList.toggle("actif", b.dataset.type === S.type); b.onclick = () => { S.type = b.dataset.type; sauverPrefs(); $$("#mType [data-type]").forEach(x => x.classList.toggle("actif", x === b)); creerSerie(); donnees(); $("#mType").classList.remove("ouvert"); }; });
    brancherReglages();
    $("#outils").onclick = async e => {
      const v = e.target.closest("[data-volet]"); if (v) { const g2 = v.closest(".outil-groupe"); if (volet && volet._nom === v.dataset.volet) { fermerVolet(); return; } ouvrirVolet(v.dataset.volet, g2); if (volet) volet._nom = v.dataset.volet; return; }
      const b = e.target.closest("[data-outil]"); if (b) { choisirOutil(G.outil === b.dataset.outil && b.dataset.outil !== "curseur" ? "curseur" : b.dataset.outil); return; }
      if (e.target.closest("#tDezoom")) { const r = G.zooms.pop(); if (r) chart.timeScale().setVisibleLogicalRange(r); construireOutils(); }
      if (e.target.closest("#tAimant")) { S.aimant = S.aimant ? false : "faible"; sauverPrefs(); construireOutils(); }
      if (e.target.closest("#tContinuer")) { S.continuer = !S.continuer; sauverPrefs(); construireOutils(); }
      if (e.target.closest("#tVerrou")) { S.verrou = !S.verrou; sauverPrefs(); construireOutils(); }
      if (e.target.closest("#tMasquer")) { S.masquer = !S.masquer; G.sel = -1; barreDessin(); sauverPrefs(); construireOutils(); sale = true; }
      if (e.target.closest("#tFavoris")) { S.voirFavoris = !S.voirFavoris; sauverPrefs(); construireOutils(); }
      if (e.target.closest("#tEffacer")) { if (G.dessins.length && await demander("Supprimer tous les dessins de " + S.actif + " ?")) { memoriser(); G.dessins = []; G.sel = -1; barreDessin(); sauverDessins(); sale = true; } }
    };
    $("#outils").oncontextmenu = e => { const g2 = e.target.closest(".outil-groupe[data-groupe]"); if (g2) { e.preventDefault(); ouvrirVolet(g2.dataset.groupe, g2); } };
    $("#ddModele").onclick = e => { e.stopPropagation(); menuModeleDessin(e.currentTarget, () => rendreStyleDessin()); };
    $("#barreDessin").onclick = e => {
      const b = e.target.closest("button"); if (!b) return;
      const d = G.dessins[G.sel]; if (!d) return;
      const a = b.dataset.act;
      e.stopPropagation();
      if (a === "couleur") return popBD(b, paletteBD(d.c || BLEU), v => { modifierSel(x => { x.c = v; }); });
      if (a === "couleurTexte") return popBD(b, paletteBD(d.cTx || d.c || BLEU), v => { modifierSel(x => { x.cTx = v; }); });
      if (a === "epaisseur") return popBD(b, `<div class="bd-liste">${[1, 2, 3, 4].map(w => `<button data-v="${w}" class="${(d.w && d.w !== 1.6 ? d.w : 1) === w ? "actif" : ""}"><svg viewBox="0 0 40 10" width="40" height="10"><path d="M2 5h36" stroke="currentColor" stroke-width="${w}"/></svg><span>${w}px</span></button>`).join("")}</div>`, v => modifierSel(x => { x.w = +v; }));
      if (a === "styleTrait") return popBD(b, `<div class="bd-liste">${[["0", "Trait plein", "none"], ["1", "Tirets", "6 4"], ["2", "Pointillés", "1.5 3.5"]].map(([v, t, da]) => `<button data-v="${v}" class="${String(d.s || 0) === v ? "actif" : ""}"><svg viewBox="0 0 40 10" width="40" height="10"><path d="M2 5h36" stroke="currentColor" stroke-width="2" stroke-dasharray="${da}" stroke-linecap="round"/></svg><span>${t}</span></button>`).join("")}</div>`, v => modifierSel(x => { x.s = +v; }));
      if (a === "plus") return popBD(b, `<div class="bd-liste">
          ${AVEC_TEXTE_BD(d) ? '<button data-v="texte"><span>Modifier le texte</span></button>' : ""}
          <button data-v="clone"><span>Dupliquer</span></button>
          <button data-v="masquer"><span>Masquer ce dessin</span></button>
          <button data-v="avant"><span>Mettre au premier plan</span></button>
          <button data-v="arriere"><span>Mettre à l'arrière-plan</span></button></div>`, v => {
            const x = G.dessins[G.sel]; if (!x) return;
            if (v === "texte") { if (TYPES_TEXTE.includes(x.type)) editerSel(); else ouvrirStyleDessin("texteL"); }
            if (v === "clone") { memoriser(); const cl = JSON.parse(JSON.stringify(x)); cl.id = Math.random().toString(36).slice(2, 10); cl.pts = cl.pts.map(q => ({ t: tDe(idxDe(q.t) + 5), p: q.p })); G.dessins.push(cl); G.sel = G.dessins.length - 1; sauverDessins(); barreDessin(); sale = true; }
            if (v === "masquer") { modifierSel(y => { y.cache = true; }); G.sel = -1; barreDessin(); toast("Dessin masqué : réaffichez-le depuis l'arborescence des objets (barre de droite)."); }
            if (v === "avant" || v === "arriere") { memoriser(); G.dessins.splice(G.sel, 1); if (v === "avant") { G.dessins.push(x); G.sel = G.dessins.length - 1; } else { G.dessins.unshift(x); G.sel = 0; } sauverDessins(); barreDessin(); sale = true; }
          });
      fermerPopBD();
      if (a === "lock") modifierSel(x => { x.lock = !x.lock; });
      if (a === "style") ouvrirStyleDessin();
      if (a === "modele") menuModeleDessin(b);
      if (a === "ordre") placerDepuisDessin(d);
      if (a === "alerte") {                          // alerte au prix du dernier point du dessin (comme « Ajouter une alerte » de TradingView)
        const pt = d.pts[d.pts.length - 1]; memoriser();
        const al = nouveauDessin("alerte", { t: pt.t, p: pt.p }); al.fixes = 1; G.dessins.push(al); sauverDessins(true); sale = true;
        toast("Alerte ajoutée au prix " + fp(pt.p) + ".");
      }
      if (a === "suppr") { if (supprimerSel()) toast("Dessin supprimé (Ctrl+Z pour annuler)"); }
    };
    document.addEventListener("mousedown", e => { if (!e.target.closest || (!e.target.closest("#popBD") && !e.target.closest("#barreDessin"))) fermerPopBD(); });
    $("#legende").onclick = e => {
      const lc = e.target.closest("[data-comp]"); if (lc && e.target.closest('[data-act="comp-suppr"]')) { retirerComparaison(lc.dataset.comp); return; }
      const b = e.target.closest("[data-act]"), l = e.target.closest("[data-uid]"); if (!b || !l) return;
      const ind = S.inds.find(x => x.uid === l.dataset.uid); if (!ind) return;
      if (b.dataset.act === "voir") { ind.cache = !ind.cache; }
      if (b.dataset.act === "suppr") { S.inds = S.inds.filter(x => x !== ind); }
      if (b.dataset.act === "param") { ouvrirParam(ind.uid); return; }
      sauverPrefs(); donnees();
    };
    $("#legende").ondblclick = e => { const l = e.target.closest("[data-uid]"); if (l) ouvrirParam(l.dataset.uid); };
    $("#bInd").onclick = ouvrirInd;
    $("#dlgIndFermer").onclick = fermerDlgs; $("#dlgParamFermer").onclick = fermerDlgs;
    $("#dlgIndTexte").oninput = rendreInd;
    $("#dlgIndCats").onclick = e => { const c = e.target.closest("[data-cat]"); if (c) { indCat = c.dataset.cat; rendreInd(); } };
    $("#dlgIndListe").onclick = e => { const l = e.target.closest("[data-ind]"); if (l) ajouterInd(l.dataset.ind); };
    $("#dlgParamOk").onclick = () => validerParam(false); $("#dlgParamDefaut").onclick = () => validerParam(true);
    $$(".dlg-fond").forEach(f => f.onclick = e => { if (e.target === f) fermerDlgs(); });
    $("#bAlerte").onclick = () => { choisirOutil(G.outil === "alerte" ? "curseur" : "alerte"); try { if (window.Notification && Notification.permission === "default") Notification.requestPermission(); } catch (e) { /* rien */ } };
    $("#bAlertes").onclick = () => $('.onglets-bas [data-bas="alertes"]').click();
    $("#bSymbole").onclick = () => ouvrirDlg("ouvrir");
    $("#bAjout").onclick = () => ouvrirDlg("ajouter");
    $("#dlgFermer").onclick = fermerDlgs;
    $("#dlgTexte").oninput = () => { dlgSel = 0; rendreDlg(); };
    $("#dlgTexte").onkeydown = e => {
      const res = resultatsDlg();
      if (e.key === "ArrowDown") { dlgSel = Math.min(res.length - 1, dlgSel + 1); rendreDlg(); e.preventDefault(); }
      if (e.key === "ArrowUp") { dlgSel = Math.max(0, dlgSel - 1); rendreDlg(); e.preventDefault(); }
      if (e.key === "Enter" && res[dlgSel]) choisirDlg(res[dlgSel].code);
    };
    $("#dlgCats").onclick = e => { const c = e.target.closest("[data-cat]"); if (c) { dlgCat = c.dataset.cat; rendreDlg(); } };
    $("#dlgListe").onclick = e => { const l = e.target.closest("[data-code]"); if (l) choisirDlg(l.dataset.code); };
    $("#liste").onclick = e => {
      const x = e.target.closest("[data-retire]"); if (x) { S.liste = S.liste.filter(a => a !== x.dataset.retire); sauverPrefs(); rendreListe(); return; }
      const l = e.target.closest("[data-a]"); if (l) changerActif(l.dataset.a);
    };
    $("#bAnnuler").onclick = annuler; $("#bRefaire").onclick = refaire;
    $("#bReplay").onclick = entrerReplay; $("#rChoisir").onclick = entrerReplay;
    $("#rPlay").onclick = lecture; $("#rPas").onclick = () => avancer(1); $("#rRecul").onclick = reculer;
    $("#rVitesse").value = S.vitesse; $("#rVitesse").onchange = e => { S.vitesse = +e.target.value; sauverPrefs(); if (G.play) { pause(); lecture(); } };
    $("#rAller").onclick = () => { const v = $("#rDate").value; if (v) demarrerReplay(new Date(v).getTime() / 1000); };
    $("#rQuitter").onclick = quitterReplay;
    $("#qAchat").onclick = () => placer(1); $("#qVente").onclick = () => placer(-1);
    $("#oAchat").onclick = () => placer(1); $("#oVente").onclick = () => placer(-1);
    $("#bPlein").onclick = () => document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen().catch(() => toast("Plein écran refusé", false));
    $("#bAllerDate").onclick = () => {
      const i = document.createElement("input"); i.type = "datetime-local"; i.style.position = "fixed"; i.style.opacity = "0"; i.style.bottom = "40px"; i.style.right = "90px"; document.body.appendChild(i);
      i.onchange = () => { if (i.value) allerDate(new Date(i.value).getTime() / 1000); i.remove(); }; i.onblur = () => setTimeout(() => i.remove(), 300);
      try { i.showPicker(); } catch (e) { i.style.opacity = "1"; i.focus(); }
    };
    $("#bCapture").onclick = () => {
      const img = chart.takeScreenshot(), c = img.getContext("2d");
      c.drawImage(calque, 0, 0, calque.width, calque.height, 0, 0, img.width, img.height);
      const a = document.createElement("a"); a.href = img.toDataURL("image/png"); a.download = `${S.actif}_${S.unite}_${new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-")}.png`; a.click();
    };
    $("#bListe").classList.toggle("actif", S.listeVisible); $("#droite").classList.toggle("cache", !S.listeVisible);

    $("#bas").classList.toggle("reduit", S.basReduit); $("#bBas").classList.toggle("actif", !S.basReduit);
    const basculerBas = () => { S.basReduit = !S.basReduit; sauverPrefs(); $("#bas").classList.toggle("reduit", S.basReduit); $("#bBas").classList.toggle("actif", !S.basReduit); $("#bFermerBas").textContent = S.basReduit ? "▴" : "▾"; };
    $("#bFermerBas").textContent = S.basReduit ? "▴" : "▾";
    $("#bBas").onclick = basculerBas; $("#bFermerBas").onclick = basculerBas;
    $$(".onglets-bas [data-bas]").forEach(b => b.onclick = () => {
      $$(".onglets-bas [data-bas]").forEach(x => x.classList.toggle("actif", x === b));
      $$(".contenu-bas").forEach(x => x.style.display = x.id === "bas-" + b.dataset.bas ? "" : "none");
      if (S.basReduit) basculerBas();
      if (b.dataset.bas === "testeur" || b.dataset.bas === "trades") chargerStats();
      if (b.dataset.bas === "alertes") tableAlertes();
      if (b.dataset.bas === "analyses") chargerAnalyses();
      if (b.dataset.bas === "trading" || b.dataset.bas === "testeur") chargerSessions();
    });
    $("#fStrat").onchange = chargerStats; $("#fMode").onchange = chargerStats;
    try { const c = JSON.parse(localStorage.getItem("mbgCompte") || "{}"); if (c.capital) $("#oCapital").value = c.capital; if (c.risque) $("#oRisque").value = c.risque; } catch (e) { /* rien */ }
    for (const id of ["#oCapital", "#oRisque"]) $(id).onchange = () => { try { localStorage.setItem("mbgCompte", JSON.stringify({ capital: $("#oCapital").value, risque: $("#oRisque").value })); } catch (e) { /* rien */ } tablePositions(); };
    // souris sur le graphique (phase de capture : avant que le graphique ne déplace la vue)
    zone.addEventListener("mousedown", surDown, true);
    const dans = (e, sel) => !!(e.target && e.target.closest && e.target.closest(sel));   // la cible peut être la fenêtre ou la page elle-même
    window.addEventListener("mousemove", e => { if (G.drag || dans(e, "#zone")) surMove(e); });
    const majMaj = e => { if (e.key === "Shift" && G.dernierMove && (G.crea || G.drag?.type === "poignee")) surMove(Object.assign({}, G.dernierMove, { shiftKey: e.type === "keydown" })); };
    window.addEventListener("keydown", majMaj); window.addEventListener("keyup", majMaj);
    window.addEventListener("mouseup", surUp);
    zone.addEventListener("dblclick", surDblClick, true);
    zone.addEventListener("contextmenu", menuContextuel, true);
    zone.addEventListener("mouseleave", () => { G.hover = null; sale = true; });
    new ResizeObserver(() => tailleCalque()).observe(zone);
    window.addEventListener("keydown", e => {
      G.aimantTemp = e.ctrlKey;
      const dansChamp = /INPUT|SELECT|TEXTAREA/.test(document.activeElement?.tagName || "");
      if ($(".dlg-fond.ouvert")) { if (e.key === "Escape") fermerDlgs(); return; }
      if (dansChamp) return;
      if (e.ctrlKey && !e.shiftKey && !e.altKey && (e.key === "t" || e.key === "T")) { e.preventDefault(); ouvrirDlg("onglet"); return; }   // Ctrl + T : nouvel onglet
      if (G.saisieU != null && !e.ctrlKey && !e.altKey && !e.metaKey) { if (saisieUnite(e)) { e.preventDefault(); return; } }
      if (/^[0-9]$/.test(e.key) && !e.ctrlKey && !e.altKey && !e.metaKey && G.sel < 0 && !G.crea) { G.saisieU = ""; saisieUnite(e); e.preventDefault(); return; }
      const k = e.key.toLowerCase();
      if ((e.ctrlKey || e.metaKey) && k === "z") { annuler(); e.preventDefault(); return; }
      if ((e.ctrlKey || e.metaKey) && k === "y") { refaire(); e.preventDefault(); return; }
      if ((e.ctrlKey || e.metaKey) && !e.altKey && k === "c") { if (copierSel()) e.preventDefault(); return; }
      if ((e.ctrlKey || e.metaKey) && !e.altKey && k === "v") { if (collerDessins()) e.preventDefault(); return; }
      if ((e.ctrlKey || e.metaKey) && !e.altKey && k === "k") { e.preventDefault(); ouvrirDlg("ouvrir", ""); return; }
      if (e.ctrlKey && e.altKey && k === "h") { e.preventDefault(); basculerMasquer(); return; }
      if (e.key === "?" || ((e.ctrlKey || e.metaKey) && e.key === "/")) { e.preventDefault(); afficherRaccourcis(); return; }
      if (e.key === "/" && !e.ctrlKey && !e.altKey) { e.preventDefault(); ouvrirInd(); return; }
      if (/^Arrow(Left|Right|Up|Down)$/.test(e.key) && !e.altKey && !(e.ctrlKey || e.metaKey) && selection().length) { deplacerAuClavier(selection(), e.key, e.shiftKey); e.preventDefault(); return; }
      if (G.mode === "replay" && e.key === "ArrowRight" && !e.ctrlKey) { avancer(1); e.preventDefault(); return; }
      if (G.mode === "replay" && e.key === "ArrowLeft" && !e.ctrlKey) { reculer(); e.preventDefault(); return; }
      if (/^Arrow(Left|Right|Up|Down)$/.test(e.key) && !e.altKey && naviguerClavier(e.key, e.ctrlKey || e.metaKey)) { e.preventDefault(); return; }
      if (G.mode === "replay" && e.key === " ") { lecture(); e.preventDefault(); return; }
      if ((e.key === "Delete" || e.key === "Backspace") && selection().length) { supprimerSel(); e.preventDefault(); return; }
      if (e.key === "Enter" && G.crea && nbPoints(G.crea.type) === "multi") { G.crea.pts.pop(); if (G.crea.pts.length >= 2) terminerCrea(); return; }
      if (e.key === "Escape") { G.crea = null; G.mesure = null; if (G.outil === "coupe" && G.rt == null) quitterReplay(); finOutil(); G.sel = -1; G.multi.clear(); barreDessin(); return; }
      if (e.altKey && k === "h") { choisirOutil("hline"); e.preventDefault(); return; }
      if (e.altKey && k === "t") { choisirOutil("trend"); e.preventDefault(); return; }
      if (e.altKey && k === "f") { choisirOutil("fibo"); e.preventDefault(); return; }
      if (e.altKey && e.shiftKey && k === "r") { choisirOutil("rect"); e.preventDefault(); return; }
      if (e.altKey && k === "j") { choisirOutil("hray"); e.preventDefault(); return; }
      if (e.altKey && k === "v") { choisirOutil("vline"); e.preventDefault(); return; }
      if (e.altKey && k === "c") { choisirOutil("croix"); e.preventDefault(); return; }
      if (e.altKey && k === "a") { $("#bAlerte").click(); e.preventDefault(); return; }
      if (e.altKey && !e.ctrlKey && !e.shiftKey && k === "g") { $("#bAllerDate").click(); e.preventDefault(); return; }
      if (e.altKey && !e.ctrlKey && !e.shiftKey && k === "s") { $("#bCapture").click(); e.preventDefault(); return; }
      if ((e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey && k === "s") { sauverMiseCourante(); e.preventDefault(); return; }   // Ctrl+S : sauvegarder la mise en page
      if (e.altKey && !e.ctrlKey && !e.shiftKey && k === "r") { chart.timeScale().resetTimeScale(); chart.priceScale("right").applyOptions({ autoScale: true }); e.preventDefault(); return; }
      if (e.altKey && !e.ctrlKey && !e.shiftKey && k === "i") { S.inverse = !S.inverse; sauverPrefs(); chart.applyOptions(optionsTheme()); toast(S.inverse ? "Échelle inversée" : "Échelle normale"); e.preventDefault(); return; }
      if (e.altKey && !e.ctrlKey && !e.shiftKey && k === "l") { modeEchelle(+S.echelle === 1 ? 0 : 1); e.preventDefault(); return; }
      if (e.altKey && !e.ctrlKey && !e.shiftKey && k === "p") { modeEchelle(+S.echelle === 2 ? 0 : 2); e.preventDefault(); return; }
      if (e.altKey && !e.ctrlKey && !e.shiftKey && k === "w") {
        if (!S.liste.includes(S.actif)) { S.liste.push(S.actif); sauverPrefs(); majListe(); toast(S.actif + " ajouté à la liste de suivi"); } else toast(S.actif + " est déjà dans la liste de suivi");
        e.preventDefault(); return;
      }
      if (e.shiftKey && k === "r" && !e.ctrlKey) { entrerReplay(); return; }
      if (/^[a-zA-Z0-9]$/.test(e.key) && !e.ctrlKey && !e.altKey && !e.metaKey) { ouvrirDlg("ouvrir", e.key); e.preventDefault(); }
    });
    window.addEventListener("keyup", e => { G.aimantTemp = e.ctrlKey; });
  }

  // ================================================================== démarrage
  async function demarrer() {
    document.body.classList.toggle("sombre", S.theme === "sombre");
    try { G.catalogue = (await api("/api/catalogue")).actifs || []; } catch (e) { G.catalogue = []; }
    if (!G.catalogue.some(x => x.code === S.actif)) S.actif = "EURUSD";
    api("/api/licence").then(l => {                  // copie avec une clé : prévenir avant la fin
      if (!l || !l.copie || !l.ok) return;
      if (l.jours_restants != null && l.jours_restants <= 5) toast(`Votre clé se termine dans ${l.jours_restants} jour(s) (le ${l.expire}) : demandez une nouvelle clé.`, false);
      if (l.utilisations_restantes != null && l.utilisations_restantes <= 3) toast(`Il reste ${l.utilisations_restantes} ouverture(s) avec votre clé : demandez une nouvelle clé.`, false);
    }).catch(() => {});
    creerGraphique(); construireOutils(); brancher(); appliquerCurseur(); tailleCalque(); requestAnimationFrame(boucle);
    await chargerDessins(); await charger(); demarrerDirect();
    tablePositions(); chargerStats(); majListe(); setInterval(majListe, 5000);
    document.addEventListener("visibilitychange", () => { if (!document.hidden) majListe(); });   // fenêtre revenue au premier plan : prix tout de suite
    const rg = (location.hash.match(/reglages=(\w+)/) || [])[1]; if (rg) ouvrirReglages(rg);
    if (location.hash === "#partage") $("#bPartage").click();
    const dp = (location.hash.match(/dispo=(\w+)/) || [])[1]; if (dp && DISPOS[dp] != null) { S.dispo = dp; appliquerDispo(); }   // ex. …/#dispo=4
    if (location.hash === "#envoi") { $("#bPartage").click(); setTimeout(() => $("#ongletEnvoi").click(), 300); }
    const bas = (location.hash.match(/bas=(\w+)/) || [])[1]; if (bas) $(`.onglets-bas [data-bas="${bas}"]`)?.click();   // ex. …/#bas=analyses   // ex. …/#reglages=toile ouvre la fenêtre Réglages
    const v = (location.hash.match(/volet=(\w+)/) || [])[1];   // ex. …/#volet=lignes ouvre directement un volet d'outils
    if (v && $(`#outils [data-groupe="${v}"]`)) setTimeout(() => ouvrirVolet(v, $(`#outils [data-groupe="${v}"]`)), 600);
  }
  // ================================================================== installation sur le PC (application installée par Edge / Chrome)
  let invitation = null;
  const dejaInstallee = () => window.matchMedia("(display-mode: standalone)").matches || window.matchMedia("(display-mode: window-controls-overlay)").matches;
  try {
    const estInvite = location.port === "8781";            // chez un invité : jamais de copie des pages gardée dans son navigateur
    if (estInvite && "serviceWorker" in navigator) navigator.serviceWorker.getRegistrations().then(rs => rs.forEach(r => r.unregister())).catch(() => {});
    if (!estInvite && "serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js")
      .then(() => { document.body.dataset.installable = "oui"; })
      .catch(e => { document.body.dataset.installable = "non : " + String(e).slice(0, 120); });
  } catch (e) { /* rien */ }
  window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); invitation = e; if (!dejaInstallee()) $("#bInstaller").style.display = ""; });
  window.addEventListener("appinstalled", () => { $("#bInstaller").style.display = "none"; toast("MaBoussole Graphiques est installé : il est dans le menu Démarrer et peut être épinglé à la barre des tâches."); });
  if (!dejaInstallee()) $("#bInstaller").style.display = "";
  $("#bInstaller").onclick = async () => {
    if (!invitation) {
      alert("Installer MaBoussole Graphiques depuis le navigateur :\n\n• Microsoft Edge : ouvrez http://localhost:8780 dans Edge, puis menu ⋯ > Applications > « Installer ce site en tant qu'application » (ou l'icône ⊕ dans la barre d'adresse).\n• Google Chrome : ouvrez http://localhost:8780, puis l'icône d'installation dans la barre d'adresse (ou menu ⋮ > Caster, enregistrer et partager > Installer la page en tant qu'application).\n\nSi l'application est déjà installée, elle se trouve dans le menu Démarrer.");
      return;
    }
    invitation.prompt(); const r = await invitation.userChoice; invitation = null; if (r.outcome === "accepted") $("#bInstaller").style.display = "none";
  };
  window.MBG = { S, G, get chart() { return chart; }, get serie() { return serie; }, idxDe, geo, peindre };
  demarrer();
})();
